import { GiftOption } from './types';

export const BROKER_URL = 'wss://broker.emqx.io:8084/mqtt';
export const ROOM_TOPIC = 'dardashti_stars_app_2026_v25';
export const ADMIN_NAME = 'sasa';
export const GIFT_COST = 5;
export const TTT_COMMISSION = 2;
export const ROOM_SEAT_COUNT = 8;

export const GIFTS: GiftOption[] = [
  { e: '🌹', n: 'وردة', cost: 5 },
  { e: '🍫', n: 'شوكولاتة', cost: 5 },
  { e: '☕', n: 'قهوة', cost: 5 },
  { e: '👑', n: 'تاج ذهبي', cost: 10 },
  { e: '💍', n: 'خاتم ألماس', cost: 15 },
  { e: '🏎️', n: 'سيارة فيراري', cost: 20 },
  { e: '🏰', n: 'قصر ملكي', cost: 50 },
  { e: '🚀', n: 'صاروخ فضائي', cost: 100 },
];

export const DIAMOND_LEVELS = [
  { min: 0, name: 'مبتدئ' },
  { min: 1000, name: 'نجم صاعد' },
  { min: 3000, name: 'متألق' },
  { min: 6000, name: 'فضي' },
  { min: 10000, name: 'ذهبي' },
  { min: 15000, name: 'ياقوتي' },
  { min: 21000, name: 'زمردي' },
  { min: 28000, name: 'أمير النجوم' },
  { min: 36000, name: 'أسطوري' },
  { min: 45000, name: 'إمبراطور' },
  { min: 55000, name: 'ملك الدردشة' },
];

export const ROOM_BGS = [
  { id: 'galaxy', name: 'مجرة بنفسجية', css: 'linear-gradient(135deg, #1e1b4b 0%, #4c1d95 50%, #701a75 100%)' },
  { id: 'royal_hall', name: 'قاعة ملكية', css: "url('https://images.unsplash.com/photo-1519751138087-5bf79df62d5b?q=80&w=1200&auto=format&fit=crop')" },
  { id: 'ocean', name: 'أمواج المحيط', css: 'linear-gradient(135deg, #082f49 0%, #0369a1 50%, #0e7490 100%)' },
  { id: 'sunset', name: 'غروب الشمس', css: "url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=1200&auto=format&fit=crop')" },
  { id: 'forest', name: 'واحة خضراء', css: 'linear-gradient(135deg, #052e16 0%, #166534 50%, #15803d 100%)' },
  { id: 'neon_city', name: 'مدينة النيون', css: "url('https://images.unsplash.com/photo-1519501025264-65ba15a82390?q=80&w=1200&auto=format&fit=crop')" },
  { id: 'royal_pink', name: 'وردي ملكي', css: 'linear-gradient(135deg, #500724 0%, #9d174d 50%, #db2777 100%)' },
  { id: 'dark_luxury', name: 'أسود فاخر', css: 'linear-gradient(135deg, #09090b 0%, #18181b 50%, #27272a 100%)' },
];

export const QUICK_EMOJIS = ['❤️', '😂', '🔥', '👑', '🎉', '👏', '😍', '🌹', '💎', '⭐', '✨', '🤩', '👍', '🙏', '💯', '🚀', '🥰', '🥳'];

export const DEMO_SONGS = [
  {
    id: 'demo_1',
    title: 'تقاسيم عود شرقية',
    artist: 'موسيقى أندلسية',
    duration: 35,
    synthType: 'oud',
  },
  {
    id: 'demo_2',
    title: 'إيقاع خليجي هادئ',
    artist: 'فرقة النجوم',
    duration: 30,
    synthType: 'rhythm',
  },
  {
    id: 'demo_3',
    title: 'أنغام ليلية هادئة',
    artist: 'موسيقى الاسترخاء',
    duration: 40,
    synthType: 'calm',
  },
];

export interface CountryOption {
  code: string;
  name: string;
  flag: string;
}

export const COUNTRIES: CountryOption[] = [
  { code: 'EG', name: 'مصر', flag: '🇪🇬' },
  { code: 'SA', name: 'السعودية', flag: '🇸🇦' },
  { code: 'AE', name: 'الإمارات', flag: '🇦🇪' },
  { code: 'KW', name: 'الكويت', flag: '🇰🇼' },
  { code: 'QA', name: 'قطر', flag: '🇶🇦' },
  { code: 'BH', name: 'البحرين', flag: '🇧🇭' },
  { code: 'OM', name: 'عمان', flag: '🇴🇲' },
  { code: 'IQ', name: 'العراق', flag: '🇮🇶' },
  { code: 'JO', name: 'الأردن', flag: '🇯🇴' },
  { code: 'SY', name: 'سوريا', flag: '🇸🇾' },
  { code: 'LB', name: 'لبنان', flag: '🇱🇧' },
  { code: 'PS', name: 'فلسطين', flag: '🇵🇸' },
  { code: 'YE', name: 'اليمن', flag: '🇾🇪' },
  { code: 'MA', name: 'المغرب', flag: '🇲🇦' },
  { code: 'DZ', name: 'الجزائر', flag: '🇩🇿' },
  { code: 'TN', name: 'تونس', flag: '🇹🇳' },
  { code: 'LY', name: 'ليبيا', flag: '🇱🇾' },
  { code: 'SD', name: 'السودان', flag: '🇸🇩' },
  { code: 'OTHER', name: 'أخرى', flag: '🌍' },
];
