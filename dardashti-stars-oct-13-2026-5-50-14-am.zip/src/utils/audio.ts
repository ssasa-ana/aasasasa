// Audio context and sound synthesizer for Dardashti Stars
let audioCtx: AudioContext | null = null;
let roomAudioElement: HTMLAudioElement | null = null;

export function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioCtxClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioCtxClass) {
      audioCtx = new AudioCtxClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playBeep(freq: number, duration: number, delay = 0, soundEnabled = true): void {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const t = ctx.currentTime + (delay || 0);
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, t);
    gain.gain.setValueAtTime(0.001, t);
    gain.gain.exponentialRampToValueAtTime(0.18, t + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(t);
    osc.stop(t + duration + 0.05);
  } catch {
    // Ignore audio restrictions
  }
}

export function playDmSound(soundEnabled = true): void {
  playBeep(880, 0.12, 0, soundEnabled);
  playBeep(1174, 0.16, 0.13, soundEnabled);
}

export function playMicJoinSound(soundEnabled = true): void {
  playBeep(523, 0.12, 0, soundEnabled);
  playBeep(659, 0.12, 0.12, soundEnabled);
  playBeep(784, 0.22, 0.24, soundEnabled);
}

export function playKickSound(soundEnabled = true): void {
  playBeep(320, 0.12, 0, soundEnabled);
  playBeep(240, 0.18, 0.12, soundEnabled);
}

export function playLockSound(soundEnabled = true): void {
  playBeep(600, 0.08, 0, soundEnabled);
  playBeep(450, 0.12, 0.08, soundEnabled);
}

export function playSecurityAlertSound(soundEnabled = true): void {
  if (!soundEnabled) return;
  try {
    playBeep(850, 0.15, 0, soundEnabled);
    playBeep(450, 0.18, 0.18, soundEnabled);
    playBeep(850, 0.15, 0.38, soundEnabled);
    playBeep(450, 0.25, 0.55, soundEnabled);
  } catch {}
}

export function playRingtoneSound(soundEnabled = true): void {
  if (!soundEnabled) return;
  try {
    playBeep(784, 0.2, 0, soundEnabled);
    playBeep(880, 0.2, 0.22, soundEnabled);
    playBeep(1046, 0.35, 0.44, soundEnabled);
  } catch {}
}

export function playOutgoingDialTone(soundEnabled = true): void {
  if (!soundEnabled) return;
  try {
    playBeep(440, 0.6, 0, soundEnabled);
    playBeep(480, 0.6, 0, soundEnabled);
  } catch {}
}

export function playCallEndSound(soundEnabled = true): void {
  if (!soundEnabled) return;
  try {
    playBeep(480, 0.12, 0, soundEnabled);
    playBeep(480, 0.12, 0.18, soundEnabled);
    playBeep(480, 0.2, 0.36, soundEnabled);
  } catch {}
}

export const BEST_MIC_CONSTRAINTS: MediaStreamConstraints = {
  audio: {
    channelCount: { ideal: 1 },
    sampleRate: { ideal: 48000 },
    sampleSize: { ideal: 16 },
    echoCancellation: { ideal: true },
    noiseSuppression: { ideal: true },
    autoGainControl: { ideal: true },
    latency: { ideal: 0.01 },
  } as unknown as MediaTrackConstraints,
};

export function createSilentAudioStream(): MediaStream {
  try {
    const ctx = getAudioContext();
    if (ctx) {
      const dest = ctx.createMediaStreamDestination();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      gain.gain.value = 0; // Silent audio track
      osc.connect(gain);
      gain.connect(dest);
      osc.start();
      return dest.stream;
    }
  } catch (err) {
    console.warn('Fallback silent stream generation:', err);
  }
  try {
    return new MediaStream();
  } catch {
    return {} as MediaStream;
  }
}

export async function getBestMicStream(): Promise<MediaStream> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return createSilentAudioStream();
  }
  try {
    return await navigator.mediaDevices.getUserMedia(BEST_MIC_CONSTRAINTS);
  } catch {
    try {
      return await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 48000,
        },
      });
    } catch {
      try {
        return await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch {
        return createSilentAudioStream();
      }
    }
  }
}

export async function getBestUserMedia(video: boolean): Promise<MediaStream> {
  if (typeof navigator === 'undefined' || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return createSilentAudioStream();
  }
  const constraints: MediaStreamConstraints = {
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
    video: video
      ? {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user',
        }
      : false,
  };
  try {
    return await navigator.mediaDevices.getUserMedia(constraints);
  } catch {
    if (video) {
      try {
        return await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      } catch {
        return await getBestMicStream();
      }
    }
    return await getBestMicStream();
  }
}

export function getRecorderOptions(): MediaRecorderOptions {
  if (typeof window === 'undefined' || !window.MediaRecorder) return {};
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
    'audio/mp4',
  ];
  for (const mimeType of candidates) {
    if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(mimeType)) {
      return { mimeType, audioBitsPerSecond: 128000 };
    }
  }
  return {};
}

let voiceCompressorNode: DynamicsCompressorNode | null = null;
let voiceGainNode: GainNode | null = null;

export function getVoiceEnhancementNodes(ctx: AudioContext): { compressor: DynamicsCompressorNode; gain: GainNode } {
  if (!voiceCompressorNode || !voiceGainNode || voiceCompressorNode.context !== ctx) {
    voiceCompressorNode = ctx.createDynamicsCompressor();
    voiceCompressorNode.threshold.setValueAtTime(-24, ctx.currentTime);
    voiceCompressorNode.knee.setValueAtTime(30, ctx.currentTime);
    voiceCompressorNode.ratio.setValueAtTime(4, ctx.currentTime);
    voiceCompressorNode.attack.setValueAtTime(0.003, ctx.currentTime);
    voiceCompressorNode.release.setValueAtTime(0.25, ctx.currentTime);

    voiceGainNode = ctx.createGain();
    voiceGainNode.gain.setValueAtTime(1.3, ctx.currentTime);

    voiceCompressorNode.connect(voiceGainNode);
    voiceGainNode.connect(ctx.destination);
  }
  return { compressor: voiceCompressorNode, gain: voiceGainNode };
}

export function unlockAudio(): void {
  try {
    const ctx = getAudioContext();
    if (ctx && ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }
  } catch {}
}

export function getRoomAudioElement(): HTMLAudioElement {
  if (!roomAudioElement && typeof window !== 'undefined') {
    roomAudioElement = new Audio();
    roomAudioElement.preload = 'auto';
  }
  return roomAudioElement!;
}

export function playRoomAudio(src: string, volume = 0.8, onEnded?: () => void) {
  const audio = getRoomAudioElement();
  audio.src = src;
  audio.volume = volume;
  if (onEnded) {
    audio.onended = onEnded;
  }
  audio.play().catch(() => {});
}

export function pauseRoomAudio() {
  if (roomAudioElement) {
    roomAudioElement.pause();
  }
}

export function stopRoomAudio() {
  if (roomAudioElement) {
    roomAudioElement.pause();
    roomAudioElement.currentTime = 0;
    roomAudioElement.src = '';
  }
}

export function setRoomAudioVolume(vol: number) {
  if (roomAudioElement) {
    roomAudioElement.volume = Math.max(0, Math.min(1, vol));
  }
}

export function getRoomAudioVolume(): number {
  return roomAudioElement ? roomAudioElement.volume : 0.85;
}

export function encodeWav(samples: Float32Array, sampleRate: number): ArrayBuffer {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, 'data');
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }

  return buffer;
}

function writeString(view: DataView, offset: number, str: string) {
  for (let i = 0; i < str.length; i++) {
    view.setUint8(offset + i, str.charCodeAt(i));
  }
}

export function downsampleBuffer(
  buffer: Float32Array,
  inputRate: number,
  outputRate: number
): Float32Array {
  if (outputRate >= inputRate) return buffer;
  const ratio = inputRate / outputRate;
  const newLength = Math.round(buffer.length / ratio);
  const result = new Float32Array(newLength);
  let offsetResult = 0;
  let offsetBuffer = 0;
  while (offsetResult < result.length) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    let accum = 0;
    let count = 0;
    for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count > 0 ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 8192;
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return btoa(binary);
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const rawBase64 = base64.includes(',') ? base64.split(',')[1] : base64;
  const binStr = atob(rawBase64);
  const len = binStr.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binStr.charCodeAt(i);
  }
  return bytes.buffer;
}
