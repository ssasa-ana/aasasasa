import React, { useState, useEffect, useRef, useCallback } from 'react';
import mqtt, { MqttClient } from 'mqtt';
import {
  Radio,
  Mic,
  MicOff,
  ChevronUp,
  LogOut,
  Video,
} from 'lucide-react';
// Icons & Models
import {
  UserAccount,
  DirectMessage,
  PostItem,
  RoomGiftEvent,
  RoomChatMsg,
  TicTacToeState,
  GiftOption,
  RoomMusicState,
  ActiveCallSession,
  VerificationRequest,
} from './types';
import {
  BROKER_URL,
  ROOM_TOPIC,
  ADMIN_NAME,
  ROOM_SEAT_COUNT,
} from './constants';
import { generateSessionId } from './utils/helpers';
import { Language, translations } from './utils/i18n';
import {
  getAudioContext,
  unlockAudio,
  playBeep,
  playDmSound,
  playMicJoinSound,
  playKickSound,
  playLockSound,
  playSecurityAlertSound,
  playRingtoneSound,
  playOutgoingDialTone,
  playCallEndSound,
  getBestMicStream,
  getBestUserMedia,
  getRecorderOptions,
  playRoomAudio,
  pauseRoomAudio,
  stopRoomAudio,
  setRoomAudioVolume,
  getRoomAudioVolume,
  getVoiceEnhancementNodes,
  encodeWav,
  downsampleBuffer,
  arrayBufferToBase64,
} from './utils/audio';

// Components
import { Toast } from './components/Toast';
import { Header } from './components/Header';
import { BottomNavigation, TabType } from './components/BottomNavigation';
import { AuthScreen } from './components/AuthScreen';
import { OnlineUsersTab } from './components/OnlineUsersTab';
import { RoomsTab } from './components/RoomsTab';
import { ActiveRoomView } from './components/ActiveRoomView';
import { DMsTab } from './components/DMsTab';
import { GamesTab } from './components/GamesTab';
import { PostsTab } from './components/PostsTab';
import { ProfileTab } from './components/ProfileTab';

// Modals
import { AdminModal } from './components/modals/AdminModal';
import { GiftModal } from './components/modals/GiftModal';
import { RoomBgModal } from './components/modals/RoomBgModal';
import { CreateRoomModal } from './components/modals/CreateRoomModal';
import { InviteModal } from './components/modals/InviteModal';
import { LevelsModal } from './components/modals/LevelsModal';
import { UserProfileModal } from './components/modals/UserProfileModal';
import { EditProfileModal } from './components/modals/EditProfileModal';
import { BuyCoinsModal, WithdrawModal } from './components/modals/FinanceModals';
import { ImageLightboxModal } from './components/modals/ImageLightboxModal';
import { SessionKickModal } from './components/modals/SessionKickModal';
import { ActiveCallModal } from './components/modals/ActiveCallModal';
import { VerificationModal } from './components/modals/VerificationModal';
import { TasksModal } from './components/modals/TasksModal';

export default function App() {
  // Session & Authentication (Unique session ID per active tab/browser)
  const [mySessionId] = useState(() => generateSessionId());
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    try {
      const saved = localStorage.getItem('auth_current_user_v25');
      return saved && saved.trim() ? saved.trim() : null;
    } catch {
      return null;
    }
  });

  // Language state: 'ar' or 'en'
  const [lang, setLang] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('app_lang_v25');
      return saved === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  // Sync HTML lang and dir attribute
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    }
    localStorage.setItem('app_lang_v25', lang);
  }, [lang]);

  // Session kick warning modal state
  const [kickModalState, setKickModalState] = useState<{
    isOpen: boolean;
    username: string;
    reason?: string;
    isBanned?: boolean;
  } | null>(null);

  // Active 1-on-1 Voice or Live Video Call Session
  const [activeCall, setActiveCall] = useState<ActiveCallSession | null>(null);
  const activeCallRef = useRef<ActiveCallSession | null>(null);
  activeCallRef.current = activeCall;
  const callStreamRef = useRef<MediaStream | null>(null);
  const [callMediaStream, setCallMediaStream] = useState<MediaStream | null>(null);
  const callAudioProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const callAudioSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  // Accounts & Persistence
  const [cloudAccounts, setCloudAccounts] = useState<Record<string, UserAccount>>(() => {
    const raw = localStorage.getItem('cloud_accounts_sync_v25');
    const parsed = raw ? JSON.parse(raw) : {};
    if (!parsed['sasa']) {
      parsed['sasa'] = {
        pass: 'mosa',
        points: 1000,
        gender: 'ذكر 👨',
        age: 25,
        bio: 'المسؤول الرئيسي للتطبيق 👑',
        idNum: '99999999',
        country: 'مصر',
        countryFlag: '🇪🇬',
        displayName: 'المسؤول sasa',
        isAdmin: true,
        isMod: false,
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=400&auto=format&fit=crop',
        mutedUntil: 0,
        isBanned: false,
        diamonds: 500,
        following: [],
        mutes: [],
        status: 'online',
        inbox: [],
        isVerified: true,
        verificationStatus: 'approved',
        completedTasks: [],
        calledPartners: [],
      };
    }
    return parsed;
  });

  // Verification Requests list (persisted & synced via MQTT)
  const [verificationRequests, setVerificationRequests] = useState<VerificationRequest[]>(() => {
    try {
      const raw = localStorage.getItem('verif_requests_v25');
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  });

  const [onlineUsers, setOnlineUsers] = useState<Record<string, number>>({});
  const [currentCoins, setCurrentCoins] = useState<number>(() => {
    try {
      const savedUser = localStorage.getItem('auth_current_user_v25');
      if (savedUser) {
        const raw = localStorage.getItem('cloud_accounts_sync_v25');
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed[savedUser]?.points !== undefined) {
            return parsed[savedUser].points;
          }
        }
      }
    } catch {}
    return 50;
  });

  // Helper to persist or clear authenticated user session
  const handleSetCurrentUser = useCallback((user: string | null) => {
    setCurrentUser(user);
    try {
      if (user && user.trim()) {
        localStorage.setItem('auth_current_user_v25', user.trim());
      } else {
        localStorage.removeItem('auth_current_user_v25');
      }
    } catch {}
  }, []);

  // Navigation & Tabs
  const [activeTab, setActiveTab] = useState<TabType>('chat');

  // Audio & Sound
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    return localStorage.getItem('sound_on_v25') !== '0';
  });
  const [audioActive, setAudioActive] = useState(false);

  // Real-time MQTT
  const [isConnected, setIsConnected] = useState(false);
  const clientRef = useRef<MqttClient | null>(null);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<any>(null);
  const showToast = useCallback((msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  }, []);

  // Direct Messages
  const [dmHistory, setDmHistory] = useState<Record<string, DirectMessage[]>>(() => {
    const raw = localStorage.getItem('dm_history_v25');
    return raw ? JSON.parse(raw) : {};
  });
  const [unreadDm, setUnreadDm] = useState<Record<string, number>>({});
  const [activeDmPartner, setActiveDmPartner] = useState<string | null>(null);
  const [typingPartners, setTypingPartners] = useState<Record<string, boolean>>({});

  // Posts Feed
  const [postsFeed, setPostsFeed] = useState<PostItem[]>(() => {
    const raw = localStorage.getItem('posts_feed_v25');
    return raw ? JSON.parse(raw) : [];
  });

  // Invites
  const [myInvites, setMyInvites] = useState<{ friend: string; ts: number }[]>(() => {
    const raw = localStorage.getItem('my_invites_v25');
    return raw ? JSON.parse(raw) : [];
  });

  // Tic-Tac-Toe
  const [tttState, setTttState] = useState<TicTacToeState>({
    gameId: null,
    active: false,
    waiting: false,
    board: Array(9).fill(''),
    myMark: 'X',
    opp: null,
    myTurn: false,
    stake: 5,
    waitDeadline: 0,
  });

  // Rooms State
  const [roomHeartbeats, setRoomHeartbeats] = useState<Record<string, number>>({});
  const [roomNames, setRoomNames] = useState<Record<string, string>>({});
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [isMyRoomAdmin, setIsMyRoomAdmin] = useState(false);
  const [isRoomMinimized, setIsRoomMinimized] = useState(false);
  const [myRoomCustomName, setMyRoomCustomName] = useState('');
  const [roomSeats, setRoomSeats] = useState<Record<number | string, string | null>>({});
  const [roomMutes, setRoomMutes] = useState<Record<string, boolean>>({});
  const [roomLockedSeats, setRoomLockedSeats] = useState<Record<number | string, boolean>>({});
  const [roomMusicState, setRoomMusicState] = useState<RoomMusicState | null>(null);
  const [roomMusicVolume, setRoomMusicVolume] = useState<number>(() => getRoomAudioVolume());
  const [roomBg, setRoomBg] = useState('linear-gradient(135deg, #1e1b4b 0%, #4c1d95 50%, #701a75 100%)');
  const [roomChatLog, setRoomChatLog] = useState<RoomChatMsg[]>([]);
  const [myRoomSeatIdx, setMyRoomSeatIdx] = useState<number | null>(null);
  const [isRoomMicMuted, setIsRoomMicMuted] = useState(false);
  const [isMeSpeaking, setIsMeSpeaking] = useState(false);
  const [speakingUsers, setSpeakingUsers] = useState<Record<string, boolean>>({});
  const [floatingGifts, setFloatingGifts] = useState<RoomGiftEvent[]>([]);
  const [floatingTexts, setFloatingTexts] = useState<RoomChatMsg[]>([]);

  // Room Audio Stream
  const roomStreamRef = useRef<MediaStream | null>(null);
  const roomRecorderRef = useRef<MediaRecorder | null>(null);
  const roomAudioProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const roomAudioSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextScheduledVoiceTime = useRef(0);
  const roomMicActiveRef = useRef(false);
  const speakingTimersRef = useRef<Record<string, any>>({});
  const cloudAccountsRef = useRef(cloudAccounts);
  cloudAccountsRef.current = cloudAccounts;

  // Modals state
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showGiftModal, setShowGiftModal] = useState(false);
  const [giftModalIsRoom, setGiftModalIsRoom] = useState(false);
  const [showRoomBgModal, setShowRoomBgModal] = useState(false);
  const [showCreateRoomModal, setShowCreateRoomModal] = useState(false);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showLevelsModal, setShowLevelsModal] = useState(false);
  const [showUserProfileModal, setShowUserProfileModal] = useState<string | null>(null);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  const [showBuyModal, setShowBuyModal] = useState(false);
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [showVerificationModal, setShowVerificationModal] = useState(false);
  const [showTasksModal, setShowTasksModal] = useState(false);

  // Sync to localStorage
  const saveCloudAccounts = useCallback((newAccs: Record<string, UserAccount>) => {
    setCloudAccounts(newAccs);
    localStorage.setItem('cloud_accounts_sync_v25', JSON.stringify(newAccs));
  }, []);

  const saveVerificationRequests = useCallback((requests: VerificationRequest[]) => {
    setVerificationRequests(requests);
    localStorage.setItem('verif_requests_v25', JSON.stringify(requests));
  }, []);

  const saveDmHistory = useCallback((newHist: Record<string, DirectMessage[]>) => {
    setDmHistory(newHist);
    localStorage.setItem('dm_history_v25', JSON.stringify(newHist));
  }, []);

  const savePostsFeed = useCallback((newPosts: PostItem[]) => {
    setPostsFeed(newPosts);
    localStorage.setItem('posts_feed_v25', JSON.stringify(newPosts));
  }, []);

  // Synchronization refs to avoid reconnecting MQTT on every state change
  const currentUserRef = useRef(currentUser);
  currentUserRef.current = currentUser;
  const isRoomMicMutedRef = useRef(isRoomMicMuted);
  isRoomMicMutedRef.current = isRoomMicMuted;
  const activeDmPartnerRef = useRef(activeDmPartner);
  activeDmPartnerRef.current = activeDmPartner;
  const soundEnabledRef = useRef(soundEnabled);
  soundEnabledRef.current = soundEnabled;
  const isMyRoomAdminRef = useRef(isMyRoomAdmin);
  isMyRoomAdminRef.current = isMyRoomAdmin;
  const currentRoomRef = useRef(currentRoom);
  currentRoomRef.current = currentRoom;
  const roomSeatsRef = useRef(roomSeats);
  roomSeatsRef.current = roomSeats;
  const roomMutesRef = useRef(roomMutes);
  roomMutesRef.current = roomMutes;
  const roomLockedSeatsRef = useRef(roomLockedSeats);
  roomLockedSeatsRef.current = roomLockedSeats;
  const roomMusicStateRef = useRef(roomMusicState);
  roomMusicStateRef.current = roomMusicState;
  const roomBgRef = useRef(roomBg);
  roomBgRef.current = roomBg;
  const myRoomCustomNameRef = useRef(myRoomCustomName);
  myRoomCustomNameRef.current = myRoomCustomName;

  // Publish helper
  const publish = useCallback((sub: string, payload: any) => {
    if (clientRef.current) {
      try {
        clientRef.current.publish(`${ROOM_TOPIC}/${sub}`, JSON.stringify(payload), { qos: 1 });
      } catch (err) {
        console.error('MQTT publish error:', err);
      }
    }
  }, []);

  // Helper to ingest offline inbox messages for the current user
  const ingestInboxMessages = useCallback((username: string, accountUser?: UserAccount) => {
    if (!accountUser || !accountUser.inbox || accountUser.inbox.length === 0) return;
    setDmHistory((prev) => {
      let changed = false;
      const nextHist = { ...prev };
      accountUser.inbox!.forEach((m) => {
        const partner = m.from === username ? m.to : m.from;
        const list = nextHist[partner] || [];
        if (!list.some((existing) => existing.id === m.id)) {
          nextHist[partner] = [...list, m];
          changed = true;
          if (m.to === username && activeDmPartnerRef.current !== partner) {
            setUnreadDm((uPrev) => ({ ...uPrev, [partner]: (uPrev[partner] || 0) + 1 }));
          }
        }
      });
      if (changed) {
        localStorage.setItem('dm_history_v25', JSON.stringify(nextHist));
        return nextHist;
      }
      return prev;
    });
  }, []);

  // Modify user coins helper
  const modifyUserCoins = useCallback(
    (targetName: string | null | undefined, delta: number) => {
      if (!targetName) return;
      setCloudAccounts((prev) => {
        const acc = prev[targetName];
        if (!acc) return prev;
        const updatedPoints = Math.max(0, (acc.points || 0) + delta);
        const updated = {
          ...prev,
          [targetName]: {
            ...acc,
            points: updatedPoints,
          },
        };
        saveCloudAccounts(updated);
        publish('sync_account', { name: targetName, user: updated[targetName] });
        if (targetName === currentUser) {
          setCurrentCoins(updatedPoints);
        }
        return updated;
      });
    },
    [currentUser, publish, saveCloudAccounts]
  );

  // Modify user diamonds helper
  const modifyUserDiamonds = useCallback(
    (targetName: string | null | undefined, delta: number) => {
      if (!targetName) return;
      setCloudAccounts((prev) => {
        const acc = prev[targetName];
        if (!acc) return prev;
        const updatedDiamonds = Math.max(0, (acc.diamonds || 0) + delta);
        const updated = {
          ...prev,
          [targetName]: {
            ...acc,
            diamonds: updatedDiamonds,
          },
        };
        saveCloudAccounts(updated);
        publish('sync_account', { name: targetName, user: updated[targetName] });
        return updated;
      });
    },
    [publish, saveCloudAccounts]
  );

  // Play remote microphone voice chunk
  const playRemoteAudioChunk = useCallback(async (base64Data: string) => {
    if (!base64Data) return;
    try {
      unlockAudio();
      const rawBase64 = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
      const binStr = atob(rawBase64);
      const len = binStr.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) bytes[i] = binStr.charCodeAt(i);
      const ctx = getAudioContext();
      if (ctx && ctx.state !== 'closed') {
        if (ctx.state === 'suspended') {
          await ctx.resume().catch(() => {});
        }
        try {
          const audioBuffer = await ctx.decodeAudioData(bytes.buffer.slice(0));
          const source = ctx.createBufferSource();
          source.buffer = audioBuffer;
          const { compressor } = getVoiceEnhancementNodes(ctx);
          source.connect(compressor);
          const now = ctx.currentTime;
          if (nextScheduledVoiceTime.current < now) {
            nextScheduledVoiceTime.current = now + 0.025;
          }
          source.start(nextScheduledVoiceTime.current);
          nextScheduledVoiceTime.current += audioBuffer.duration;
          return;
        } catch {
          // fallback to HTML5 Audio
        }
      }
      const mime = base64Data.includes('audio/wav')
        ? 'audio/wav'
        : base64Data.includes('audio/mp4')
        ? 'audio/mp4'
        : 'audio/webm;codecs=opus';
      const dataUri = base64Data.startsWith('data:') ? base64Data : `data:${mime};base64,${rawBase64}`;
      const audioElem = new Audio(dataUri);
      audioElem.volume = 1.0;
      audioElem.play().catch(() => {});
    } catch (e) {
      console.warn('Voice playback error:', e);
    }
  }, []);

  // Leave room handler
  const leaveCurrentRoom = useCallback(() => {
    roomMicActiveRef.current = false;
    nextScheduledVoiceTime.current = 0;
    if (roomAudioProcessorRef.current) {
      try {
        roomAudioProcessorRef.current.disconnect();
      } catch {}
      roomAudioProcessorRef.current = null;
    }
    if (roomAudioSourceRef.current) {
      try {
        roomAudioSourceRef.current.disconnect();
      } catch {}
      roomAudioSourceRef.current = null;
    }
    if (roomStreamRef.current) {
      roomStreamRef.current.getTracks().forEach((t) => t.stop());
      roomStreamRef.current = null;
    }
    if (roomRecorderRef.current) {
      try {
        roomRecorderRef.current.stop();
      } catch {}
      roomRecorderRef.current = null;
    }
    stopRoomAudio();
    const curUser = currentUserRef.current;
    if (isMyRoomAdminRef.current && curUser) {
      publish('rooms', { type: 'room_closed', room: curUser });
    } else if (currentRoomRef.current && myRoomSeatIdx !== null && curUser) {
      publish('rooms', { type: 'leave_seat', room: currentRoomRef.current, seat: myRoomSeatIdx, name: curUser });
    }
    if (curUser) {
      setCloudAccounts((prev) => {
        const u = prev[curUser];
        if (!u) return prev;
        const updated = { ...prev, [curUser]: { ...u, currentRoom: undefined } };
        saveCloudAccounts(updated);
        publish('sync_account', { name: curUser, user: updated[curUser] });
        return updated;
      });
    }
    setCurrentRoom(null);
    currentRoomRef.current = null;
    setIsMyRoomAdmin(false);
    isMyRoomAdminRef.current = false;
    setIsRoomMinimized(false);
    setMyRoomSeatIdx(null);
    setIsRoomMicMuted(false);
    isRoomMicMutedRef.current = false;
    setIsMeSpeaking(false);
    setSpeakingUsers({});
    setRoomSeats({});
    setRoomLockedSeats({});
    setRoomMusicState(null);
    setRoomChatLog([]);
    setFloatingGifts([]);
    setFloatingTexts([]);
  }, [myRoomSeatIdx, publish, saveCloudAccounts]);

  // Handle confirming session kick (logout after warning countdown)
  const handleKickLogoutConfirm = useCallback(() => {
    setKickModalState(null);
    leaveCurrentRoom();
    handleSetCurrentUser(null);
    showToast('تم تسجيل الخروج بنجاح.');
  }, [leaveCurrentRoom, handleSetCurrentUser, showToast]);

  // Admin toggle ban user handler
  const handleToggleBanUser = useCallback(
    (targetName: string, isBanned: boolean, reason?: string) => {
      setCloudAccounts((prev) => {
        const acc = prev[targetName];
        if (!acc) return prev;
        const updatedAcc: UserAccount = {
          ...acc,
          isBanned,
          banReason: isBanned ? reason || 'مخالفة الشروط' : undefined,
          bannedAt: isBanned ? Date.now() : undefined,
        };
        const updated = { ...prev, [targetName]: updatedAcc };
        saveCloudAccounts(updated);
        publish('control', {
          target: targetName,
          isBanned,
          banReason: updatedAcc.banReason,
        });
        publish('sync_account', { name: targetName, user: updatedAcc });
        if (isBanned) {
          publish('session_kick', {
            username: targetName,
            adminKick: true,
            isBanned: true,
            reason: updatedAcc.banReason,
            sessionId: 'admin_ban_' + Date.now(),
          });
        }
        return updated;
      });
      showToast(
        isBanned
          ? `تم حظر ${targetName} بنجاح`
          : `تم إلغاء حظر ${targetName}`
      );
    },
    [publish, saveCloudAccounts, showToast]
  );

  // Stop active call audio/video streams
  const stopCallAudio = useCallback(() => {
    if (callAudioProcessorRef.current) {
      try {
        callAudioProcessorRef.current.disconnect();
      } catch {}
      callAudioProcessorRef.current = null;
    }
    if (callAudioSourceRef.current) {
      try {
        callAudioSourceRef.current.disconnect();
      } catch {}
      callAudioSourceRef.current = null;
    }
    if (callStreamRef.current) {
      callStreamRef.current.getTracks().forEach((t) => t.stop());
      callStreamRef.current = null;
    }
    setCallMediaStream(null);
  }, []);

  // Broadcast microphone voice chunks in private call
  const startCallMicBroadcast = useCallback((stream: MediaStream, targetPartner: string) => {
    unlockAudio();
    stream.getAudioTracks().forEach((t) => {
      t.enabled = true;
    });
    try {
      const ctx = getAudioContext();
      if (ctx && ctx.state !== 'closed') {
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }
        const source = ctx.createMediaStreamSource(stream);
        callAudioSourceRef.current = source;
        const processor = ctx.createScriptProcessor(4096, 1, 1);
        callAudioProcessorRef.current = processor;
        let sampleBuffer: number[] = [];
        const targetSampleRate = 24000;
        const samplesPerChunk = 6000;
        processor.onaudioprocess = (e) => {
          if (!activeCallRef.current || activeCallRef.current.status !== 'connected' || activeCallRef.current.isMuted) {
            return;
          }
          const inputData = e.inputBuffer.getChannelData(0);
          let sumSquares = 0;
          for (let i = 0; i < inputData.length; i++) {
            sumSquares += inputData[i] * inputData[i];
          }
          const rms = Math.sqrt(sumSquares / inputData.length);
          if (rms > 0.015) {
            setIsMeSpeaking(true);
          } else {
            setIsMeSpeaking(false);
          }
          const downsampled = downsampleBuffer(inputData, ctx.sampleRate, targetSampleRate);
          for (let i = 0; i < downsampled.length; i++) {
            sampleBuffer.push(downsampled[i]);
          }
          if (sampleBuffer.length >= samplesPerChunk) {
            const chunkSamples = new Float32Array(sampleBuffer);
            sampleBuffer = [];
            const wavBuffer = encodeWav(chunkSamples, targetSampleRate);
            const base64 = arrayBufferToBase64(wavBuffer);
            if (clientRef.current?.connected) {
              publish('call', {
                type: 'call_voice',
                target: targetPartner,
                caller: currentUserRef.current,
                audio: 'data:audio/wav;base64,' + base64,
              });
            }
          }
        };
        const zeroGain = ctx.createGain();
        zeroGain.gain.value = 0;
        source.connect(processor);
        processor.connect(zeroGain);
        zeroGain.connect(ctx.destination);
      }
    } catch (e) {
      console.warn('Call Web Audio capture error:', e);
    }
  }, [publish]);

  // Record user call for female task completion tracker
  const recordCallTaskProgress = useCallback((partner: string) => {
    const curUser = currentUserRef.current;
    if (!curUser) return;
    setCloudAccounts((prev) => {
      const myAcc = prev[curUser];
      if (!myAcc) return prev;
      const isFemale = myAcc.gender?.includes('أنثى');
      if (!isFemale) return prev;
      const called = myAcc.calledPartners ? [...myAcc.calledPartners] : [];
      if (!called.includes(partner)) {
        called.push(partner);
        const updated = {
          ...prev,
          [curUser]: {
            ...myAcc,
            calledPartners: called,
          },
        };
        saveCloudAccounts(updated);
        publish('sync_account', { name: curUser, user: updated[curUser] });
        if (called.length >= 3 && !myAcc.completedTasks?.includes('call_3_users')) {
          showToast('تهانينا! لقد أكملتِ مهمة التحدث مع 3 مستخدمين. يمكنكِ استلام 8 ماسات الآن من صفحة المهمات! 💎');
        }
        return updated;
      }
      return prev;
    });
  }, [publish, saveCloudAccounts, showToast]);

  // Start 1-on-1 Voice Call
  const handleStartVoiceCall = useCallback(
    async (targetPartner: string) => {
      if (!currentUser) return;
      unlockAudio();
      const myAcc = cloudAccountsRef.current[currentUser];
      const partnerAcc = cloudAccountsRef.current[targetPartner];
      const isMaleCallingFemale = !myAcc?.gender?.includes('أنثى') && !!partnerAcc?.gender?.includes('أنثى');

      if (isMaleCallingFemale && currentCoins < 50) {
        showToast('رصيدك لا يكفي للاتصال، يتطلب 50 كوينز.');
        setShowBuyModal(true);
        return;
      }

      const callId = 'call_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      const newCall: ActiveCallSession = {
        callId,
        partner: targetPartner,
        status: 'calling',
        isCaller: true,
        callType: 'voice',
        durationSeconds: 0,
        costPerMinute: 50,
        diamondsPerMinute: 50,
        isMuted: false,
      };

      try {
        const stream = await getBestMicStream();
        callStreamRef.current = stream;
        setCallMediaStream(stream);
      } catch {}

      setActiveCall(newCall);
      playOutgoingDialTone(soundEnabledRef.current);
      publish('call', {
        type: 'call_request',
        callId,
        caller: currentUser,
        target: targetPartner,
        callType: 'voice',
        callerUser: myAcc,
      });
      showToast(`جاري الاتصال الصوتي بـ ${partnerAcc?.displayName || targetPartner}...`);
    },
    [currentUser, currentCoins, publish, showToast]
  );

  // Start 1-on-1 LIVE VIDEO Call (REQUESTED: اضيف ليا اتصل فيديو مباشر)
  const handleStartVideoCall = useCallback(
    async (targetPartner: string) => {
      if (!currentUser) return;
      unlockAudio();
      const myAcc = cloudAccountsRef.current[currentUser];
      const partnerAcc = cloudAccountsRef.current[targetPartner];
      const isMaleCallingFemale = !myAcc?.gender?.includes('أنثى') && !!partnerAcc?.gender?.includes('أنثى');

      if (isMaleCallingFemale && currentCoins < 50) {
        showToast('رصيدك لا يكفي لمكالمة الفيديو، يتطلب 50 كوينز.');
        setShowBuyModal(true);
        return;
      }

      const callId = 'vcall_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
      const newCall: ActiveCallSession = {
        callId,
        partner: targetPartner,
        status: 'calling',
        isCaller: true,
        callType: 'video',
        durationSeconds: 0,
        costPerMinute: 50,
        diamondsPerMinute: 50,
        isMuted: false,
        isVideoOff: false,
        isFrontCamera: true,
      };

      try {
        const stream = await getBestUserMedia(true);
        callStreamRef.current = stream;
        setCallMediaStream(stream);
      } catch {}

      setActiveCall(newCall);
      playOutgoingDialTone(soundEnabledRef.current);
      publish('call', {
        type: 'call_request',
        callId,
        caller: currentUser,
        target: targetPartner,
        callType: 'video',
        callerUser: myAcc,
      });
      showToast(`جاري الاتصال بالفيديو المباشر بـ ${partnerAcc?.displayName || targetPartner}...`);
    },
    [currentUser, currentCoins, publish, showToast]
  );

  // Accept incoming call (Voice or Video)
  const handleAcceptCall = useCallback(async () => {
    if (!activeCall || !currentUser) return;
    unlockAudio();
    const partner = activeCall.partner;
    const isVideo = activeCall.callType === 'video';

    publish('call', {
      type: 'call_accept',
      callId: activeCall.callId,
      caller: partner,
      target: partner,
      partner: currentUser,
      callType: activeCall.callType,
    });

    setActiveCall((prev) => (prev ? { ...prev, status: 'connected', startedAt: Date.now() } : null));

    try {
      const stream = isVideo ? await getBestUserMedia(true) : await getBestMicStream();
      callStreamRef.current = stream;
      setCallMediaStream(stream);
      startCallMicBroadcast(stream, partner);
    } catch {}

    // Track mission progress for female
    recordCallTaskProgress(partner);
    showToast('تم بدء المكالمة بنجاح.');
  }, [activeCall, currentUser, publish, showToast, startCallMicBroadcast, recordCallTaskProgress]);

  // Reject call
  const handleRejectCall = useCallback(() => {
    if (!activeCall) return;
    publish('call', {
      type: 'call_reject',
      callId: activeCall.callId,
      target: activeCall.partner,
      partner: currentUser,
    });
    playCallEndSound(soundEnabledRef.current);
    stopCallAudio();
    setActiveCall(null);
    showToast('تم رفض المكالمة');
  }, [activeCall, currentUser, publish, showToast, stopCallAudio]);

  // End call
  const handleEndCall = useCallback(() => {
    if (!activeCall) return;
    publish('call', {
      type: 'call_end',
      callId: activeCall.callId,
      target: activeCall.partner,
      partner: currentUser,
    });
    playCallEndSound(soundEnabledRef.current);
    stopCallAudio();
    setActiveCall(null);
    showToast('تم إنهاء المكالمة');
  }, [activeCall, currentUser, publish, showToast, stopCallAudio]);

  // Toggle call mute
  const handleToggleCallMute = useCallback(() => {
    setActiveCall((prev) => {
      if (!prev) return null;
      const nextMute = !prev.isMuted;
      if (callStreamRef.current) {
        callStreamRef.current.getAudioTracks().forEach((track) => {
          track.enabled = !nextMute;
        });
      }
      showToast(nextMute ? 'تم كتم الصوت' : 'تم تشغيل الصوت');
      return { ...prev, isMuted: nextMute };
    });
  }, [showToast]);

  // Toggle call video
  const handleToggleCallVideo = useCallback(() => {
    setActiveCall((prev) => {
      if (!prev) return null;
      const nextOff = !prev.isVideoOff;
      if (callStreamRef.current) {
        callStreamRef.current.getVideoTracks().forEach((track) => {
          track.enabled = !nextOff;
        });
      }
      showToast(nextOff ? 'تم إيقاف الكاميرا' : 'تم تشغيل الكاميرا');
      return { ...prev, isVideoOff: nextOff };
    });
  }, [showToast]);

  // Switch camera front/back
  const handleSwitchCallCamera = useCallback(async () => {
    if (!callStreamRef.current) return;
    const currentFront = activeCall?.isFrontCamera !== false;
    const nextFront = !currentFront;
    try {
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: nextFront ? 'user' : 'environment' },
        audio: true,
      });
      callStreamRef.current.getTracks().forEach((t) => t.stop());
      callStreamRef.current = newStream;
      setCallMediaStream(newStream);
      setActiveCall((prev) => (prev ? { ...prev, isFrontCamera: nextFront } : null));
      showToast('تم تبديل الكاميرا');
    } catch {}
  }, [activeCall?.isFrontCamera, showToast]);

  // Submit Verification Request
  const handleSubmitVerification = useCallback(
    (photos: { front: string; left: string; right: string; down: string }) => {
      if (!currentUser) return;
      const myAcc = cloudAccountsRef.current[currentUser];
      const newRequest: VerificationRequest = {
        id: 'vreq_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        username: currentUser,
        submittedAt: Date.now(),
        avatar: myAcc?.avatar,
        gender: myAcc?.gender,
        photos,
        status: 'pending',
      };

      setVerificationRequests((prev) => {
        const filtered = prev.filter((r) => r.username !== currentUser);
        const updated = [newRequest, ...filtered];
        saveVerificationRequests(updated);
        return updated;
      });

      setCloudAccounts((prev) => {
        const u = prev[currentUser];
        if (!u) return prev;
        const updatedUser: UserAccount = {
          ...u,
          verificationStatus: 'pending',
          verificationPhotos: photos,
        };
        const updated = { ...prev, [currentUser]: updatedUser };
        saveCloudAccounts(updated);
        publish('sync_account', { name: currentUser, user: updatedUser });
        return updated;
      });

      publish('verification', {
        type: 'submit',
        request: newRequest,
      });

      showToast('تم إرسال طلب التوثيق للإدارة بنجاح! سيتم مراجعته قريباً.');
    },
    [currentUser, publish, saveCloudAccounts, saveVerificationRequests, showToast]
  );

  // Admin Approve Verification
  const handleApproveVerification = useCallback(
    (targetUser: string) => {
      setCloudAccounts((prev) => {
        const u = prev[targetUser];
        if (!u) return prev;
        const updatedUser: UserAccount = {
          ...u,
          isVerified: true,
          verificationStatus: 'approved',
          verifiedAt: Date.now(),
        };
        const updated = { ...prev, [targetUser]: updatedUser };
        saveCloudAccounts(updated);
        publish('sync_account', { name: targetUser, user: updatedUser });
        publish('verification', {
          type: 'approved',
          target: targetUser,
        });
        return updated;
      });

      setVerificationRequests((prev) => {
        const updated = prev.map((r) =>
          r.username === targetUser ? { ...r, status: 'approved' as const } : r
        );
        saveVerificationRequests(updated);
        return updated;
      });

      showToast(`تم قبول توثيق حساب ${targetUser} بنجاح! تم اعتماد الشارة الزرقاء.`);
    },
    [publish, saveCloudAccounts, saveVerificationRequests, showToast]
  );

  // Admin Reject Verification
  const handleRejectVerification = useCallback(
    (targetUser: string) => {
      setCloudAccounts((prev) => {
        const u = prev[targetUser];
        if (!u) return prev;
        const updatedUser: UserAccount = {
          ...u,
          isVerified: false,
          verificationStatus: 'rejected',
        };
        const updated = { ...prev, [targetUser]: updatedUser };
        saveCloudAccounts(updated);
        publish('sync_account', { name: targetUser, user: updatedUser });
        publish('verification', {
          type: 'rejected',
          target: targetUser,
        });
        return updated;
      });

      setVerificationRequests((prev) => {
        const updated = prev.map((r) =>
          r.username === targetUser ? { ...r, status: 'rejected' as const } : r
        );
        saveVerificationRequests(updated);
        return updated;
      });

      showToast(`تم رفض طلب توثيق ${targetUser}. يمكنه إعادة التوثيق.`);
    },
    [publish, saveCloudAccounts, saveVerificationRequests, showToast]
  );

  // Claim Mission Task
  const handleClaimTask = useCallback(
    (taskId: string, rewardType: 'diamonds' | 'coins', amount: number) => {
      if (!currentUser) return;
      const myAcc = cloudAccountsRef.current[currentUser];
      if (!myAcc) return;

      if (rewardType === 'diamonds') {
        modifyUserDiamonds(currentUser, amount);
      } else {
        modifyUserCoins(currentUser, amount);
      }

      setCloudAccounts((prev) => {
        const u = prev[currentUser];
        if (!u) return prev;
        const completed = u.completedTasks ? [...u.completedTasks] : [];
        if (!completed.includes(taskId)) {
          completed.push(taskId);
        }
        const updatedUser: UserAccount = {
          ...u,
          completedTasks: completed,
        };
        const updated = { ...prev, [currentUser]: updatedUser };
        saveCloudAccounts(updated);
        publish('sync_account', { name: currentUser, user: updatedUser });
        return updated;
      });

      showToast(`تهانينا! تم استلام مكافأة المهمة (+${amount} ${rewardType === 'diamonds' ? 'ماسة 💎' : 'كوينز 🪙'})`);
    },
    [currentUser, modifyUserCoins, modifyUserDiamonds, publish, saveCloudAccounts, showToast]
  );

  // Call timer & periodic billing effect (50 coins per minute from male -> female)
  useEffect(() => {
    if (!activeCall || activeCall.status !== 'connected') return;
    const timer = setInterval(() => {
      setActiveCall((prev) => {
        if (!prev || prev.status !== 'connected') return prev;
        const nextDuration = prev.durationSeconds + 1;
        if (nextDuration > 0 && nextDuration % 60 === 0) {
          const curUser = currentUserRef.current;
          if (curUser && prev.isCaller) {
            const myAcc = cloudAccountsRef.current[curUser];
            const partnerAcc = cloudAccountsRef.current[prev.partner];
            const isMaleCallingFemale = !myAcc?.gender?.includes('أنثى') && !!partnerAcc?.gender?.includes('أنثى');
            if (isMaleCallingFemale) {
              const currentBalance = myAcc?.points || 0;
              if (currentBalance < 50) {
                publish('call', {
                  type: 'call_end',
                  callId: prev.callId,
                  target: prev.partner,
                  partner: curUser,
                  reason: 'insufficient_balance',
                });
                showToast('انتهى رصيدك! تم إنهاء المكالمة تلقائياً.');
                playCallEndSound(soundEnabledRef.current);
                stopCallAudio();
                return null;
              } else {
                modifyUserCoins(curUser, -50);
                modifyUserDiamonds(prev.partner, 50);
                showToast('تم خصم 50 كوينز للدقيقة (وصل للبنت 50 ماسة)');
              }
            }
          }
        }
        return { ...prev, durationSeconds: nextDuration };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [activeCall?.status, publish, showToast, modifyUserCoins, modifyUserDiamonds, stopCallAudio]);

  // Periodic ringtone for incoming or outgoing calls
  useEffect(() => {
    if (!activeCall) return;
    if (activeCall.status === 'ringing' || activeCall.status === 'calling') {
      const ringTimer = setInterval(() => {
        if (activeCall.status === 'ringing') {
          playRingtoneSound(soundEnabledRef.current);
        } else if (activeCall.status === 'calling') {
          playOutgoingDialTone(soundEnabledRef.current);
        }
      }, 2600);
      return () => clearInterval(ringTimer);
    }
  }, [activeCall?.status]);

  // Connect to MQTT
  useEffect(() => {
    const client = mqtt.connect(BROKER_URL);
    clientRef.current = client;

    client.on('connect', () => {
      setIsConnected(true);
      const subTopics = [
        'game',
        'users',
        'sync_account',
        'admin_points',
        'request_db',
        'session_kick',
        'dm',
        'gift',
        'control',
        'typing',
        'posts',
        'invite',
        'rooms',
        'rooms_voice',
        'room_chat',
        'room_music',
        'call',
        'verification',
      ];
      subTopics.forEach((s) => client.subscribe(`${ROOM_TOPIC}/${s}`, { qos: 1 }));
      client.publish(`${ROOM_TOPIC}/request_db`, JSON.stringify({ req: true }), { qos: 1 });
      const curUser = currentUserRef.current;
      if (curUser) {
        const uAcc = cloudAccountsRef.current[curUser];
        client.publish(
          `${ROOM_TOPIC}/users`,
          JSON.stringify({
            type: 'join',
            name: curUser,
            points: uAcc?.points || 50,
            user: uAcc,
          }),
          { qos: 1 }
        );
      }
    });

    client.on('offline', () => setIsConnected(false));
    client.on('error', () => setIsConnected(false));

    client.on('message', (topic, payload) => {
      try {
        const d = JSON.parse(payload.toString());
        const t = topic.toString();
        const myUser = currentUserRef.current;

        // VERIFICATION PROTOCOL (Admin approval & user notification)
        if (t.endsWith('/verification')) {
          if (d.type === 'submit' && d.request) {
            setVerificationRequests((prev) => {
              const filtered = prev.filter((r) => r.id !== d.request.id);
              const updated = [d.request, ...filtered];
              saveVerificationRequests(updated);
              return updated;
            });
            if (myUser === ADMIN_NAME || cloudAccountsRef.current[myUser || '']?.isAdmin) {
              showToast(`وصل طلب توثيق صور جديد من المستخدم: ${d.request.username}!`);
            }
          } else if (d.type === 'approved') {
            if (myUser && d.target === myUser) {
              setCloudAccounts((prev) => {
                const u = prev[myUser];
                if (!u) return prev;
                const updatedUser: UserAccount = { ...u, isVerified: true, verificationStatus: 'approved' };
                const updated = { ...prev, [myUser]: updatedUser };
                saveCloudAccounts(updated);
                return updated;
              });
              showToast('تهانينا! تم قبول طلب التوثيق الخاص بك بنجاح بعد موافقة الأدمن! أصبح حسابك موثقاً رسمياً 🌟');
            }
            setVerificationRequests((prev) => {
              const updated = prev.map((r) => (r.username === d.target ? { ...r, status: 'approved' as const } : r));
              saveVerificationRequests(updated);
              return updated;
            });
          } else if (d.type === 'rejected') {
            if (myUser && d.target === myUser) {
              setCloudAccounts((prev) => {
                const u = prev[myUser];
                if (!u) return prev;
                const updatedUser: UserAccount = { ...u, isVerified: false, verificationStatus: 'rejected' };
                const updated = { ...prev, [myUser]: updatedUser };
                saveCloudAccounts(updated);
                return updated;
              });
              showToast('تم رفض طلب التوثيق من قبل الإدارة. يمكنك إعادة التوثيق والتقاط الصور مرة أخرى.');
            }
            setVerificationRequests((prev) => {
              const updated = prev.map((r) => (r.username === d.target ? { ...r, status: 'rejected' as const } : r));
              saveVerificationRequests(updated);
              return updated;
            });
          }
        }
        // CALL PROTOCOL (Voice & Video Call)
        else if (t.endsWith('/call')) {
          if (!myUser) return;
          if (d.type === 'call_request' && d.target === myUser) {
            // Incoming Call
            if (activeCallRef.current || currentRoomRef.current) {
              publish('call', {
                type: 'call_reject',
                callId: d.callId,
                target: d.caller,
                partner: myUser,
                reason: 'busy',
              });
              return;
            }
            playRingtoneSound(soundEnabledRef.current);
            setActiveCall({
              callId: d.callId,
              partner: d.caller,
              status: 'ringing',
              isCaller: false,
              callType: d.callType === 'video' ? 'video' : 'voice',
              durationSeconds: 0,
              costPerMinute: 50,
              diamondsPerMinute: 50,
              isMuted: false,
              isVideoOff: false,
              isFrontCamera: true,
            });
          } else if (d.type === 'call_accept' && (d.target === myUser || d.caller === myUser) && activeCallRef.current?.callId === d.callId) {
            unlockAudio();
            const curCall = activeCallRef.current;
            if (!curCall) return;
            if (curCall.isCaller) {
              const myAcc = cloudAccountsRef.current[myUser];
              const partnerAcc = cloudAccountsRef.current[curCall.partner];
              const isMaleCallingFemale = !myAcc?.gender?.includes('أنثى') && !!partnerAcc?.gender?.includes('أنثى');
              if (isMaleCallingFemale) {
                modifyUserCoins(myUser, -50);
                modifyUserDiamonds(curCall.partner, 50);
                showToast('تم خصم 50 كوينز للدقيقة (وصل للبنت 50 ماسة)');
              }

              if (curCall.callType === 'video') {
                getBestUserMedia(true).then((stream) => {
                  callStreamRef.current = stream;
                  setCallMediaStream(stream);
                  startCallMicBroadcast(stream, curCall.partner);
                }).catch(() => {});
              } else {
                getBestMicStream().then((stream) => {
                  callStreamRef.current = stream;
                  setCallMediaStream(stream);
                  startCallMicBroadcast(stream, curCall.partner);
                }).catch(() => {});
              }
            }
            // Record call for mission progress
            recordCallTaskProgress(curCall.partner);
            setActiveCall((prev) => (prev ? { ...prev, status: 'connected', startedAt: Date.now() } : null));
            showToast(`تم الاتصال بـ ${curCall.partner}`);
          } else if (d.type === 'call_reject' && d.target === myUser) {
            playCallEndSound(soundEnabledRef.current);
            stopCallAudio();
            setActiveCall(null);
            showToast(d.reason === 'busy' ? `المستخدم ${d.partner} مشغول في مكالمة أخرى` : `تم رفض المكالمة من ${d.partner}`);
          } else if (d.type === 'call_end' && d.target === myUser) {
            playCallEndSound(soundEnabledRef.current);
            stopCallAudio();
            setActiveCall(null);
            showToast(d.reason === 'insufficient_balance' ? 'انتهى رصيد الكوينز!' : 'انتهت المكالمة');
          } else if (d.type === 'call_voice' && d.target === myUser && activeCallRef.current?.status === 'connected') {
            if (d.audio) {
              playRemoteAudioChunk(d.audio);
            }
          }
        }
        // SESSION KICK
        else if (t.endsWith('/session_kick')) {
          if (myUser && d.username === myUser && d.sessionId !== mySessionId) {
            playSecurityAlertSound(soundEnabledRef.current);
            setKickModalState({
              isOpen: true,
              username: myUser,
              reason: d.reason || (d.isBanned ? 'تم حظر الحساب' : undefined),
              isBanned: !!d.isBanned,
            });
          }
        } else if (t.endsWith('/sync_account')) {
          if (d.db) {
            setCloudAccounts((prev) => {
              const merged = { ...prev, ...d.db };
              localStorage.setItem('cloud_accounts_sync_v25', JSON.stringify(merged));
              return merged;
            });
            if (myUser && d.db[myUser]) {
              ingestInboxMessages(myUser, d.db[myUser]);
              if (d.db[myUser].isBanned) {
                playSecurityAlertSound(soundEnabledRef.current);
                setKickModalState({
                  isOpen: true,
                  username: myUser,
                  reason: d.db[myUser].banReason || 'تم حظر الحساب',
                  isBanned: true,
                });
              }
            }
          } else if (d.name && d.user) {
            setCloudAccounts((prev) => {
              const updated = { ...prev, [d.name]: d.user };
              localStorage.setItem('cloud_accounts_sync_v25', JSON.stringify(updated));
              return updated;
            });
            if (myUser && d.name === myUser) {
              ingestInboxMessages(myUser, d.user);
              if (d.user.isBanned) {
                playSecurityAlertSound(soundEnabledRef.current);
                setKickModalState({
                  isOpen: true,
                  username: myUser,
                  reason: d.user.banReason || 'تم حظر الحساب',
                  isBanned: true,
                });
              }
            }
          }
        } else if (t.endsWith('/request_db')) {
          setCloudAccounts((accs) => {
            publish('sync_account', { db: accs });
            return accs;
          });
          if (myUser) {
            publish('users', {
              type: 'ping',
              name: myUser,
              points: currentCoins,
              currentRoom: currentRoomRef.current || undefined,
              user: cloudAccountsRef.current[myUser],
            });
          }
        } else if (t.endsWith('/users')) {
          if (d.name) {
            const now = Date.now();
            setOnlineUsers((prev) => ({ ...prev, [d.name]: now }));
            setCloudAccounts((prev) => {
              const existing = prev[d.name];
              const updatedUser: UserAccount = existing
                ? {
                    ...existing,
                    points: d.points !== undefined ? d.points : existing.points,
                    currentRoom: d.currentRoom !== undefined ? d.currentRoom : existing.currentRoom,
                    ...(d.user || {}),
                  }
                : {
                    pass: 'pass123',
                    points: d.points !== undefined ? d.points : 50,
                    gender: d.user?.gender || 'أنثى 👩',
                    age: d.user?.age || 22,
                    bio: d.user?.bio || 'مرحباً بكم في حسابي!',
                    idNum: d.user?.idNum || String(Math.floor(10000000 + Math.random() * 90000000)),
                    country: d.user?.country || 'مصر',
                    countryFlag: d.user?.countryFlag || '🇪🇬',
                    displayName: d.user?.displayName || d.name,
                    isAdmin: d.user?.isAdmin || false,
                    isMod: d.user?.isMod || false,
                    avatar: d.user?.avatar || '',
                    mutedUntil: 0,
                    isBanned: false,
                    diamonds: 0,
                    following: [],
                    mutes: [],
                    status: 'online',
                    inbox: [],
                    currentRoom: d.currentRoom || undefined,
                    isVerified: false,
                    verificationStatus: 'none',
                    completedTasks: [],
                    calledPartners: [],
                    ...(d.user || {}),
                  };
              const merged = { ...prev, [d.name]: updatedUser };
              localStorage.setItem('cloud_accounts_sync_v25', JSON.stringify(merged));
              return merged;
            });
          }
        } else if (t.endsWith('/admin_points')) {
          if (d.target) {
            setCloudAccounts((prev) => {
              const acc = prev[d.target];
              if (!acc) return prev;
              const updated = { ...prev, [d.target]: { ...acc, points: d.newPts } };
              localStorage.setItem('cloud_accounts_sync_v25', JSON.stringify(updated));
              return updated;
            });
            if (d.target === myUser) {
              setCurrentCoins(d.newPts);
              showToast(`وصلك ${d.amount} كوينز من الإدارة!`);
            }
          }
        } else if (t.endsWith('/control')) {
          if (d.target) {
            setCloudAccounts((prev) => {
              const acc = prev[d.target];
              if (!acc) return prev;
              const next = { ...acc };
              if (d.mutedUntil !== undefined) next.mutedUntil = d.mutedUntil;
              if (d.isBanned !== undefined) {
                next.isBanned = d.isBanned;
                if (d.banReason) next.banReason = d.banReason;
              }
              if (d.pass !== undefined) next.pass = d.pass;
              if (d.isMod !== undefined) next.isMod = d.isMod;
              const updated = { ...prev, [d.target]: next };
              saveCloudAccounts(updated);
              return updated;
            });
            if (myUser && d.target === myUser) {
              if (d.isBanned) {
                playSecurityAlertSound(soundEnabledRef.current);
                setKickModalState({
                  isOpen: true,
                  username: myUser,
                  reason: d.banReason || 'تم حظر الحساب',
                  isBanned: true,
                });
              } else if (d.mutedUntil !== undefined) {
                showToast(d.mutedUntil > Date.now() ? 'تم كتمك من الإدارة' : 'تم إلغاء الكتم');
              }
            }
          }
        } else if (t.endsWith('/dm')) {
          if (!myUser) return;
          if (d.from === myUser || d.to === myUser) {
            const partner = d.from === myUser ? d.to : d.from;
            setDmHistory((prev) => {
              const list = prev[partner] || [];
              if (list.some((m) => m.id === d.id)) return prev;
              const nextList = [...list, d];
              const updated = { ...prev, [partner]: nextList };
              saveDmHistory(updated);
              return updated;
            });
            if (d.to === myUser) {
              playDmSound(soundEnabledRef.current);
              if (activeDmPartnerRef.current !== partner) {
                setUnreadDm((prev) => ({ ...prev, [partner]: (prev[partner] || 0) + 1 }));
              }
              const preview = d.text
                ? d.text.length > 25
                  ? d.text.slice(0, 25) + '...'
                  : d.text
                : d.type === 'gift'
                ? `أرسل لك هدية (${d.giftName})`
                : d.type === 'img'
                ? 'أرسل صورة'
                : d.type === 'voice'
                ? 'أرسل رسالة صوتية'
                : 'رسالة جديدة';
              showToast(`رسالة من ${partner}: ${preview}`);
            }
          }
        } else if (t.endsWith('/typing')) {
          if (d.to === myUser && d.name) {
            setTypingPartners((prev) => ({ ...prev, [d.name]: true }));
            setTimeout(() => {
              setTypingPartners((prev) => ({ ...prev, [d.name]: false }));
            }, 3000);
          }
        } else if (t.endsWith('/posts')) {
          if (d && d.from && d.from !== myUser) {
            setPostsFeed((prev) => {
              const updated = [d, ...prev.filter((p) => p.id !== d.id)].slice(0, 60);
              savePostsFeed(updated);
              return updated;
            });
          }
        } else if (t.endsWith('/rooms')) {
          if (d.type === 'hb') {
            if (d.owner && d.owner !== myUser) {
              setRoomHeartbeats((prev) => ({ ...prev, [d.owner]: Date.now() }));
              if (d.roomName) setRoomNames((prev) => ({ ...prev, [d.owner]: d.roomName }));
            }
          } else if (d.type === 'get') {
            if (isMyRoomAdminRef.current && d.owner === myUser) {
              publish('rooms', {
                type: 'state',
                room: myUser,
                seats: roomSeatsRef.current,
                mutes: roomMutesRef.current,
                lockedSeats: roomLockedSeatsRef.current,
                music: roomMusicStateRef.current,
                bg: roomBgRef.current,
                roomName: myRoomCustomNameRef.current,
              });
            }
          } else if (d.type === 'state') {
            if (d.room === currentRoomRef.current && !isMyRoomAdminRef.current) {
              if (d.roomName) setRoomNames((prev) => ({ ...prev, [d.room]: d.roomName }));
              if (d.seats) setRoomSeats(d.seats);
              if (d.mutes) setRoomMutes(d.mutes);
              if (d.lockedSeats) setRoomLockedSeats(d.lockedSeats);
              if (d.bg) setRoomBg(d.bg);
              if (d.music !== undefined) {
                setRoomMusicState(d.music);
                if (d.music && d.music.isPlaying && d.music.audioData) {
                  playRoomAudio(d.music.audioData);
                } else if (!d.music || !d.music.isPlaying) {
                  pauseRoomAudio();
                }
              }
            }
          } else if (d.type === 'take_seat') {
            if (isMyRoomAdminRef.current && d.room === myUser) {
              const s = parseInt(d.seat, 10);
              if (roomLockedSeatsRef.current[s]) {
                publish('rooms', { type: 'seat_rejected', room: myUser, target: d.name, reason: 'locked' });
                return;
              }
              setRoomSeats((prev) => {
                const updated = { ...prev };
                Object.keys(updated).forEach((k) => {
                  if (updated[k] === d.name) updated[k] = null;
                });
                if (!updated[s]) updated[s] = d.name;
                publish('rooms', {
                  type: 'state',
                  room: myUser,
                  seats: updated,
                  mutes: roomMutesRef.current,
                  lockedSeats: roomLockedSeatsRef.current,
                  music: roomMusicStateRef.current,
                  bg: roomBgRef.current,
                  roomName: myRoomCustomNameRef.current,
                });
                return updated;
              });
            }
          } else if (d.type === 'seat_rejected') {
            if (d.target === myUser && d.room === currentRoomRef.current) {
              showToast('المقعد مقفل من المضيف');
            }
          } else if (d.type === 'leave_seat') {
            if (isMyRoomAdminRef.current && d.room === myUser) {
              setRoomSeats((prev) => {
                const updated = { ...prev };
                if (updated[d.seat] === d.name) updated[d.seat] = null;
                publish('rooms', {
                  type: 'state',
                  room: myUser,
                  seats: updated,
                  mutes: roomMutesRef.current,
                  lockedSeats: roomLockedSeatsRef.current,
                  music: roomMusicStateRef.current,
                  bg: roomBgRef.current,
                  roomName: myRoomCustomNameRef.current,
                });
                return updated;
              });
            }
          } else if (d.type === 'kick') {
            if (!isMyRoomAdminRef.current && d.room === currentRoomRef.current && d.name === myUser) {
              playKickSound(soundEnabledRef.current);
              showToast('تم إنزالك من مقعد المايك');
              if (roomStreamRef.current) {
                roomStreamRef.current.getTracks().forEach((tr) => tr.stop());
                roomStreamRef.current = null;
              }
              setMyRoomSeatIdx(null);
              setIsRoomMicMuted(true);
            }
          } else if (d.type === 'admin_mute_user') {
            if (d.room === currentRoomRef.current) {
              setRoomMutes((prev) => ({ ...prev, [d.name]: d.muted }));
              if (d.name === myUser) {
                setIsRoomMicMuted(d.muted);
                if (roomStreamRef.current) {
                  roomStreamRef.current.getAudioTracks().forEach((track) => {
                    track.enabled = !d.muted;
                  });
                }
                showToast(d.muted ? 'تم كتم مايكك من المضيف' : 'تم تفعيل مايكك من المضيف');
              }
            }
          } else if (d.type === 'gift') {
            if (currentRoomRef.current !== null && (d.room === currentRoomRef.current || d.room === myUser)) {
              setFloatingGifts((prev) => [
                ...prev,
                { id: 'fg_' + Date.now(), room: d.room, from: d.from, to: d.to, gift: d.gift, giftName: d.giftName, msg: d.msg },
              ]);
              showToast(`أهدى ${d.from} هدية ${d.gift} إلى ${d.to}!`);
            }
          } else if (d.type === 'speaking') {
            if (d.room === currentRoomRef.current || (isMyRoomAdminRef.current && d.room === myUser)) {
              if (d.user && d.user !== myUser) {
                setSpeakingUsers((prev) => ({ ...prev, [d.user]: !!d.isSpeaking }));
              }
            }
          } else if (d.type === 'room_closed') {
            if (!isMyRoomAdminRef.current && d.room === currentRoomRef.current) {
              showToast('أغلق المضيف الغرفة الصوتية');
              leaveCurrentRoom();
            }
          }
        } else if (t.endsWith('/room_music')) {
          if (d.room === currentRoomRef.current || (isMyRoomAdminRef.current && d.room === myUser)) {
            if (d.type === 'play') {
              setRoomMusicState({
                isPlaying: true,
                title: d.title,
                audioData: d.audioData,
                playedBy: d.playedBy,
                timestamp: d.timestamp,
              });
              if (d.audioData) {
                playRoomAudio(d.audioData, 0.85);
              }
              showToast(`موسيقى: ${d.title}`);
            } else if (d.type === 'pause') {
              setRoomMusicState((prev) => (prev ? { ...prev, isPlaying: d.isPlaying } : null));
              if (d.isPlaying) {
                if (roomMusicStateRef.current?.audioData) {
                  playRoomAudio(roomMusicStateRef.current.audioData);
                }
              } else {
                pauseRoomAudio();
              }
            } else if (d.type === 'stop') {
              setRoomMusicState(null);
              stopRoomAudio();
              showToast('توقف تشغيل الموسيقى');
            }
          }
        } else if (t.endsWith('/rooms_voice')) {
          const curRoom = currentRoomRef.current;
          const isTargetRoom =
            d.room === curRoom ||
            (curRoom && String(d.room).trim().toLowerCase() === String(curRoom).trim().toLowerCase()) ||
            (isMyRoomAdminRef.current && (d.room === myUser || String(d.room).trim().toLowerCase() === String(myUser).trim().toLowerCase()));
          if (isTargetRoom && d.name !== myUser && d.audio) {
            if (!roomMutesRef.current[d.name]) {
              playRemoteAudioChunk(d.audio);
              setSpeakingUsers((prev) => ({ ...prev, [d.name]: true }));
              if (speakingTimersRef.current[d.name]) {
                clearTimeout(speakingTimersRef.current[d.name]);
              }
              speakingTimersRef.current[d.name] = setTimeout(() => {
                setSpeakingUsers((prev) => {
                  const next = { ...prev };
                  delete next[d.name];
                  return next;
                });
              }, 850);
            }
          }
        } else if (t.endsWith('/room_chat')) {
          if (d.room === currentRoomRef.current && d.from !== myUser) {
            setRoomChatLog((prev) => [...prev.slice(-200), d]);
            setFloatingTexts((prev) => [...prev.slice(-3), d]);
            setTimeout(() => {
              setFloatingTexts((prev) => prev.filter((item) => item.id !== d.id));
            }, 5000);
          }
        } else if (t.endsWith('/game')) {
          if (d.type === 'ttt_invite' && d.target === myUser) {
            publish('dm', {
              id: 'tttinv_' + Date.now(),
              from: d.sender,
              to: myUser,
              type: 'ttt_invite',
              gameId: d.gameId,
              stake: d.stake || 5,
              text: `دعاك ${d.sender} لتحدي لعبة X-O على ${d.stake || 5} كوينز`,
            });
          } else if (d.type === 'ttt_accept') {
            if (d.inviter === myUser) {
              setTttState((prev) => ({
                ...prev,
                gameId: d.gameId,
                active: true,
                waiting: false,
                board: Array(9).fill(''),
                myMark: 'X',
                opp: d.accepter,
                myTurn: true,
                stake: d.stake || 5,
              }));
              setActiveTab('dms');
              showToast('قبل الخصم التحدي! بدأ اللعب');
            }
          } else if (d.type === 'ttt_decline' && d.inviter === myUser) {
            setTttState((prev) => {
              if (prev.waiting && prev.stake) {
                modifyUserCoins(myUser, prev.stake);
                showToast(`رفض ${d.accepter} التحدي (+${prev.stake} كوينز)`);
              }
              return { ...prev, waiting: false, active: false };
            });
          } else if (d.type === 'ttt_move' && d.from !== myUser) {
            setTttState((prev) => {
              if (!prev.active || prev.gameId !== d.gameId) return prev;
              const nextBoard = [...prev.board];
              nextBoard[d.i] = d.mark;
              const winMark = checkTttWinner(nextBoard);
              if (winMark === 'draw') {
                finishTtt(null, prev.stake, prev.opp, false);
                return { ...prev, board: nextBoard, active: false };
              } else if (winMark) {
                finishTtt(d.from, prev.stake, prev.opp, false);
                return { ...prev, board: nextBoard, active: false };
              } else {
                return { ...prev, board: nextBoard, myTurn: true };
              }
            });
          } else if (d.type === 'ttt_forfeit' && d.winner === myUser) {
            setTttState((prev) => {
              if (prev.active) finishTtt(myUser, prev.stake, prev.opp, false);
              return { ...prev, active: false };
            });
          }
        }
      } catch {
        // Ignore json parse error
      }
    });

    return () => {
      client.end();
    };
  }, [
    mySessionId,
    publish,
    playRemoteAudioChunk,
    showToast,
    modifyUserCoins,
    modifyUserDiamonds,
    ingestInboxMessages,
    leaveCurrentRoom,
    startCallMicBroadcast,
    stopCallAudio,
    recordCallTaskProgress,
  ]);

  // Ping presence & room status every 3 seconds
  useEffect(() => {
    if (!currentUser) return;
    const sendPing = () => {
      publish('users', {
        type: 'ping',
        name: currentUser,
        points: currentCoins,
        currentRoom: currentRoom || undefined,
        user: cloudAccountsRef.current[currentUser],
      });
    };
    sendPing();
    const interval = setInterval(sendPing, 3000);
    return () => clearInterval(interval);
  }, [currentUser, currentCoins, currentRoom, publish]);

  // Clean stale online users
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now();
      setOnlineUsers((prev) => {
        let changed = false;
        const next = { ...prev };
        Object.keys(next).forEach((u) => {
          if (now - next[u] > 300000) {
            delete next[u];
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Room host heartbeats
  useEffect(() => {
    if (!isMyRoomAdmin || !currentUser) return;
    const interval = setInterval(() => {
      publish('rooms', {
        type: 'hb',
        owner: currentUser,
        bg: roomBg,
        roomName: myRoomCustomName || `غرفة ${currentUser}`,
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [isMyRoomAdmin, currentUser, roomBg, myRoomCustomName, publish]);

  // Tic-Tac-Toe helpers
  const checkTttWinner = (b: string[]) => {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (const [a, c, e2] of lines) {
      if (b[a] && b[a] === b[c] && b[a] === b[e2]) return b[a];
    }
    return b.every((x) => !!x) ? 'draw' : null;
  };

  const finishTtt = (winner: string | null, stake: number, opp: string | null, announce: boolean) => {
    const prize = stake * 2 - 2;
    if (winner === currentUser) {
      modifyUserCoins(currentUser, prize);
      showToast(`فزت بالتحدي! حصلت على ${prize} كوينز!`);
    } else if (winner) {
      showToast(`خسرت التحدي (${stake} كوينز للفائز: ${winner})`);
    } else {
      modifyUserCoins(currentUser, stake);
      if (opp) modifyUserCoins(opp, stake);
      showToast(`تعادل! استردت الرهان (${stake} كوينز).`);
    }
    if (announce && opp) {
      const msg = winner
        ? `انتهى التحدي بفوز ${winner} (+${prize} كوينز)`
        : 'انتهى التحدي بالتعادل!';
      publish('dm', { id: 'tttend_' + Date.now(), sys: true, from: currentUser, to: opp, text: msg });
    }
  };

  // Broadcast microphone voice chunks in room
  const startRoomMicBroadcast = (stream: MediaStream) => {
    roomMicActiveRef.current = true;
    unlockAudio();
    stream.getAudioTracks().forEach((t) => {
      t.enabled = true;
    });
    if (roomAudioProcessorRef.current) {
      try {
        roomAudioProcessorRef.current.disconnect();
      } catch {}
      roomAudioProcessorRef.current = null;
    }
    if (roomAudioSourceRef.current) {
      try {
        roomAudioSourceRef.current.disconnect();
      } catch {}
      roomAudioSourceRef.current = null;
    }
    try {
      const ctx = getAudioContext();
      if (ctx && ctx.state !== 'closed') {
        if (ctx.state === 'suspended') {
          ctx.resume().catch(() => {});
        }
        const source = ctx.createMediaStreamSource(stream);
        roomAudioSourceRef.current = source;
        const processor = ctx.createScriptProcessor(4096, 1, 1);
        roomAudioProcessorRef.current = processor;
        let sampleBuffer: number[] = [];
        const targetSampleRate = 24000;
        const samplesPerChunk = 6000;
        processor.onaudioprocess = (e) => {
          if (!roomMicActiveRef.current || isRoomMicMutedRef.current || !currentRoomRef.current) {
            return;
          }
          const u = currentUserRef.current;
          if (u && roomMutesRef.current[u]) return;
          const inputData = e.inputBuffer.getChannelData(0);
          let sumSquares = 0;
          for (let i = 0; i < inputData.length; i++) {
            sumSquares += inputData[i] * inputData[i];
          }
          const rms = Math.sqrt(sumSquares / inputData.length);
          if (rms > 0.015) {
            setIsMeSpeaking(true);
          } else {
            setIsMeSpeaking(false);
          }
          const downsampled = downsampleBuffer(inputData, ctx.sampleRate, targetSampleRate);
          for (let i = 0; i < downsampled.length; i++) {
            sampleBuffer.push(downsampled[i]);
          }
          if (sampleBuffer.length >= samplesPerChunk) {
            const chunkSamples = new Float32Array(sampleBuffer);
            sampleBuffer = [];
            const wavBuffer = encodeWav(chunkSamples, targetSampleRate);
            const base64 = arrayBufferToBase64(wavBuffer);
            const activeRoom = currentRoomRef.current;
            if (activeRoom && clientRef.current?.connected) {
              publish('rooms_voice', {
                room: activeRoom,
                name: currentUserRef.current,
                audio: 'data:audio/wav;base64,' + base64,
              });
            }
          }
        };
        const zeroGain = ctx.createGain();
        zeroGain.gain.value = 0;
        source.connect(processor);
        processor.connect(zeroGain);
        zeroGain.connect(ctx.destination);
      }
    } catch (e) {
      console.warn('Web Audio capture error:', e);
    }
  };

  // Take seat in room
  const handleTakeSeat = async (seatIdx: number) => {
    if (!currentRoom || !currentUser) return;
    if (roomSeats[seatIdx] === currentUser || roomSeats[String(seatIdx)] === currentUser) return;
    unlockAudio();
    setAudioActive(true);
    const isEffectiveAdmin = isMyRoomAdmin || currentRoom === currentUser;
    if (!isEffectiveAdmin && (roomLockedSeats[seatIdx] || roomLockedSeats[String(seatIdx)])) {
      showToast('المقعد مقفل');
      playLockSound(soundEnabled);
      return;
    }
    if (!isEffectiveAdmin && (roomSeats[seatIdx] || roomSeats[String(seatIdx)])) {
      showToast('المقعد مشغول');
      return;
    }
    setIsRoomMicMuted(false);
    isRoomMicMutedRef.current = false;
    roomMicActiveRef.current = true;
    if (!roomStreamRef.current) {
      getBestMicStream()
        .then((stream) => {
          roomStreamRef.current = stream;
          setIsRoomMicMuted(false);
          isRoomMicMutedRef.current = false;
          stream.getAudioTracks().forEach((t) => {
            t.enabled = true;
          });
          startRoomMicBroadcast(stream);
        })
        .catch(() => {});
    } else {
      roomStreamRef.current.getAudioTracks().forEach((t) => {
        t.enabled = true;
      });
      startRoomMicBroadcast(roomStreamRef.current);
    }
    setRoomSeats((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((k) => {
        if (updated[k] === currentUser) updated[k] = null;
      });
      updated[seatIdx] = currentUser;
      updated[String(seatIdx)] = currentUser;
      roomSeatsRef.current = updated;
      if (isEffectiveAdmin) {
        publish('rooms', {
          type: 'state',
          room: currentRoom || currentUser,
          seats: updated,
          mutes: roomMutesRef.current,
          lockedSeats: roomLockedSeatsRef.current,
          music: roomMusicStateRef.current,
          bg: roomBgRef.current,
          roomName: myRoomCustomNameRef.current || `غرفة ${currentRoom || currentUser}`,
        });
      }
      return updated;
    });
    setMyRoomSeatIdx(seatIdx);
    if (!isEffectiveAdmin) {
      publish('rooms', { type: 'take_seat', room: currentRoom, seat: seatIdx, name: currentUser });
    }
    playMicJoinSound(soundEnabled);
    showToast(
      seatIdx === ROOM_SEAT_COUNT
        ? 'أنت على مقعد المضيف الرئيسي'
        : `جلست على المقعد ${seatIdx + 1}`
    );
  };

  // Toggle mic inside room
  const handleToggleRoomMic = async () => {
    if (currentUser && roomMutes[currentUser]) {
      showToast('أنت مكتوم في هذه الغرفة من المضيف');
      return;
    }
    const isEffectiveAdmin = isMyRoomAdmin || currentRoom === currentUser;
    if (myRoomSeatIdx === null && !isEffectiveAdmin) {
      const freeSeatKey = Object.keys(roomSeats).find((idxStr) => {
        const num = parseInt(idxStr, 10);
        return (
          num < ROOM_SEAT_COUNT &&
          !roomSeats[idxStr] &&
          !roomSeats[num] &&
          !roomLockedSeats[num] &&
          !roomLockedSeats[idxStr]
        );
      });
      if (freeSeatKey !== undefined) {
        handleTakeSeat(parseInt(freeSeatKey, 10));
      }
    }
    const nextState = !isRoomMicMuted;
    setIsRoomMicMuted(nextState);
    isRoomMicMutedRef.current = nextState;
    if (nextState) {
      roomMicActiveRef.current = false;
      try {
        if (roomRecorderRef.current && roomRecorderRef.current.state === 'recording') {
          roomRecorderRef.current.stop();
        }
      } catch {}
    } else {
      roomMicActiveRef.current = true;
    }
    if (roomStreamRef.current) {
      const tracks = roomStreamRef.current.getAudioTracks();
      tracks.forEach((t) => {
        t.enabled = !nextState;
      });
      if (!nextState) {
        startRoomMicBroadcast(roomStreamRef.current);
      }
    } else if (!nextState) {
      getBestMicStream()
        .then((stream) => {
          roomStreamRef.current = stream;
          stream.getAudioTracks().forEach((t) => {
            t.enabled = true;
          });
          startRoomMicBroadcast(stream);
        })
        .catch(() => {});
    }
    showToast(nextState ? 'تم كتم المايك' : 'تم فتح المايك');
    if (soundEnabled) {
      playBeep(nextState ? 350 : 700, 0.08, 0, true);
    }
  };

  // Admin lock/unlock seat
  const handleAdminToggleSeatLock = (seatIdx: number) => {
    const isEffectiveAdmin = isMyRoomAdmin || (currentRoom !== null && currentRoom === currentUser);
    if (!isEffectiveAdmin || !currentUser) return;
    const currentLock = !!roomLockedSeats[seatIdx] || !!roomLockedSeats[String(seatIdx)];
    const nextLockState = !currentLock;
    const updatedLockedSeats = {
      ...roomLockedSeats,
      [seatIdx]: nextLockState,
      [String(seatIdx)]: nextLockState,
    };
    roomLockedSeatsRef.current = updatedLockedSeats;
    setRoomLockedSeats(updatedLockedSeats);
    playLockSound(soundEnabled);
    publish('rooms', {
      type: 'state',
      room: currentRoom || currentUser,
      seats: roomSeatsRef.current,
      mutes: roomMutesRef.current,
      lockedSeats: updatedLockedSeats,
      music: roomMusicStateRef.current,
      bg: roomBgRef.current,
      roomName: myRoomCustomNameRef.current || `غرفة ${currentRoom || currentUser}`,
    });
    showToast(nextLockState ? `تم قفل المقعد ${seatIdx + 1}` : `تم فتح المقعد ${seatIdx + 1}`);
  };

  // Admin kick seat
  const handleAdminKickSeat = (seatIdx: number) => {
    const isEffectiveAdmin = isMyRoomAdmin || (currentRoom !== null && currentRoom === currentUser);
    if (!isEffectiveAdmin || !currentUser) return;
    const victim = roomSeats[seatIdx] || roomSeats[String(seatIdx)];
    if (victim) {
      playKickSound(soundEnabled);
      publish('rooms', { type: 'kick', room: currentRoom || currentUser, name: victim });
      const updatedSeats = { ...roomSeats, [seatIdx]: null, [String(seatIdx)]: null };
      roomSeatsRef.current = updatedSeats;
      setRoomSeats(updatedSeats);
      publish('rooms', {
        type: 'state',
        room: currentRoom || currentUser,
        seats: updatedSeats,
        mutes: roomMutesRef.current,
        lockedSeats: roomLockedSeatsRef.current,
        music: roomMusicStateRef.current,
        bg: roomBgRef.current,
        roomName: myRoomCustomNameRef.current || `غرفة ${currentRoom || currentUser}`,
      });
      showToast(`تم إنزال ${victim} من المقعد`);
    }
  };

  // Admin mute seat
  const handleAdminMuteSeat = (seatIdx: number) => {
    const isEffectiveAdmin = isMyRoomAdmin || (currentRoom !== null && currentRoom === currentUser);
    if (!isEffectiveAdmin || !currentUser) return;
    const victim = roomSeats[seatIdx] || roomSeats[String(seatIdx)];
    if (victim) {
      const isCurrentlyMuted = !!roomMutes[victim];
      const nextMutes = { ...roomMutes, [victim]: !isCurrentlyMuted };
      roomMutesRef.current = nextMutes;
      setRoomMutes(nextMutes);
      publish('rooms', {
        type: 'admin_mute_user',
        room: currentRoom || currentUser,
        name: victim,
        muted: !isCurrentlyMuted,
      });
      publish('rooms', {
        type: 'state',
        room: currentRoom || currentUser,
        seats: roomSeatsRef.current,
        mutes: nextMutes,
        lockedSeats: roomLockedSeatsRef.current,
        music: roomMusicStateRef.current,
        bg: roomBgRef.current,
        roomName: myRoomCustomNameRef.current || `غرفة ${currentRoom || currentUser}`,
      });
      showToast(!isCurrentlyMuted ? `تم كتم مايك ${victim}` : `تم فتح مايك ${victim}`);
    }
  };

  // Play file from device in room
  const handlePlayDeviceMusic = (file: File) => {
    if (!currentRoom || !currentUser) return;
    showToast(`جاري تجهيز ${file.name}...`);
    const reader = new FileReader();
    reader.onload = (e) => {
      const audioData = e.target?.result as string;
      if (!audioData) return;
      const musicState: RoomMusicState = {
        isPlaying: true,
        title: file.name.replace(/\.[^/.]+$/, ''),
        audioData,
        playedBy: currentUser,
        timestamp: Date.now(),
      };
      setRoomMusicState(musicState);
      playRoomAudio(audioData, roomMusicVolume);
      const targetRoom = isMyRoomAdmin ? currentUser : currentRoom;
      publish('room_music', {
        type: 'play',
        room: targetRoom,
        ...musicState,
      });
      showToast(`يعمل الآن: ${musicState.title}`);
    };
    reader.readAsDataURL(file);
  };

  // Play demo music in room
  const handlePlayDemoMusic = (songId: string, title: string) => {
    if (!currentRoom || !currentUser) return;
    const musicState: RoomMusicState = {
      isPlaying: true,
      title,
      audioData: '',
      playedBy: currentUser,
      timestamp: Date.now(),
    };
    setRoomMusicState(musicState);
    const notes = [392, 440, 523, 587, 659, 784, 880];
    notes.forEach((freq, idx) => {
      playBeep(freq, 0.4, idx * 0.35, true);
    });
    const targetRoom = isMyRoomAdmin ? currentUser : currentRoom;
    publish('room_music', {
      type: 'play',
      room: targetRoom,
      ...musicState,
    });
    showToast(`يعمل الآن: ${title}`);
  };

  // Stop room music
  const handleStopRoomMusic = () => {
    if (!currentRoom || !currentUser) return;
    setRoomMusicState(null);
    stopRoomAudio();
    const targetRoom = isMyRoomAdmin ? currentUser : currentRoom;
    publish('room_music', {
      type: 'stop',
      room: targetRoom,
    });
    showToast('تم إيقاف الموسيقى');
  };

  // Toggle pause room music
  const handleTogglePauseRoomMusic = () => {
    if (!currentRoom || !currentUser || !roomMusicState) return;
    const nextState = !roomMusicState.isPlaying;
    setRoomMusicState((prev) => (prev ? { ...prev, isPlaying: nextState } : null));
    if (nextState) {
      if (roomMusicState.audioData) playRoomAudio(roomMusicState.audioData);
    } else {
      pauseRoomAudio();
    }
    const targetRoom = isMyRoomAdmin ? currentUser : currentRoom;
    publish('room_music', {
      type: 'pause',
      room: targetRoom,
      isPlaying: nextState,
    });
  };

  // Volume
  const handleSetRoomMusicVolume = (vol: number) => {
    const clamped = Math.max(0, Math.min(1, Math.round(vol * 100) / 100));
    setRoomMusicVolume(clamped);
    setRoomAudioVolume(clamped);
  };

  // Create room
  const handleCreateRoom = (roomName: string) => {
    if (!currentUser) return;
    unlockAudio();
    setAudioActive(true);
    const roomTitle = roomName.trim() || `غرفة ${currentUser}`;
    setMyRoomCustomName(roomTitle);
    myRoomCustomNameRef.current = roomTitle;
    setIsMyRoomAdmin(true);
    isMyRoomAdminRef.current = true;
    setIsRoomMinimized(false);
    setCurrentRoom(currentUser);
    currentRoomRef.current = currentUser;
    const initialSeats: Record<number | string, string | null> = {};
    for (let i = 0; i < ROOM_SEAT_COUNT; i++) {
      initialSeats[i] = null;
      initialSeats[String(i)] = null;
    }
    initialSeats[ROOM_SEAT_COUNT] = currentUser;
    initialSeats[String(ROOM_SEAT_COUNT)] = currentUser;
    setRoomSeats(initialSeats);
    roomSeatsRef.current = initialSeats;
    setRoomLockedSeats({});
    roomLockedSeatsRef.current = {};
    setMyRoomSeatIdx(ROOM_SEAT_COUNT);
    setCloudAccounts((prev) => {
      const u = prev[currentUser];
      if (!u) return prev;
      const updated = { ...prev, [currentUser]: { ...u, currentRoom: roomTitle } };
      saveCloudAccounts(updated);
      publish('sync_account', { name: currentUser, user: updated[currentUser] });
      return updated;
    });
    setIsRoomMicMuted(false);
    isRoomMicMutedRef.current = false;
    getBestMicStream()
      .then((stream) => {
        roomStreamRef.current = stream;
        setIsRoomMicMuted(false);
        isRoomMicMutedRef.current = false;
        startRoomMicBroadcast(stream);
      })
      .catch(() => {});
    publish('rooms', {
      type: 'state',
      room: currentUser,
      seats: initialSeats,
      mutes: {},
      lockedSeats: {},
      music: null,
      bg: roomBg,
      roomName: roomTitle,
    });
    showToast('تم فتح الغرفة بنجاح!');
  };

  // Join room
  const handleJoinRoom = (owner: string) => {
    unlockAudio();
    setAudioActive(true);
    setCurrentRoom(owner);
    currentRoomRef.current = owner;
    const isOwner = owner === currentUser;
    setIsMyRoomAdmin(isOwner);
    isMyRoomAdminRef.current = isOwner;
    setIsRoomMinimized(false);
    setMyRoomSeatIdx(isOwner ? ROOM_SEAT_COUNT : null);
    if (isOwner) {
      setIsRoomMicMuted(false);
      isRoomMicMutedRef.current = false;
      roomMicActiveRef.current = true;
      if (!roomStreamRef.current) {
        getBestMicStream()
          .then((stream) => {
            roomStreamRef.current = stream;
            stream.getAudioTracks().forEach((t) => {
              t.enabled = true;
            });
            startRoomMicBroadcast(stream);
          })
          .catch(() => {});
      } else {
        roomStreamRef.current.getAudioTracks().forEach((t) => {
          t.enabled = true;
        });
        startRoomMicBroadcast(roomStreamRef.current);
      }
    }
    if (currentUser) {
      setCloudAccounts((prev) => {
        const u = prev[currentUser];
        if (!u) return prev;
        const targetRoomName = roomNames[owner] || `غرفة ${owner}`;
        const updated = { ...prev, [currentUser]: { ...u, currentRoom: targetRoomName } };
        saveCloudAccounts(updated);
        publish('sync_account', { name: currentUser, user: updated[currentUser] });
        return updated;
      });
    }
    publish('rooms', { type: 'get', owner });
  };

  // DM Text
  const handleSendDmText = (text: string) => {
    if (!activeDmPartner || !currentUser) return;
    const userAcc = cloudAccounts[currentUser];
    if (userAcc?.mutedUntil && userAcc.mutedUntil > Date.now()) {
      showToast('أنت ممنوع من المراسلة حالياً');
      return;
    }
    const partnerAcc = cloudAccounts[activeDmPartner];
    if (partnerAcc?.mutes?.includes(currentUser)) {
      showToast('لا يمكن إرسال الرسالة');
      return;
    }
    const isSenderMale = !userAcc?.gender?.includes('أنثى');
    const isReceiverFemale = !!partnerAcc?.gender?.includes('أنثى');
    if (isSenderMale && isReceiverFemale) {
      if (currentCoins < 5) {
        showToast('رصيدك غير كافٍ. يتطلب 5 كوينز.');
        setShowBuyModal(true);
        return;
      }
      modifyUserCoins(currentUser, -5);
      modifyUserDiamonds(activeDmPartner, 3);
    }
    const msg: DirectMessage = {
      id: 'dm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      from: currentUser,
      to: activeDmPartner,
      text,
      timestamp: Date.now(),
    };
    publish('dm', msg);
    setDmHistory((prev) => {
      const list = prev[activeDmPartner] || [];
      const updated = { ...prev, [activeDmPartner]: [...list, msg] };
      saveDmHistory(updated);
      return updated;
    });
  };

  // DM Image
  const handleSendDmImage = (file: File) => {
    if (!activeDmPartner || !currentUser) return;
    if (file.size > 280 * 1024) {
      showToast('الحد الأقصى للصورة 280KB');
      return;
    }
    const userAcc = cloudAccounts[currentUser];
    const partnerAcc = cloudAccounts[activeDmPartner];
    const isSenderMale = !userAcc?.gender?.includes('أنثى');
    const isReceiverFemale = !!partnerAcc?.gender?.includes('أنثى');
    if (isSenderMale && isReceiverFemale) {
      if (currentCoins < 5) {
        showToast('رصيدك غير كافٍ. يتطلب 5 كوينز.');
        setShowBuyModal(true);
        return;
      }
      modifyUserCoins(currentUser, -5);
      modifyUserDiamonds(activeDmPartner, 3);
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const imgData = ev.target?.result as string;
      const msg: DirectMessage = {
        id: 'dmimg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        from: currentUser,
        to: activeDmPartner,
        type: 'img',
        img: imgData,
        timestamp: Date.now(),
      };
      publish('dm', msg);
      setDmHistory((prev) => {
        const list = prev[activeDmPartner] || [];
        const updated = { ...prev, [activeDmPartner]: [...list, msg] };
        saveDmHistory(updated);
        return updated;
      });
    };
    reader.readAsDataURL(file);
  };

  // DM Voice
  const handleSendDmVoice = (audioBase64: string) => {
    if (!activeDmPartner || !currentUser) return;
    const userAcc = cloudAccounts[currentUser];
    const partnerAcc = cloudAccounts[activeDmPartner];
    const isSenderMale = !userAcc?.gender?.includes('أنثى');
    const isReceiverFemale = !!partnerAcc?.gender?.includes('أنثى');
    if (isSenderMale && isReceiverFemale) {
      if (currentCoins < 5) {
        showToast('رصيدك غير كافٍ. يتطلب 5 كوينز.');
        setShowBuyModal(true);
        return;
      }
      modifyUserCoins(currentUser, -5);
      modifyUserDiamonds(activeDmPartner, 3);
    }
    const msg: DirectMessage = {
      id: 'dmvoice_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      from: currentUser,
      to: activeDmPartner,
      type: 'voice',
      audio: audioBase64,
      timestamp: Date.now(),
    };
    publish('dm', msg);
    setDmHistory((prev) => {
      const list = prev[activeDmPartner] || [];
      const updated = { ...prev, [activeDmPartner]: [...list, msg] };
      saveDmHistory(updated);
      return updated;
    });
    showToast('تم إرسال الرسالة الصوتية');
  };

  // Send Gift
  const handleSendGift = (gift: GiftOption, target: string, customMsg?: string) => {
    if (!currentUser) return;
    if (currentCoins < gift.cost) {
      showToast(`رصيدك غير كافٍ! تحتاج ${gift.cost} كوينز.`);
      return;
    }
    modifyUserCoins(currentUser, -gift.cost);
    const targetAcc = cloudAccounts[target];
    if (targetAcc?.gender?.includes('أنثى')) {
      const diamondReward = Math.max(3, Math.round(gift.cost * 0.6));
      modifyUserDiamonds(target, diamondReward);
    }
    if (giftModalIsRoom && currentRoom) {
      publish('rooms', {
        type: 'gift',
        room: isMyRoomAdmin ? currentUser : currentRoom,
        from: currentUser,
        to: target,
        gift: gift.e,
        giftName: gift.n,
        msg: customMsg || '',
      });
      setFloatingGifts((prev) => [
        ...prev,
        {
          id: 'fg_' + Date.now(),
          room: currentRoom,
          from: currentUser,
          to: target,
          gift: gift.e,
          giftName: gift.n,
          msg: customMsg || '',
        },
      ]);
      showToast(`أرسلت هدية ${gift.e} ${gift.n} إلى ${target}!`);
    } else {
      const giftMsg: DirectMessage = {
        id: 'gift_' + Date.now(),
        from: currentUser,
        to: target,
        type: 'gift',
        gift: gift.e,
        giftName: gift.n,
        amount: gift.cost,
        timestamp: Date.now(),
      };
      publish('dm', giftMsg);
      setDmHistory((prev) => {
        const list = prev[target] || [];
        const updated = { ...prev, [target]: [...list, giftMsg] };
        saveDmHistory(updated);
        return updated;
      });
      showToast(`أرسلت ${gift.e} ${gift.n} إلى ${target}`);
    }
  };

  // Tic-Tac-Toe
  const handleInvitePlayerTtt = (target: string, stake: number) => {
    if (!currentUser) return;
    if (currentCoins < stake) {
      showToast(`رصيدك لا يكفي (${stake} كوينز)!`);
      return;
    }
    modifyUserCoins(currentUser, -stake);
    const gameId = 'g_' + Date.now();
    setTttState({
      gameId,
      active: false,
      waiting: true,
      board: Array(9).fill(''),
      myMark: 'X',
      opp: target,
      myTurn: false,
      stake,
      waitDeadline: Date.now() + 60000,
    });
    publish('game', { type: 'ttt_invite', sender: currentUser, target, gameId, stake });
    showToast(`تم إرسال التحدي إلى ${target} على ${stake} كوينز`);
  };

  const handleRespondTtt = (inviteId: string, fromUser: string, action: 'accept' | 'decline') => {
    if (!currentUser) return;
    setDmHistory((prev) => {
      const list = prev[fromUser] || [];
      const updated = list.map((m) => (m.id === inviteId ? { ...m, handled: true } : m));
      saveDmHistory({ ...prev, [fromUser]: updated });
      return { ...prev, [fromUser]: updated };
    });
    if (action === 'accept') {
      const msg = (dmHistory[fromUser] || []).find((m) => m.id === inviteId);
      const stake = msg?.stake || 5;
      if (currentCoins < stake) {
        showToast(`رصيدك لا يكفي (${stake} كوينز)!`);
        return;
      }
      modifyUserCoins(currentUser, -stake);
      const gameId = msg?.gameId || 'g_' + Date.now();
      publish('game', { type: 'ttt_accept', inviter: fromUser, accepter: currentUser, gameId, stake });
      setTttState({
        gameId,
        active: true,
        waiting: false,
        board: Array(9).fill(''),
        myMark: 'O',
        opp: fromUser,
        myTurn: false,
        stake,
        waitDeadline: 0,
      });
      setActiveTab('dms');
      showToast('قبلت التحدي! دور الخصم أولاً');
    } else {
      publish('game', { type: 'ttt_decline', inviter: fromUser, accepter: currentUser });
      showToast('تم رفض التحدي');
    }
  };

  const handlePlayTttCell = (index: number) => {
    if (!tttState.active || !tttState.myTurn || tttState.board[index] || !currentUser) return;
    const nextBoard = [...tttState.board];
    nextBoard[index] = tttState.myMark;
    publish('game', {
      type: 'ttt_move',
      gameId: tttState.gameId,
      from: currentUser,
      mark: tttState.myMark,
      i: index,
    });
    const winMark = checkTttWinner(nextBoard);
    if (winMark === 'draw') {
      finishTtt(null, tttState.stake, tttState.opp, true);
      setTttState((prev) => ({ ...prev, board: nextBoard, active: false }));
    } else if (winMark) {
      finishTtt(currentUser, tttState.stake, tttState.opp, true);
      setTttState((prev) => ({ ...prev, board: nextBoard, active: false }));
    } else {
      setTttState((prev) => ({ ...prev, board: nextBoard, myTurn: false }));
    }
  };

  const handleExitTtt = () => {
    if (tttState.active && tttState.opp && currentUser) {
      publish('game', {
        type: 'ttt_forfeit',
        gameId: tttState.gameId,
        loser: currentUser,
        winner: tttState.opp,
      });
      finishTtt(tttState.opp, tttState.stake, tttState.opp, true);
    }
    setTttState((prev) => ({ ...prev, active: false, waiting: false }));
  };

  // Follow / Mute
  const handleToggleFollow = (targetName: string) => {
    if (!currentUser) return;
    setCloudAccounts((prev) => {
      const myAcc = prev[currentUser];
      if (!myAcc) return prev;
      const following = myAcc.following ? [...myAcc.following] : [];
      const idx = following.indexOf(targetName);
      if (idx > -1) {
        following.splice(idx, 1);
        showToast(`ألغيت متابعة ${targetName}`);
      } else {
        following.push(targetName);
        showToast(`أنت الآن تتابع ${targetName}!`);
        publish('dm', {
          id: 'follow_' + Date.now(),
          sys: true,
          from: currentUser,
          to: targetName,
          text: `بدأ ${currentUser} بمتابعتك!`,
        });
      }
      const updated = { ...prev, [currentUser]: { ...myAcc, following } };
      saveCloudAccounts(updated);
      publish('sync_account', { name: currentUser, user: updated[currentUser] });
      return updated;
    });
  };

  const handleToggleMuteUser = (targetName: string) => {
    if (!currentUser) return;
    setCloudAccounts((prev) => {
      const myAcc = prev[currentUser];
      if (!myAcc) return prev;
      const mutes = myAcc.mutes ? [...myAcc.mutes] : [];
      const idx = mutes.indexOf(targetName);
      if (idx > -1) {
        mutes.splice(idx, 1);
        showToast(`ألغيت كتم ${targetName}`);
      } else {
        mutes.push(targetName);
        showToast(`تم كتم ${targetName}`);
      }
      const updated = { ...prev, [currentUser]: { ...myAcc, mutes } };
      saveCloudAccounts(updated);
      publish('sync_account', { name: currentUser, user: updated[currentUser] });
      return updated;
    });
  };

  // If not logged in, show AuthScreen
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 text-white font-sans" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
        <AuthScreen
          cloudAccounts={cloudAccounts}
          lang={lang}
          onLoginSuccess={(name, acc) => {
            handleSetCurrentUser(name);
            setCurrentCoins(acc.points || 50);
            if (acc.preferredLang) setLang(acc.preferredLang);
            publish('session_kick', { username: name, sessionId: mySessionId });
            publish('users', { type: 'join', name, points: acc.points || 50, user: acc });
            ingestInboxMessages(name, acc);
            showToast(`أهلاً بك يا ${name}!`);
          }}
          onRegisterAccount={(name, acc) => {
            setCloudAccounts((prev) => {
              const updated = { ...prev, [name]: acc };
              saveCloudAccounts(updated);
              publish('sync_account', { name, user: acc });
              return updated;
            });
            handleSetCurrentUser(name);
            setCurrentCoins(acc.points || 50);
            publish('session_kick', { username: name, sessionId: mySessionId });
            publish('users', { type: 'join', name, points: acc.points || 50, user: acc });
            showToast(`أهلاً بك يا ${name}!`);
            if (acc.invitedBy) {
              publish('invite', { type: 'joined', inviter: acc.invitedBy, friend: name });
            }
          }}
        />
        <Toast message={toastMessage} />
      </div>
    );
  }

  const currentUserAccount = cloudAccounts[currentUser];
  const totalUnreadCount = Object.values(unreadDm).reduce((a, b) => a + b, 0);

  return (
    <div
      className="h-screen bg-slate-950 text-slate-100 font-sans selection:bg-purple-500 selection:text-white flex flex-col items-center overflow-hidden"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="w-full max-w-lg h-full bg-slate-950 flex flex-col relative shadow-2xl border-x border-purple-900/10 overflow-hidden">
        {/* Top Header */}
        <Header
          currentUser={currentUser}
          account={currentUserAccount}
          coins={currentCoins}
          soundEnabled={soundEnabled}
          audioActive={audioActive}
          isConnected={isConnected}
          lang={lang}
          onToggleSound={() => {
            const next = !soundEnabled;
            setSoundEnabled(next);
            localStorage.setItem('sound_on_v25', next ? '1' : '0');
            showToast(next ? 'تم تفعيل المؤثرات' : 'تم كتم المؤثرات');
          }}
          onEnableAudio={() => {
            getAudioContext();
            setAudioActive(true);
            showToast('تم تفعيل الصوت');
          }}
          onOpenAdmin={() => setShowAdminModal(true)}
        />

        {/* Tab Content Body */}
        <main
          className={`flex-1 flex flex-col min-h-0 ${
            activeTab === 'dms' && activeDmPartner
              ? 'p-0 overflow-hidden pb-16'
              : 'p-4 overflow-y-auto pb-20'
          }`}
        >
          {activeTab === 'chat' && (
            <OnlineUsersTab
              currentUser={currentUser}
              cloudAccounts={cloudAccounts}
              onlineUsers={onlineUsers}
              lang={lang}
              onOpenUserModal={(name) => setShowUserProfileModal(name)}
              onOpenDmWith={(name) => {
                setActiveDmPartner(name);
                setActiveTab('dms');
              }}
              onJoinRoom={handleJoinRoom}
            />
          )}

          {activeTab === 'rooms' && (
            <RoomsTab
              currentUser={currentUser}
              roomHeartbeats={roomHeartbeats}
              roomNames={roomNames}
              cloudAccounts={cloudAccounts}
              lang={lang}
              onOpenCreateModal={() => setShowCreateRoomModal(true)}
              onJoinRoom={handleJoinRoom}
              onEnterMyRoom={() => {
                setIsRoomMinimized(false);
                handleCreateRoom(myRoomCustomName || `غرفة ${currentUser}`);
              }}
              hasMyRoom={isMyRoomAdmin}
            />
          )}

          {activeTab === 'dms' && (
            <DMsTab
              currentUser={currentUser}
              currentCoins={currentCoins}
              cloudAccounts={cloudAccounts}
              onlineUsers={onlineUsers}
              dmHistory={dmHistory}
              unreadDm={unreadDm}
              activePartner={activeDmPartner}
              typingPartners={typingPartners}
              lang={lang}
              onSelectPartner={(partner) => {
                setActiveDmPartner(partner);
                setUnreadDm((prev) => ({ ...prev, [partner]: 0 }));
              }}
              onCloseConversation={() => setActiveDmPartner(null)}
              onSendTextMessage={handleSendDmText}
              onSendVoiceMessage={handleSendDmVoice}
              onSendImageMessage={handleSendDmImage}
              onStartVoiceCall={handleStartVoiceCall}
              onStartVideoCall={handleStartVideoCall}
              onOpenGiftModal={() => {
                setGiftModalIsRoom(false);
                setShowGiftModal(true);
              }}
              onOpenBuyModal={() => setShowBuyModal(true)}
              onOpenWithdrawModal={() => setShowWithdrawModal(true)}
              onNotifyTyping={() => {
                if (activeDmPartner) {
                  publish('typing', { name: currentUser, to: activeDmPartner });
                }
              }}
              onRespondTtt={handleRespondTtt}
              onViewImage={(url) => setLightboxImage(url)}
              onShowToast={showToast}
            />
          )}

          {activeTab === 'posts' && (
            <PostsTab
              currentUser={currentUser}
              cloudAccounts={cloudAccounts}
              posts={postsFeed}
              onPublishPost={(text, imgData) => {
                const newPost: PostItem = {
                  id: 'post_' + Date.now(),
                  from: currentUser,
                  text,
                  img: imgData,
                  ts: Date.now(),
                };
                const updated = [newPost, ...postsFeed].slice(0, 60);
                savePostsFeed(updated);
                publish('posts', newPost);
                showToast('تم النشر بنجاح!');
              }}
              onViewImage={(url) => setLightboxImage(url)}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileTab
              currentUser={currentUser}
              account={currentUserAccount}
              coins={currentCoins}
              lang={lang}
              onOpenGames={() => {
                setTttState((prev) => ({ ...prev, active: false }));
                setActiveTab('chat');
                showToast('اختر لاعباً لتحدي X-O');
              }}
              onOpenInvite={() => setShowInviteModal(true)}
              onOpenLevels={() => setShowLevelsModal(true)}
              onOpenEditProfile={() => setShowEditProfileModal(true)}
              onOpenVerification={() => setShowVerificationModal(true)}
              onOpenTasks={() => setShowTasksModal(true)}
              onOpenBuyCoins={() => setShowBuyModal(true)}
              onOpenWithdraw={() => setShowWithdrawModal(true)}
              onShowToast={showToast}
              onLogout={() => {
                handleSetCurrentUser(null);
                showToast('تم تسجيل الخروج');
              }}
              onChangeAvatar={(file) => {
                const reader = new FileReader();
                reader.onload = (ev) => {
                  const avatarData = ev.target?.result as string;
                  setCloudAccounts((prev) => {
                    const u = prev[currentUser];
                    if (!u) return prev;
                    const updated = { ...prev, [currentUser]: { ...u, avatar: avatarData } };
                    saveCloudAccounts(updated);
                    publish('sync_account', { name: currentUser, user: updated[currentUser] });
                    return updated;
                  });
                  showToast('تم تحديث الصورة الشخصية!');
                };
                reader.readAsDataURL(file);
              }}
            />
          )}
        </main>

        {/* Floating Mini-Bar when Room is Minimized */}
        {currentRoom !== null && isRoomMinimized && (
          <div className="fixed bottom-16 left-0 right-0 max-w-lg mx-auto z-40 px-3 py-2 bg-gradient-to-r from-purple-950/95 via-slate-900/95 to-slate-950/95 border-t border-purple-500/40 backdrop-blur-xl flex items-center justify-between gap-2 shadow-2xl">
            <div
              className="flex items-center gap-2 min-w-0 flex-1 cursor-pointer"
              onClick={() => setIsRoomMinimized(false)}
            >
              <div className="w-8 h-8 rounded-xl bg-purple-600/30 text-purple-300 flex items-center justify-center shrink-0 border border-purple-500/30">
                <Radio className="w-4 h-4 text-purple-400 animate-pulse" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-xs font-bold text-white truncate">
                  <span>{roomNames[currentRoom] || `غرفة ${currentRoom}`}</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                </div>
                {roomMusicState?.isPlaying ? (
                  <span className="text-[10px] text-pink-300 flex items-center gap-1 truncate font-medium">
                    <span>موسيقى: {roomMusicState.title}</span>
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-400 truncate block">
                    المضيف: {currentRoom} {myRoomSeatIdx !== null ? `(مايك ${myRoomSeatIdx === ROOM_SEAT_COUNT ? 'رئيسي' : myRoomSeatIdx + 1})` : '(مستمع)'}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={handleToggleRoomMic}
                className={`p-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isRoomMicMuted
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                }`}
                aria-label="مايك"
              >
                {isRoomMicMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
              </button>
              <button
                onClick={() => setIsRoomMinimized(false)}
                className="px-2.5 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md flex items-center gap-1 active:scale-95 cursor-pointer"
                title="تكبير الغرفة"
              >
                <ChevronUp className="w-3.5 h-3.5" />
                <span>تكبير</span>
              </button>
              <button
                onClick={leaveCurrentRoom}
                className="p-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs transition-all active:scale-95 cursor-pointer"
                title="مغادرة"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        <BottomNavigation
          currentTab={activeTab}
          unreadCount={totalUnreadCount}
          lang={lang}
          onTabChange={(tab) => {
            setActiveTab(tab);
            if (tab !== 'dms') setActiveDmPartner(null);
          }}
        />

        {/* Active Voice & Music Room Full-Screen Overlay */}
        {currentRoom !== null && !isRoomMinimized && (
          <ActiveRoomView
            currentUser={currentUser}
            roomName={currentRoom}
            roomTitle={roomNames[currentRoom] || `غرفة ${currentRoom}`}
            isOwner={isMyRoomAdmin || currentRoom === currentUser}
            roomSeats={roomSeats}
            roomMutes={roomMutes}
            roomLockedSeats={roomLockedSeats}
            roomMusicState={roomMusicState}
            roomBg={roomBg}
            cloudAccounts={cloudAccounts}
            roomChatLog={roomChatLog}
            mySeatIdx={myRoomSeatIdx}
            isMicMuted={isRoomMicMuted}
            isMeSpeaking={isMeSpeaking}
            speakingUsers={speakingUsers}
            onMinimizeRoom={() => setIsRoomMinimized(true)}
            onLeaveRoom={leaveCurrentRoom}
            onTakeSeat={handleTakeSeat}
            onToggleMic={handleToggleRoomMic}
            onAdminKick={handleAdminKickSeat}
            onAdminMute={handleAdminMuteSeat}
            onAdminToggleSeatLock={handleAdminToggleSeatLock}
            onOpenBgPicker={() => setShowRoomBgModal(true)}
            onOpenGiftModal={() => {
              setGiftModalIsRoom(true);
              setShowGiftModal(true);
            }}
            onSendChatMessage={(text) => {
              const msg: RoomChatMsg = {
                id: 'rc_' + Date.now(),
                room: isMyRoomAdmin ? currentUser : currentRoom,
                from: currentUser,
                text,
                ts: Date.now(),
              };
              publish('room_chat', msg);
              setRoomChatLog((prev) => [...prev.slice(-200), msg]);
              setFloatingTexts((prev) => [...prev.slice(-3), msg]);
              setTimeout(() => {
                setFloatingTexts((prev) => prev.filter((item) => item.id !== msg.id));
              }, 5000);
            }}
            floatingGifts={floatingGifts}
            floatingTexts={floatingTexts}
            onOpenXO={() => {
              showToast('افتح لعبة X-O من القائمة!');
            }}
            onPlayDeviceMusic={handlePlayDeviceMusic}
            onPlayDemoMusic={handlePlayDemoMusic}
            onStopRoomMusic={handleStopRoomMusic}
            onTogglePauseRoomMusic={handleTogglePauseRoomMusic}
            musicVolume={roomMusicVolume}
            onVolumeChange={handleSetRoomMusicVolume}
            onShowToast={showToast}
          />
        )}
      </div>

      {/* Floating Toast */}
      <Toast message={toastMessage} />

      {/* Session Kick Security Alert Modal */}
      {kickModalState?.isOpen && (
        <SessionKickModal
          username={kickModalState.username}
          reason={kickModalState.reason}
          isBanned={kickModalState.isBanned}
          onLogoutConfirm={handleKickLogoutConfirm}
        />
      )}

      {/* 1-on-1 Direct Voice or LIVE VIDEO Call Modal */}
      {activeCall && (
        <ActiveCallModal
          callSession={activeCall}
          partnerAccount={cloudAccounts[activeCall.partner]}
          myCoins={currentCoins}
          isMeFemale={!!currentUserAccount?.gender?.includes('أنثى')}
          isPartnerFemale={!!cloudAccounts[activeCall.partner]?.gender?.includes('أنثى')}
          lang={lang}
          localStream={callMediaStream}
          onAcceptCall={handleAcceptCall}
          onRejectCall={handleRejectCall}
          onEndCall={handleEndCall}
          onToggleMute={handleToggleCallMute}
          onToggleVideo={handleToggleCallVideo}
          onSwitchCamera={handleSwitchCallCamera}
          isSpeaking={isMeSpeaking}
        />
      )}

      {/* Verification Modal (REQUESTED: التحقق من الجنس وتصوير 4 زوايا 3 ثواني) */}
      {showVerificationModal && (
        <VerificationModal
          currentUser={currentUser}
          account={currentUserAccount}
          lang={lang}
          onClose={() => setShowVerificationModal(false)}
          onSubmitVerification={handleSubmitVerification}
          onUpdateAvatar={(file) => {
            const reader = new FileReader();
            reader.onload = (ev) => {
              const avatarData = ev.target?.result as string;
              setCloudAccounts((prev) => {
                const u = prev[currentUser];
                if (!u) return prev;
                const updated = { ...prev, [currentUser]: { ...u, avatar: avatarData } };
                saveCloudAccounts(updated);
                publish('sync_account', { name: currentUser, user: updated[currentUser] });
                return updated;
              });
              showToast('تم رفع صورة الملف الشخصي بنجاح!');
            };
            reader.readAsDataURL(file);
          }}
        />
      )}

      {/* Tasks Modal (REQUESTED: المهمات - كلم 3 مستخدمين واكسب 8 ماسات للبنات فقط) */}
      {showTasksModal && (
        <TasksModal
          currentUser={currentUser}
          account={currentUserAccount}
          lang={lang}
          onClose={() => setShowTasksModal(false)}
          onClaimTask={handleClaimTask}
          onOpenVerification={() => setShowVerificationModal(true)}
        />
      )}

      {/* Admin Modal with Verification Requests (مقبول / مرفوض) */}
      {showAdminModal && (
        <AdminModal
          currentUser={currentUser}
          account={currentUserAccount}
          cloudAccounts={cloudAccounts}
          verificationRequests={verificationRequests}
          onClose={() => setShowAdminModal(false)}
          onChangePassword={(target, newPass) => {
            setCloudAccounts((prev) => {
              const u = prev[target];
              if (!u) {
                showToast('المستخدم غير موجود');
                return prev;
              }
              const updated = { ...prev, [target]: { ...u, pass: newPass } };
              saveCloudAccounts(updated);
              publish('control', { target, pass: newPass });
              showToast(`تم تغيير كلمة المرور لـ ${target}`);
              return updated;
            });
          }}
          onToggleMod={(target) => {
            setCloudAccounts((prev) => {
              const u = prev[target];
              if (!u) {
                showToast('المستخدم غير موجود');
                return prev;
              }
              const nextMod = !u.isMod;
              const updated = { ...prev, [target]: { ...u, isMod: nextMod } };
              saveCloudAccounts(updated);
              publish('control', { target, isMod: nextMod });
              showToast(`تم تعيين ${target}: ${nextMod ? 'مشرف' : 'عضو عادي'}`);
              return updated;
            });
          }}
          onGrantPoints={(target, amount) => {
            modifyUserCoins(target, amount);
            showToast(`تم شحن ${amount} كوينز للمستخدم ${target}`);
          }}
          onMuteUser={(target, mins) => {
            const until = mins > 0 ? Date.now() + mins * 60000 : 0;
            setCloudAccounts((prev) => {
              const u = prev[target];
              if (!u) {
                showToast('المستخدم غير موجود');
                return prev;
              }
              const updated = { ...prev, [target]: { ...u, mutedUntil: until } };
              saveCloudAccounts(updated);
              publish('control', { target, mutedUntil: until });
              showToast(until ? `تم كتم ${target} لمدة ${mins} دقيقة` : `تم إلغاء كتم ${target}`);
              return updated;
            });
          }}
          onToggleBanUser={handleToggleBanUser}
          onApproveVerification={handleApproveVerification}
          onRejectVerification={handleRejectVerification}
          onViewImage={(url) => setLightboxImage(url)}
        />
      )}

      {showGiftModal && (
        <GiftModal
          isRoomMode={giftModalIsRoom}
          partnerName={activeDmPartner || ''}
          roomUsers={Object.values(roomSeats).filter((u): u is string => !!u && u !== currentUser)}
          myCoins={currentCoins}
          onClose={() => setShowGiftModal(false)}
          onSendGift={handleSendGift}
        />
      )}

      {showRoomBgModal && (
        <RoomBgModal
          currentBg={roomBg}
          onClose={() => setShowRoomBgModal(false)}
          onSelectBg={(css) => {
            setRoomBg(css);
            showToast('تم تغيير الخلفية بنجاح!');
            if (isMyRoomAdmin && currentUser) {
              publish('rooms', {
                type: 'state',
                room: currentUser,
                seats: roomSeats,
                mutes: roomMutes,
                lockedSeats: roomLockedSeats,
                music: roomMusicState,
                bg: css,
                roomName: myRoomCustomName,
              });
            }
          }}
          onUploadCustomBg={(file) => {
            const reader = new FileReader();
            reader.onload = (ev) => {
              const css = `url('${ev.target?.result}')`;
              setRoomBg(css);
              showToast('تم تطبيق الخلفية الجديدة!');
              if (isMyRoomAdmin && currentUser) {
                publish('rooms', {
                  type: 'state',
                  room: currentUser,
                  seats: roomSeats,
                  mutes: roomMutes,
                  lockedSeats: roomLockedSeats,
                  music: roomMusicState,
                  bg: css,
                  roomName: myRoomCustomName,
                });
              }
            };
            reader.readAsDataURL(file);
          }}
        />
      )}

      {showCreateRoomModal && (
        <CreateRoomModal
          onClose={() => setShowCreateRoomModal(false)}
          onCreateRoom={handleCreateRoom}
        />
      )}

      {showInviteModal && (
        <InviteModal
          idNum={currentUserAccount?.idNum || ''}
          myInvites={myInvites}
          onClose={() => setShowInviteModal(false)}
          onCopySuccess={() => showToast('تم نسخ كود الدعوة بنجاح!')}
        />
      )}

      {showLevelsModal && (
        <LevelsModal
          diamonds={currentUserAccount?.diamonds || 0}
          onClose={() => setShowLevelsModal(false)}
        />
      )}

      {showUserProfileModal && (
        <UserProfileModal
          targetUser={showUserProfileModal}
          account={cloudAccounts[showUserProfileModal]}
          isFollowing={!!currentUserAccount?.following?.includes(showUserProfileModal)}
          isMuted={!!currentUserAccount?.mutes?.includes(showUserProfileModal)}
          onClose={() => setShowUserProfileModal(null)}
          onToggleFollow={() => handleToggleFollow(showUserProfileModal)}
          onToggleMute={() => handleToggleMuteUser(showUserProfileModal)}
          onStartDm={() => {
            setActiveDmPartner(showUserProfileModal);
            setActiveTab('dms');
          }}
        />
      )}

      {showEditProfileModal && (
        <EditProfileModal
          account={currentUserAccount}
          currentUser={currentUser}
          lang={lang}
          onClose={() => setShowEditProfileModal(false)}
          onToggleLanguage={(newLang) => {
            setLang(newLang);
            showToast(newLang === 'ar' ? 'تم تحويل اللغة إلى العربية' : 'Language switched to English');
          }}
          onSave={(newAge, newBio, newCountry, newCountryFlag, newDisplayName, newLang) => {
            setLang(newLang);
            setCloudAccounts((prev) => {
              const u = prev[currentUser];
              if (!u) return prev;
              const updated = {
                ...prev,
                [currentUser]: {
                  ...u,
                  age: newAge,
                  bio: newBio,
                  country: newCountry,
                  countryFlag: newCountryFlag,
                  displayName: newDisplayName,
                  preferredLang: newLang,
                },
              };
              saveCloudAccounts(updated);
              publish('sync_account', { name: currentUser, user: updated[currentUser] });
              showToast(newLang === 'ar' ? 'تم حفظ التعديلات بنجاح' : 'Profile updated successfully');
              return updated;
            });
          }}
          onCopyId={() => {
            if (currentUserAccount?.idNum) {
              navigator.clipboard?.writeText(currentUserAccount.idNum);
              showToast(`تم نسخ ID: ${currentUserAccount.idNum}`);
            }
          }}
        />
      )}

      {showBuyModal && (
        <BuyCoinsModal
          myCoins={currentCoins}
          onClose={() => setShowBuyModal(false)}
          onRequestBuy={(pts) => {
            publish('dm', {
              id: 'req_' + Date.now(),
              sys: true,
              from: currentUser,
              to: ADMIN_NAME,
              text: `طلب شحن من ${currentUser}: ${pts} كوينز ($${(pts / 50).toFixed(2)})`,
            });
            showToast('تم إرسال طلب الشحن إلى الإدارة بنجاح');
          }}
        />
      )}

      {showWithdrawModal && (
        <WithdrawModal
          myDiamonds={currentUserAccount?.diamonds || 0}
          myCoins={currentCoins}
          onClose={() => setShowWithdrawModal(false)}
          onRequestWithdraw={(amt, method, details) => {
            if (!currentUser) return;
            modifyUserDiamonds(currentUser, -amt);
            publish('dm', {
              id: 'wdr_' + Date.now(),
              sys: true,
              from: currentUser,
              to: ADMIN_NAME,
              text: `طلب سحب كاش من ${currentUser}: ${amt} ماسة (${method || 'كاش'}) - بيانات الحساب: ${details || 'غير محدد'}`,
            });
            showToast(`تم إرسال طلب سحب ${amt} ماسة للإدارة بنجاح`);
          }}
          onConvertToCoins={(amt) => {
            if (!currentUser) return;
            modifyUserDiamonds(currentUser, -amt);
            modifyUserCoins(currentUser, amt);
            showToast(`تم تحويل ${amt} ماسة إلى ${amt} كوينز فوراً!`);
          }}
        />
      )}

      {lightboxImage && (
        <ImageLightboxModal
          imageUrl={lightboxImage}
          onClose={() => setLightboxImage(null)}
        />
      )}
    </div>
  );
}
