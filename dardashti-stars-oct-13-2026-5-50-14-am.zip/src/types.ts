export interface UserAccount {
  pass: string;
  points: number;
  gender: string;
  age: number;
  bio: string;
  idNum: string;
  displayName?: string;
  country?: string;
  countryFlag?: string;
  isAdmin?: boolean;
  isMod?: boolean;
  avatar?: string;
  mutedUntil?: number;
  isBanned?: boolean;
  banReason?: string;
  bannedAt?: number;
  diamonds?: number;
  following?: string[];
  mutes?: string[];
  invitedBy?: string;
  status?: 'online' | 'busy' | 'away';
  currentRoom?: string;
  inbox?: DirectMessage[];
  // Verification system
  isVerified?: boolean;
  verificationStatus?: 'none' | 'pending' | 'approved' | 'rejected';
  verifiedAt?: number;
  verificationPhotos?: {
    front: string;
    left: string;
    right: string;
    down: string;
  };
  // Tasks system
  completedTasks?: string[];
  calledPartners?: string[]; // tracks distinct users called for the mission
  // Localization
  preferredLang?: 'ar' | 'en';
}

export interface VerificationRequest {
  id: string;
  username: string;
  submittedAt: number;
  avatar?: string;
  gender?: string;
  photos: {
    front: string;
    left: string;
    right: string;
    down: string;
  };
  status: 'pending' | 'approved' | 'rejected';
}

export interface RoomDetail {
  owner: string;
  roomName: string;
  bg?: string;
  seatsCount: number;
  occupantsCount: number;
  lockedCount: number;
  currentSong?: string;
  lastSeen: number;
}

export interface DirectMessage {
  id: string;
  from: string;
  to: string;
  text?: string;
  type?: 'gift' | 'img' | 'voice' | 'ttt_invite' | 'call_log';
  gift?: string;
  giftName?: string;
  amount?: number;
  img?: string;
  audio?: string;
  gameId?: string;
  stake?: number;
  handled?: boolean;
  sys?: boolean;
  timestamp?: number;
}

export interface PostItem {
  id: string;
  from: string;
  text?: string;
  img?: string;
  ts: number;
}

export interface RoomGiftEvent {
  room: string;
  from: string;
  to: string;
  gift: string;
  giftName: string;
  msg: string;
  id?: string;
}

export interface RoomChatMsg {
  id: string;
  room: string;
  from: string;
  text?: string;
  img?: string;
  ts?: number;
}

export interface RoomMusicState {
  isPlaying: boolean;
  title: string;
  artist?: string;
  audioData?: string;
  timestamp?: number;
  playedBy: string;
  duration?: number;
}

export interface TicTacToeState {
  gameId: string | null;
  active: boolean;
  waiting: boolean;
  board: string[];
  myMark: 'X' | 'O';
  opp: string | null;
  myTurn: boolean;
  stake: number;
  waitDeadline: number;
}

export interface GiftOption {
  e: string;
  n: string;
  cost: number;
}

export interface ActiveCallSession {
  callId: string;
  partner: string;
  status: 'calling' | 'ringing' | 'connected' | 'ended';
  isCaller: boolean;
  callType: 'voice' | 'video'; // Live video or voice
  startedAt?: number;
  durationSeconds: number;
  costPerMinute: number;
  diamondsPerMinute: number;
  isMuted: boolean;
  isVideoOff?: boolean;
  isFrontCamera?: boolean;
}
