import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  ArrowRight,
  Send,
  Mic,
  Smile,
  Image as ImageIcon,
  Gift,
  Coins,
  DollarSign,
  Phone,
  Video,
  Gem,
  Sparkles,
  CheckCheck,
  ShieldCheck,
} from 'lucide-react';
import { UserAccount, DirectMessage } from '../types';
import { QUICK_EMOJIS } from '../constants';
import { getBestMicStream, getRecorderOptions } from '../utils/audio';
import { translations, Language } from '../utils/i18n';

interface DMsTabProps {
  currentUser: string;
  currentCoins: number;
  cloudAccounts: Record<string, UserAccount>;
  onlineUsers: Record<string, number>;
  dmHistory: Record<string, DirectMessage[]>;
  unreadDm: Record<string, number>;
  activePartner: string | null;
  typingPartners: Record<string, boolean>;
  lang?: Language;
  onSelectPartner: (partner: string) => void;
  onCloseConversation: () => void;
  onSendTextMessage: (text: string) => void;
  onSendVoiceMessage: (audioBase64: string) => void;
  onSendImageMessage: (file: File) => void;
  onStartVoiceCall: (partner: string) => void;
  onStartVideoCall: (partner: string) => void;
  onOpenGiftModal: () => void;
  onOpenBuyModal: () => void;
  onOpenWithdrawModal: () => void;
  onNotifyTyping: () => void;
  onRespondTtt: (inviteId: string, fromUser: string, action: 'accept' | 'decline') => void;
  onViewImage: (imgUrl: string) => void;
  onShowToast: (msg: string) => void;
}

export const DMsTab: React.FC<DMsTabProps> = ({
  currentUser,
  currentCoins,
  cloudAccounts,
  onlineUsers,
  dmHistory,
  unreadDm,
  activePartner,
  typingPartners,
  lang = 'ar',
  onSelectPartner,
  onCloseConversation,
  onSendTextMessage,
  onSendVoiceMessage,
  onSendImageMessage,
  onStartVoiceCall,
  onStartVideoCall,
  onOpenGiftModal,
  onOpenBuyModal,
  onOpenWithdrawModal,
  onNotifyTyping,
  onRespondTtt,
  onViewImage,
  onShowToast,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'online' | 'unread' | 'friends'>('all');
  const [inputText, setInputText] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const msgsEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);

  const now = Date.now();
  const myAccount = cloudAccounts[currentUser];
  const isMeMale = !myAccount?.gender?.includes('أنثى');

  useEffect(() => {
    if (activePartner) {
      const scrollDown = (behavior: ScrollBehavior = 'smooth') => {
        if (msgsEndRef.current) {
          msgsEndRef.current.scrollIntoView({ behavior, block: 'end' });
        }
      };
      scrollDown('auto');
      const t1 = setTimeout(() => scrollDown('smooth'), 60);
      const t2 = setTimeout(() => scrollDown('smooth'), 220);
      return () => {
        clearTimeout(t1);
        clearTimeout(t2);
      };
    }
  }, [activePartner, activePartner ? (dmHistory[activePartner] || []).length : 0, typingPartners]);

  // Check if sending to this partner costs 5 coins (Male -> Female)
  const isMaleToFemale = (partnerName: string) => {
    if (!isMeMale) return false;
    const partnerAcc = cloudAccounts[partnerName];
    return !!partnerAcc?.gender?.includes('أنثى');
  };

  const handleStartVoice = () => {
    if (!activePartner) return;
    if (isMaleToFemale(activePartner) && currentCoins < 50) {
      onShowToast('رصيدك لا يكفي للاتصال، يتطلب 50 كوينز للدقيقة.');
      onOpenBuyModal();
      return;
    }
    onStartVoiceCall(activePartner);
  };

  const handleStartVideo = () => {
    if (!activePartner) return;
    if (isMaleToFemale(activePartner) && currentCoins < 50) {
      onShowToast('رصيدك لا يكفي لمكالمة الفيديو، يتطلب 50 كوينز للدقيقة.');
      onOpenBuyModal();
      return;
    }
    onStartVideoCall(activePartner);
  };

  const handleToggleVoiceRecord = async () => {
    if (!isRecording) {
      if (activePartner && isMaleToFemale(activePartner) && currentCoins < 5) {
        onShowToast('رصيدك لا يكفي لإرسال رسالة صوتية.');
        onOpenBuyModal();
        return;
      }
      try {
        const stream = await getBestMicStream();
        audioChunksRef.current = [];
        const recorder = new MediaRecorder(stream, getRecorderOptions());
        mediaRecorderRef.current = recorder;
        recorder.ondataavailable = (e) => {
          if (e.data.size > 0) audioChunksRef.current.push(e.data);
        };
        recorder.onstop = () => {
          const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
          const reader = new FileReader();
          reader.onload = (ev) => {
            if (ev.target?.result) {
              onSendVoiceMessage(ev.target.result as string);
            }
          };
          reader.readAsDataURL(audioBlob);
          stream.getTracks().forEach((track) => track.stop());
        };
        recorder.start();
        setIsRecording(true);
        setRecordingSeconds(0);
        timerRef.current = setInterval(() => {
          setRecordingSeconds((prev) => prev + 1);
        }, 1000);
      } catch {
        setIsRecording(false);
      }
    } else {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      clearInterval(timerRef.current);
    }
  };

  const handleSendText = () => {
    if (!inputText.trim() || !activePartner) return;
    if (isMaleToFemale(activePartner) && currentCoins < 5) {
      onShowToast('رصيدك غير كافٍ لإرسال رسالة (يتطلب 5 كوينز).');
      onOpenBuyModal();
      return;
    }
    onSendTextMessage(inputText.trim());
    setInputText('');
  };

  const handleSendImage = (file: File) => {
    if (!activePartner) return;
    if (isMaleToFemale(activePartner) && currentCoins < 5) {
      onShowToast('رصيدك غير كافٍ لإرسال صورة (يتطلب 5 كوينز).');
      onOpenBuyModal();
      return;
    }
    onSendImageMessage(file);
  };

  const isMutualFriend = (otherUser: string) => {
    const accA = cloudAccounts[currentUser];
    const accB = cloudAccounts[otherUser];
    const aFollowsB = accA?.following?.includes(otherUser);
    const bFollowsA = accB?.following?.includes(currentUser);
    return !!(aFollowsB && bFollowsA);
  };

  const allPartners = Array.from(
    new Set([
      ...Object.keys(dmHistory).filter((k) => (dmHistory[k] || []).length > 0),
      ...Object.keys(cloudAccounts).filter((k) => k !== currentUser),
    ])
  );

  const filteredPartners = allPartners.filter((p) => {
    if (p === currentUser) return false;
    const isOnline = onlineUsers[p] && now - onlineUsers[p] <= 300000;
    const unread = (unreadDm[p] || 0) > 0;
    const mutual = isMutualFriend(p);

    if (filter === 'online' && !isOnline) return false;
    if (filter === 'unread' && !unread) return false;
    if (filter === 'friends' && !mutual) return false;

    if (search.trim()) {
      const q = search.toLowerCase().trim();
      const u = cloudAccounts[p];
      return p.toLowerCase().includes(q) || (u?.idNum && u.idNum.includes(q));
    }
    return true;
  });

  // SINGLE CONVERSATION VIEW
  if (activePartner) {
    const partnerAcc = cloudAccounts[activePartner];
    const isOnline = onlineUsers[activePartner] && now - onlineUsers[activePartner] <= 300000;
    const mutual = isMutualFriend(activePartner);
    const msgs = dmHistory[activePartner] || [];
    const isPartnerStaff = partnerAcc?.isAdmin || partnerAcc?.isMod;
    const isTargetFemale = !!partnerAcc?.gender?.includes('أنثى');
    const isBillingActive = isMeMale && isTargetFemale;

    return (
      <div className="flex-1 flex flex-col min-h-0 w-full h-full bg-slate-950 text-white relative overflow-hidden">
        {/* Chat Header */}
        <div className="px-3.5 py-2.5 bg-gradient-to-r from-slate-900/95 via-purple-950/80 to-slate-900/95 backdrop-blur-xl border-b border-purple-900/40 flex items-center justify-between gap-2.5 shrink-0 shadow-lg">
          <div className="flex items-center gap-2.5 min-w-0">
            <button
              onClick={onCloseConversation}
              className="p-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 transition-colors shrink-0 cursor-pointer"
              title="رجوع"
            >
              <ArrowRight className={`w-5 h-5 ${isRtl ? '' : 'rotate-180'}`} />
            </button>
            <div className="relative shrink-0">
              <div className="w-10 h-10 rounded-2xl overflow-hidden bg-slate-800 border-2 border-purple-500/30 p-0.5">
                {partnerAcc?.avatar ? (
                  <img src={partnerAcc.avatar} alt={activePartner} className="w-full h-full object-cover rounded-xl" />
                ) : (
                  <div className="w-full h-full bg-gradient-to-tr from-purple-800 to-indigo-700 flex items-center justify-center font-bold text-white rounded-xl">
                    {activePartner.slice(0, 1).toUpperCase()}
                  </div>
                )}
              </div>
              {isOnline && (
                <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-900 shadow-sm" />
              )}
            </div>
            <div className="min-w-0 text-right">
              <div className="flex items-center gap-1.5 truncate">
                <span className="text-sm font-black text-white truncate">
                  {partnerAcc?.displayName || activePartner}
                </span>
                <span>{partnerAcc?.countryFlag || '🌍'}</span>
                {partnerAcc?.isVerified && (
                  <span title="موثق">
                    <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  </span>
                )}
                {mutual && (
                  <span className="text-[9px] text-emerald-400 font-bold bg-emerald-500/15 px-1.5 py-0.5 rounded border border-emerald-500/25 shrink-0">
                    صديق
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1 text-[11px] text-purple-300/80">
                <span>{partnerAcc?.gender || 'مستخدم'}</span>
                <span>•</span>
                <span className={isOnline ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                  {isOnline ? t.onlineStatus : 'غير متصل'}
                </span>
              </div>
            </div>
          </div>

          {/* Action Header Buttons: DIRECT VOICE CALL & VIDEO CALL (REQUESTED: مكالمة فيديو مباشر داخل المحادثة فقط) */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Live Video Call Button */}
            <button
              type="button"
              onClick={handleStartVideo}
              className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 hover:brightness-110 active:scale-95 text-white text-xs font-black shadow-md shadow-pink-600/30 flex items-center gap-1 transition-all cursor-pointer border border-pink-400/40"
              title={t.videoCall}
            >
              <Video className="w-4 h-4 text-white" />
              <span className="hidden sm:inline">{isRtl ? 'فيديو' : 'Video'}</span>
            </button>

            {/* Direct Voice Call Button */}
            <button
              type="button"
              onClick={handleStartVoice}
              className="p-2 sm:px-2.5 sm:py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:brightness-110 active:scale-95 text-white text-xs font-black shadow-md shadow-emerald-600/30 flex items-center gap-1 transition-all cursor-pointer border border-emerald-400/40"
              title={t.voiceCall}
            >
              <Phone className="w-4 h-4" />
              <span className="hidden sm:inline">{isRtl ? 'صوت' : 'Call'}</span>
            </button>

            {/* Quick Gift Button */}
            <button
              onClick={onOpenGiftModal}
              className="p-2 rounded-xl bg-gradient-to-r from-amber-400 to-yellow-400 hover:brightness-105 active:scale-95 text-slate-950 text-xs font-bold shadow-md shadow-amber-400/25 transition-all cursor-pointer"
              title={t.gift}
            >
              <Gift className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Pricing Notice Ribbon */}
        {isBillingActive && (
          <div className="px-3.5 py-1.5 bg-gradient-to-r from-purple-950/90 via-pink-950/70 to-purple-950/90 border-b border-purple-500/30 flex items-center justify-between text-[11px] text-pink-200">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                الرسائل: <b className="text-amber-300">5 كوينز</b> (للبنت <b className="text-pink-300">3 ماسات</b>) • الاتصال/الفيديو: <b className="text-amber-300">50 كوينز/دقيقة</b>
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <div className="flex items-center gap-1 text-amber-300 font-bold shrink-0 font-mono">
                <Coins className="w-3 h-3 text-amber-400" />
                <span>{currentCoins}</span>
              </div>
              <button
                type="button"
                onClick={onOpenBuyModal}
                className="px-2 py-0.5 rounded-lg bg-amber-500/25 hover:bg-amber-500/40 border border-amber-400/50 text-amber-300 text-[10px] font-bold cursor-pointer transition-all active:scale-95"
              >
                شحن
              </button>
            </div>
          </div>
        )}

        {/* Message Stream */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gradient-to-b from-slate-950 via-slate-900/60 to-slate-950">
          {msgs.length === 0 ? (
            <div className="text-center py-16 text-slate-400 text-xs space-y-2">
              <div className="w-12 h-12 rounded-2xl bg-purple-600/20 text-purple-300 flex items-center justify-center mx-auto text-2xl">
                💬
              </div>
              <p className="font-bold text-white">لا توجد رسائل سابقة</p>
              <p className="text-[11px] text-slate-500">
                ابدأ محادثة خاصة أو مكالمة فيديو مباشرة مع {partnerAcc?.displayName || activePartner}
              </p>
            </div>
          ) : (
            msgs.map((m) => {
              if (m.sys) {
                return (
                  <div key={m.id} className="text-center my-2">
                    <span className="inline-block px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-medium">
                      {m.text}
                    </span>
                  </div>
                );
              }
              const isMe = m.from === currentUser;
              const date = new Date(m.timestamp || Date.now());
              const timeStr = `${date.getHours()}:${String(date.getMinutes()).padStart(2, '0')}`;
              return (
                <div
                  key={m.id}
                  className={`flex flex-col ${isMe ? 'items-start' : 'items-end'}`}
                >
                  <div
                    className={`max-w-[82%] rounded-2xl p-3 shadow-md relative transition-all ${
                      isMe
                        ? 'bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-700 text-white rounded-bl-sm shadow-purple-950/40 border border-purple-400/20'
                        : 'bg-slate-900/95 text-slate-100 border border-slate-800 rounded-br-sm shadow-black/30'
                    }`}
                  >
                    {/* Text Message */}
                    {m.text && <p className="text-sm leading-relaxed break-words whitespace-pre-wrap">{m.text}</p>}
                    {/* Gift Notification */}
                    {m.type === 'gift' && (
                      <div className="flex items-center gap-3 py-1 bg-black/20 p-2.5 rounded-xl border border-white/10 my-1">
                        <span className="text-3xl drop-shadow-md">{m.gift}</span>
                        <div>
                          <div className="text-xs font-black text-amber-300">
                            هدية: {m.giftName}
                          </div>
                          <div className="text-[10px] text-white/80">
                            القيمة: {m.amount} كوينز
                          </div>
                        </div>
                      </div>
                    )}
                    {/* Image Message */}
                    {m.type === 'img' && m.img && (
                      <div className="mt-1">
                        <img
                          src={m.img}
                          alt="Photo"
                          onClick={() => onViewImage(m.img!)}
                          className="max-h-60 rounded-xl object-cover cursor-pointer hover:opacity-90 transition-opacity border border-white/20"
                        />
                      </div>
                    )}
                    {/* Voice Message */}
                    {m.type === 'voice' && m.audio && (
                      <div className="flex items-center gap-2 min-w-[200px] pt-1">
                        <audio controls src={m.audio} className="w-full max-w-[240px] h-8" />
                      </div>
                    )}
                    {/* Tic-Tac-Toe Game Challenge Invite */}
                    {m.type === 'ttt_invite' && (
                      <div className="space-y-2 py-1">
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">🎮</span>
                          <div>
                            <span className="text-xs font-bold text-amber-300">
                              تحدي لعبة X-O على {m.stake || 5} كوينز
                            </span>
                            <p className="text-[10px] text-white/80">
                              جائزة الفائز: {(m.stake || 5) * 2 - 2} كوينز
                            </p>
                          </div>
                        </div>
                        {!m.handled && !isMe ? (
                          <div className="flex gap-2 pt-1">
                            <button
                              onClick={() => onRespondTtt(m.id, m.from, 'accept')}
                              className="flex-1 py-1.5 px-3 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs transition-colors cursor-pointer"
                            >
                              قبول التحدي
                            </button>
                            <button
                              onClick={() => onRespondTtt(m.id, m.from, 'decline')}
                              className="flex-1 py-1.5 px-3 rounded-lg bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs transition-colors cursor-pointer"
                            >
                              رفض
                            </button>
                          </div>
                        ) : (
                          <p className="text-[10px] text-slate-300 italic pt-1">
                            تم التعامل مع التحدي
                          </p>
                        )}
                      </div>
                    )}
                    {/* Timestamp & read receipts */}
                    <div className="flex items-center justify-end gap-1 text-[9px] text-white/60 mt-1">
                      <span>{timeStr}</span>
                      {isMe && <CheckCheck className="w-3 h-3 text-purple-200" />}
                    </div>
                  </div>
                </div>
              );
            })
          )}
          {typingPartners[activePartner] && (
            <div className="text-xs text-purple-300 italic animate-pulse flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-purple-400 animate-ping" />
              <span>{activePartner} يكتب الآن...</span>
            </div>
          )}
          <div ref={msgsEndRef} className="h-4 shrink-0" />
        </div>

        {/* Emoji Tray */}
        {showEmoji && (
          <div className="p-2 bg-slate-900 border-t border-purple-500/20 shrink-0">
            <div className="grid grid-cols-9 gap-1 max-h-24 overflow-y-auto">
              {QUICK_EMOJIS.map((e) => (
                <button
                  key={e}
                  onClick={() => setInputText((prev) => prev + e)}
                  className="text-xl p-1 hover:bg-slate-800 rounded-lg text-center cursor-pointer"
                >
                  {e}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Input Bar */}
        <div className="p-3 bg-slate-900/95 backdrop-blur-xl border-t border-purple-900/30 space-y-2 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer shrink-0"
              title="إرسال صورة"
            >
              <ImageIcon className="w-4 h-4" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleSendImage(f);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
              className="hidden"
            />
            <button
              onClick={() => setShowEmoji(!showEmoji)}
              className="p-2.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer shrink-0"
              title="إيموجي"
            >
              <Smile className="w-4 h-4" />
            </button>
            <input
              type="text"
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                onNotifyTyping();
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendText();
              }}
              placeholder={
                isBillingActive
                  ? 'اكتب رسالة (تكلفة 5 كوينز)...'
                  : t.typeMessage
              }
              className="flex-1 min-w-0 py-2.5 px-3.5 rounded-xl bg-slate-950 border border-slate-700/80 text-white placeholder-slate-500 text-xs outline-none focus:border-purple-500 transition-colors"
            />
            <button
              onClick={handleToggleVoiceRecord}
              className={`p-2.5 rounded-xl transition-all cursor-pointer shrink-0 ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-slate-800/90 hover:bg-slate-700 text-slate-300'
              }`}
              title={isRecording ? 'إيقاف وإرسال' : 'تسجيل صوت'}
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              onClick={handleSendText}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:brightness-110 active:scale-95 text-white text-xs font-black transition-all shadow-md shadow-purple-600/30 cursor-pointer flex items-center gap-1.5 shrink-0"
              title={t.send}
            >
              <Send className={`w-4 h-4 ${isRtl ? 'rotate-180' : ''}`} />
              <span>{t.send}</span>
            </button>
          </div>
          {isRecording && (
            <div className="text-center text-xs text-rose-400 font-bold animate-pulse">
              جاري تسجيل الصوت ({recordingSeconds} ثانية)... اضغط مجدداً للإرسال
            </div>
          )}
        </div>
      </div>
    );
  }

  // PARTNERS LIST VIEW (EXTERNAL DMS PAGE)
  // CRITICAL REQUIREMENT: "شيل اتصل في صفحه الخاص وتكون جوا المحادثه وحده بس"
  // (NO CALL BUTTONS IN THIS LIST!)
  return (
    <div className="space-y-4 pb-20 text-right">
      <div className="relative">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={t.searchPlaceholder}
          className="w-full py-2.5 px-4 pr-10 rounded-2xl bg-slate-900/70 border border-slate-800 text-white placeholder-slate-500 text-xs outline-none focus:border-purple-500 transition-colors"
        />
        <Search className="w-4 h-4 text-slate-500 absolute top-3 right-3.5" />
      </div>

      <div className="flex bg-slate-900/80 p-1 rounded-2xl border border-purple-900/30 gap-1 overflow-x-auto">
        {(['all', 'online', 'unread', 'friends'] as const).map((tabKey) => {
          const labels = {
            all: t.allFilter,
            online: t.onlineFilter,
            unread: t.unreadFilter,
            friends: t.friendsFilter,
          };
          const isActive = filter === tabKey;
          return (
            <button
              key={tabKey}
              onClick={() => setFilter(tabKey)}
              className={`flex-1 py-1.5 px-3 text-xs font-bold rounded-xl whitespace-nowrap transition-all cursor-pointer ${
                isActive ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              {labels[tabKey]}
            </button>
          );
        })}
      </div>

      <div className="space-y-2">
        <div className="text-xs font-bold text-purple-200/70 px-1">
          {t.dmsTitle} ({filteredPartners.length})
        </div>
        {filteredPartners.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-500 text-xs">
            لا توجد محادثات مطابقة
          </div>
        ) : (
          filteredPartners.map((partner) => {
            const partnerAcc = cloudAccounts[partner];
            const isOnline = onlineUsers[partner] && now - onlineUsers[partner] <= 300000;
            const mutual = isMutualFriend(partner);
            const history = dmHistory[partner] || [];
            const lastMsg = history[history.length - 1];
            const unreadCount = unreadDm[partner] || 0;

            let previewText = 'اضغط لفتح المحادثة...';
            if (lastMsg) {
              if (lastMsg.type === 'gift') previewText = `هدية: ${lastMsg.giftName}`;
              else if (lastMsg.type === 'img') previewText = '📷 صورة';
              else if (lastMsg.type === 'voice') previewText = '🎤 رسالة صوتية';
              else if (lastMsg.type === 'ttt_invite') previewText = '🎮 تحدي X-O';
              else previewText = lastMsg.text || '';
            }

            return (
              <div
                key={partner}
                onClick={() => onSelectPartner(partner)}
                className="p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-purple-500/30 transition-all flex items-center justify-between gap-3 cursor-pointer group"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-2xl overflow-hidden bg-slate-800 border border-purple-500/20">
                      {partnerAcc?.avatar ? (
                        <img src={partnerAcc.avatar} alt={partner} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-tr from-purple-800 to-indigo-700 flex items-center justify-center font-bold text-white text-base">
                          {partner.slice(0, 1).toUpperCase()}
                        </div>
                      )}
                    </div>
                    {isOnline && (
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-900" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                        {partnerAcc?.displayName || partner}
                      </span>
                      <span>{partnerAcc?.countryFlag || '🌍'}</span>
                      {partnerAcc?.isVerified && (
                        <span title="موثق">
                          <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        </span>
                      )}
                      {mutual && (
                        <span className="text-[10px] text-emerald-400 font-bold">صديق</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">{previewText}</p>
                  </div>
                </div>

                {/* Notice: No Call Button here! Just unread counter badge and open arrow */}
                <div className="flex items-center gap-2 shrink-0">
                  {unreadCount > 0 && (
                    <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[11px] font-black flex items-center justify-center shadow-md shadow-rose-500/40">
                      {unreadCount}
                    </span>
                  )}
                  <div className="w-8 h-8 rounded-xl bg-purple-600/10 group-hover:bg-purple-600/20 text-purple-400 flex items-center justify-center transition-colors">
                    <ArrowRight className={`w-4 h-4 ${isRtl ? 'rotate-180' : ''}`} />
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
