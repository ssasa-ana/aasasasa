import React from 'react';
import { Plus, Radio, Crown, ShieldCheck } from 'lucide-react';
import { UserAccount } from '../types';
import { translations, Language } from '../utils/i18n';

interface RoomsTabProps {
  currentUser: string;
  roomHeartbeats: Record<string, number>;
  roomNames: Record<string, string>;
  cloudAccounts?: Record<string, UserAccount>;
  lang?: Language;
  onOpenCreateModal: () => void;
  onJoinRoom: (owner: string) => void;
  onEnterMyRoom: () => void;
  hasMyRoom: boolean;
}

export const RoomsTab: React.FC<RoomsTabProps> = ({
  currentUser,
  roomHeartbeats,
  roomNames,
  cloudAccounts = {},
  lang = 'ar',
  onOpenCreateModal,
  onJoinRoom,
  onEnterMyRoom,
  hasMyRoom,
}) => {
  const t = translations[lang] || translations.ar;
  const now = Date.now();
  const activeRooms = Object.keys(roomHeartbeats).filter((owner) => {
    return (
      (now - roomHeartbeats[owner] <= 20000 && owner !== currentUser) ||
      (cloudAccounts[owner]?.currentRoom && owner !== currentUser)
    );
  });

  return (
    <div className="space-y-4 pb-20 text-right">
      {/* Create Room Hero */}
      <div className="rounded-3xl bg-gradient-to-br from-purple-900/60 via-indigo-950/60 to-slate-900 border border-purple-500/30 p-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-40 h-40 bg-purple-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-300">
            <Radio className="w-5 h-5 text-purple-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">{t.tabRooms}</h2>
            <p className="text-xs text-purple-300/80">
              أنشئ غرفتك الصوتية الخاصة وشارك الموسيقى والمحادثات مع أصدقائك
            </p>
          </div>
        </div>

        <div className="mt-4">
          {hasMyRoom ? (
            <button
              onClick={onEnterMyRoom}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:opacity-95 text-slate-950 font-bold text-xs shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
            >
              <span>دخول غرفتي النشطة</span>
            </button>
          ) : (
            <button
              onClick={onOpenCreateModal}
              className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:opacity-95 text-white font-bold text-xs shadow-xl shadow-purple-600/30 flex items-center justify-center gap-2 transition-all active:scale-98 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إنشاء غرفة صوتية جديدة</span>
            </button>
          )}
        </div>
      </div>

      {/* Active rooms list */}
      <div>
        <div className="flex items-center justify-between text-xs font-bold text-purple-200/70 mb-3 px-1">
          <span>الغرف الصوتية النشطة ({activeRooms.length})</span>
          <span className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping inline-block" />
            <span>مباشر</span>
          </span>
        </div>

        {activeRooms.length === 0 ? (
          <div className="p-8 rounded-3xl bg-slate-900/40 border border-slate-800 text-center text-slate-400 space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto text-2xl">
              📻
            </div>
            <p className="text-sm font-semibold text-white">لا توجد غرف نشطة حالياً</p>
            <p className="text-xs text-slate-500">
              كن أول من يفتح غرفة صوتية واجمع أصدقاءك للحديث والاستماع
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-3">
            {activeRooms.map((owner) => {
              const displayName = roomNames[owner] || `غرفة ${owner}`;
              const hostAcc = cloudAccounts[owner];
              return (
                <div
                  key={owner}
                  onClick={() => onJoinRoom(owner)}
                  className="group p-4 rounded-3xl bg-slate-900/70 hover:bg-slate-900 border border-purple-900/30 hover:border-purple-500/50 transition-all cursor-pointer shadow-lg flex items-center justify-between gap-4"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="w-14 h-14 rounded-2xl overflow-hidden bg-gradient-to-tr from-purple-700 via-indigo-600 to-pink-600 p-0.5 shadow-md shadow-purple-900/30 shrink-0">
                      {hostAcc?.avatar ? (
                        <img src={hostAcc.avatar} alt={owner} className="w-full h-full object-cover rounded-[14px]" />
                      ) : (
                        <div className="w-full h-full bg-slate-950/90 rounded-[14px] flex items-center justify-center text-2xl">
                          🎙️
                        </div>
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <h3 className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                          {displayName}
                        </h3>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                        {hostAcc?.isVerified && (
                          <span title="موثق">
                            <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-purple-300/70 truncate mt-0.5 flex items-center gap-1">
                        <Crown className="w-3 h-3 text-amber-400" />
                        <span>المضيف: </span>
                        <span className="text-white font-medium">{owner}</span>
                      </p>
                      <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-400">
                        <span className="flex items-center gap-1 text-emerald-400 font-medium">
                          <Radio className="w-3 h-3 animate-pulse" />
                          <span>8 مقاعد مايك</span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <button className="px-4 py-2 rounded-xl bg-purple-600/20 group-hover:bg-purple-600 text-purple-300 group-hover:text-white text-xs font-bold transition-all shrink-0 shadow-md">
                    انضمام
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
