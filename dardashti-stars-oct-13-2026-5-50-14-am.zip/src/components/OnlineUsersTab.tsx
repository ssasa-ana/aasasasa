import React, { useState } from 'react';
import { Search, Heart, ShieldCheck } from 'lucide-react';
import { UserAccount } from '../types';
import { translations, Language } from '../utils/i18n';

interface OnlineUsersTabProps {
  currentUser: string;
  cloudAccounts: Record<string, UserAccount>;
  onlineUsers: Record<string, number>;
  lang?: Language;
  onOpenUserModal: (username: string) => void;
  onOpenDmWith: (username: string) => void;
  onJoinRoom?: (roomOwner: string) => void;
}

export const OnlineUsersTab: React.FC<OnlineUsersTabProps> = ({
  currentUser,
  cloudAccounts,
  onlineUsers,
  lang = 'ar',
  onOpenUserModal,
  onOpenDmWith,
  onJoinRoom,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'online'>('all');

  const now = Date.now();
  const allNames = Array.from(
    new Set([...Object.keys(cloudAccounts), ...Object.keys(onlineUsers)])
  ).filter((name) => name !== currentUser);

  const filteredNames = allNames.filter((name) => {
    const isOnline = Boolean(onlineUsers[name] && now - onlineUsers[name] <= 180000);
    if (filterMode === 'online' && !isOnline) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    const u = cloudAccounts[name];
    return (
      name.toLowerCase().includes(q) ||
      (u?.displayName && u.displayName.toLowerCase().includes(q)) ||
      (u?.idNum && u.idNum.includes(q))
    );
  });

  const sortedUserList = filteredNames.sort((a, b) => {
    const aOnline = Boolean(onlineUsers[a] && now - onlineUsers[a] <= 180000);
    const bOnline = Boolean(onlineUsers[b] && now - onlineUsers[b] <= 180000);
    if (aOnline && !bOnline) return -1;
    if (!aOnline && bOnline) return 1;
    const aTime = onlineUsers[a] || 0;
    const bTime = onlineUsers[b] || 0;
    return bTime - aTime;
  });

  const onlineCount = allNames.filter(
    (name) => onlineUsers[name] && now - onlineUsers[name] <= 180000
  ).length;

  return (
    <div className="space-y-4 pb-20 text-right">
      {/* Search Bar & Filter */}
      <div className="space-y-2">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={t.searchPlaceholder}
            className="w-full py-2.5 px-4 pr-10 rounded-2xl bg-slate-900/70 border border-slate-800 text-white placeholder-slate-500 text-xs outline-none focus:border-purple-500 transition-colors shadow-inner"
          />
          <Search className="w-4 h-4 text-slate-500 absolute top-3 right-3.5" />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setFilterMode('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterMode === 'all'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {t.allFilter} ({allNames.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterMode('online')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              filterMode === 'online'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{t.onlineFilter} ({onlineCount})</span>
          </button>
        </div>
      </div>

      {/* Online Users List */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-purple-200/70 px-1">
          <span>{t.tabChat} ({sortedUserList.length})</span>
          <span className="text-emerald-400 font-medium">{t.onlineFilter}: {onlineCount} متصل</span>
        </div>

        {sortedUserList.length === 0 ? (
          <div className="text-center py-12 text-slate-500 text-xs">
            {filterMode === 'online' ? 'لا يوجد مستخدمون متصلون الآن' : 'لا يوجد مستخدمون متطابقون'}
          </div>
        ) : (
          sortedUserList.map((username) => {
            const user = cloudAccounts[username];
            const isOnline = Boolean(onlineUsers[username] && now - onlineUsers[username] <= 180000);
            const isBanned = !!user?.isBanned;
            const isVerified = Boolean(user?.isVerified);

            return (
              <div
                key={username}
                onClick={() => onOpenUserModal(username)}
                className={`group p-3 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border transition-all flex items-center justify-between gap-3 cursor-pointer shadow-sm ${
                  isBanned ? 'border-rose-500/30 bg-rose-950/10' : 'border-slate-800/80 hover:border-purple-500/30'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  {/* Avatar with Status Ring */}
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-2xl overflow-hidden bg-slate-800 border border-purple-500/20">
                      {user?.avatar ? (
                        <img src={user.avatar} alt={username} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-tr from-purple-800 to-indigo-700 flex items-center justify-center text-lg text-white font-bold">
                          {username.slice(0, 1).toUpperCase()}
                        </div>
                      )}
                    </div>
                    {isOnline && !isBanned && (
                      <span className="absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-slate-900 shadow-sm" />
                    )}
                  </div>

                  {/* Info */}
                  <div className="min-w-0 text-right">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-sm font-bold text-white group-hover:text-purple-300 transition-colors truncate">
                        {user?.displayName || username}
                      </span>
                      {isVerified && (
                        <span title={t.verifiedBadge}>
                          <ShieldCheck className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        </span>
                      )}
                      {isBanned ? (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-bold border border-rose-500/40">
                          محظور
                        </span>
                      ) : isOnline ? (
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span>{t.onlineStatus}</span>
                        </span>
                      ) : null}
                      <span className="text-xs">{user?.countryFlag || '🌍'}</span>
                      <span className="text-[10px] text-slate-400">{user?.gender || 'مستخدم'}</span>
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {user?.bio || 'لا توجد نبذة'}
                    </p>
                    {user?.currentRoom && !isBanned && (
                      <span className="inline-flex items-center gap-1 text-[10px] text-purple-300 bg-purple-950/80 px-2 py-0.5 rounded-md border border-purple-500/30 mt-1 font-bold">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>في الغرفة: {user.currentRoom}</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Quick Action Buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {user?.currentRoom && onJoinRoom && !isBanned && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onJoinRoom(user.currentRoom!);
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold transition-all flex items-center gap-1 shadow-sm active:scale-95 cursor-pointer"
                      title="دخول الغرفة"
                    >
                      <span>دخول</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenDmWith(username);
                    }}
                    className="px-3 py-1.5 rounded-xl bg-pink-500/15 hover:bg-pink-500/25 border border-pink-500/30 text-pink-300 text-xs font-bold transition-all flex items-center gap-1 shadow-sm active:scale-95 cursor-pointer"
                    title="محادثة"
                  >
                    <Heart className="w-3.5 h-3.5 fill-pink-400 text-pink-400" />
                    <span>خاص</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
