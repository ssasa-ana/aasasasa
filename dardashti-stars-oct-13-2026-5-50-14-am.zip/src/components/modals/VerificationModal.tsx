import React, { useState, useRef, useEffect } from 'react';
import {
  X,
  ArrowRight,
  Camera,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Check,
  Upload,
} from 'lucide-react';
import { UserAccount } from '../../types';
import { translations, Language } from '../../utils/i18n';

interface VerificationModalProps {
  currentUser: string;
  account: UserAccount | undefined;
  lang?: Language;
  onClose: () => void;
  onSubmitVerification: (photos: {
    front: string;
    left: string;
    right: string;
    down: string;
  }) => void;
  onUpdateAvatar: (file: File) => void;
}

type VerificationStep = 'intro' | 'camera' | 'review';

export const VerificationModal: React.FC<VerificationModalProps> = ({
  currentUser,
  account,
  lang = 'ar',
  onClose,
  onSubmitVerification,
  onUpdateAvatar,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const [step, setStep] = useState<VerificationStep>('intro');
  const [capturedPhotos, setCapturedPhotos] = useState<{
    front: string;
    left: string;
    right: string;
    down: string;
  }>({
    front: '',
    left: '',
    right: '',
    down: '',
  });

  // Camera capture states: 0 = front, 1 = left, 2 = right, 3 = down, 4 = done
  const [currentAngleIndex, setCurrentAngleIndex] = useState<number>(0);
  const [countdown, setCountdown] = useState<number>(3);
  const [isCountingDown, setIsCountingDown] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const hasAvatar = Boolean(account?.avatar && account.avatar.trim().length > 0);

  const angleConfigs = [
    {
      key: 'front' as const,
      name: isRtl ? 'وجه أمامي' : 'Front Face',
      instruction: isRtl ? 'انظر إلى الكاميرا مباشرة بثبات' : 'Look directly at the camera',
      icon: '👤',
    },
    {
      key: 'left' as const,
      name: isRtl ? 'التفات لليسار' : 'Turn Left',
      instruction: isRtl ? 'أدر رأسك نحو جهة اليسار ببطء' : 'Turn your head slightly to the left',
      icon: '👈',
    },
    {
      key: 'right' as const,
      name: isRtl ? 'التفات لليمين' : 'Turn Right',
      instruction: isRtl ? 'أدر رأسك نحو جهة اليمين ببطء' : 'Turn your head slightly to the right',
      icon: '👉',
    },
    {
      key: 'down' as const,
      name: isRtl ? 'خفض الرأس' : 'Tilt Down',
      instruction: isRtl ? 'أنزل رأسك قليلاً نحو الأسفل' : 'Tilt your head slightly downwards',
      icon: '👇',
    },
  ];

  // Stop camera helper
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  // Start camera
  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch(() => {});
      }
      setCurrentAngleIndex(0);
      setCountdown(3);
      setIsCountingDown(true);
    } catch {
      setCameraError(t.verifCameraDenied);
    }
  };

  // Switch to camera step
  const handleStartCaptureSequence = () => {
    if (!hasAvatar) {
      alert(t.verifMustHaveAvatar);
      return;
    }
    setStep('camera');
    setTimeout(() => {
      startCamera();
    }, 100);
  };

  // Capture snapshot from video element
  const takeSnapshot = (angleKey: 'front' | 'left' | 'right' | 'down') => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 480;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Flip horizontally for natural mirror selfie look
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedPhotos((prev) => ({
      ...prev,
      [angleKey]: dataUrl,
    }));
  };

  // Countdown timer effect during camera capture
  useEffect(() => {
    if (step !== 'camera' || !isCountingDown || currentAngleIndex >= 4) return;

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          // Snap photo for current angle!
          const curAngle = angleConfigs[currentAngleIndex];
          if (curAngle) {
            takeSnapshot(curAngle.key);
          }

          if (currentAngleIndex < 3) {
            setCurrentAngleIndex((idx) => idx + 1);
            return 3; // reset countdown for next angle
          } else {
            // Done with all 4 angles!
            clearInterval(timer);
            setIsCountingDown(false);
            stopCamera();
            setStep('review');
            return 0;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [step, isCountingDown, currentAngleIndex]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpdateAvatar(file);
    }
    if (avatarInputRef.current) avatarInputRef.current.value = '';
  };

  const handleRetake = () => {
    setCapturedPhotos({ front: '', left: '', right: '', down: '' });
    setCurrentAngleIndex(0);
    setCountdown(3);
    setStep('camera');
    setTimeout(() => {
      startCamera();
    }, 100);
  };

  const handleSubmitAll = () => {
    if (!capturedPhotos.front || !capturedPhotos.left || !capturedPhotos.right || !capturedPhotos.down) {
      alert(isRtl ? 'يرجى التقاط جميع الصور الأربعة أولاً!' : 'Please capture all 4 angle photos!');
      return;
    }
    onSubmitVerification(capturedPhotos);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border border-purple-500/35 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header Bar */}
        <div className="px-4 py-3 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (step === 'camera' || step === 'review') {
                  stopCamera();
                  setStep('intro');
                } else {
                  onClose();
                }
              }}
              className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="رجوع"
            >
              <ArrowRight className={`w-5 h-5 ${isRtl ? '' : 'rotate-180'}`} />
            </button>
            <h3 className="text-base font-black text-white flex items-center gap-1.5">
              <span>{t.verifModalTitle}</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </h3>
          </div>
          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: INTRO & INSTRUCTIONS (Exact Match to User's Screenshot) */}
        {step === 'intro' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-center">
            {/* Rejected Warning Alert if previously rejected */}
            {account?.verificationStatus === 'rejected' && (
              <div className="p-3 rounded-2xl bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center gap-2 text-right">
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
                <div>
                  <span className="block font-black">
                    {isRtl ? 'تم رفض طلب التوثيق السابق من الإدارة' : 'Previous verification was rejected'}
                  </span>
                  <span className="text-[11px] font-normal text-rose-200">
                    {isRtl
                      ? 'يرجى إعادة التقاط صور واضحة ومطابقة لوجهك بالكامل لإعادة التقديم.'
                      : 'Please retake clear, matching pictures of your full face to re-apply.'}
                  </span>
                </div>
              </div>
            )}

            {/* Current Profile Photo Box */}
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="relative">
                <div className="w-28 h-28 rounded-2xl overflow-hidden border-2 border-purple-500/40 shadow-xl bg-slate-950 flex items-center justify-center">
                  {hasAvatar ? (
                    <img
                      src={account!.avatar}
                      alt={currentUser}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-500 space-y-1 p-2">
                      <Camera className="w-8 h-8 text-rose-400 animate-pulse" />
                      <span className="text-[10px] text-rose-300 font-bold">
                        {isRtl ? 'لا توجد صورة' : 'No Photo'}
                      </span>
                    </div>
                  )}
                </div>
                {/* Status indicator on avatar */}
                {account?.isVerified && (
                  <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black flex items-center gap-1 shadow-md">
                    <Check className="w-3 h-3 stroke-[3]" />
                    <span>{isRtl ? 'موثق' : 'Verified'}</span>
                  </div>
                )}
              </div>
              <span className="text-xs font-black text-white">{t.verifCurrentPhoto}</span>
              <p className="text-xs text-slate-400 max-w-xs">{t.verifPhotoWarning}</p>

              {/* Requirement: User MUST have photo before verification */}
              {!hasAvatar && (
                <div className="w-full p-3 rounded-2xl bg-amber-500/15 border border-amber-500/40 space-y-2">
                  <span className="text-xs font-bold text-amber-300 block">
                    {t.verifMustHaveAvatar}
                  </span>
                  <button
                    type="button"
                    onClick={() => avatarInputRef.current?.click()}
                    className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>{t.verifUploadAvatarNow}</span>
                  </button>
                  <input
                    type="file"
                    ref={avatarInputRef}
                    accept="image/*"
                    onChange={handleAvatarFile}
                    className="hidden"
                  />
                </div>
              )}
            </div>

            {/* Next Step Button (Big Yellow Button matching screenshot) */}
            <button
              type="button"
              onClick={handleStartCaptureSequence}
              disabled={!hasAvatar}
              className={`w-full py-3.5 px-4 rounded-2xl font-black text-sm shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 ${
                hasAvatar
                  ? 'bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-400 hover:brightness-105 text-slate-950 shadow-yellow-400/25 ring-2 ring-yellow-400/40'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>{t.verifNextStep}</span>
            </button>

            {/* Verification Examples Section (مثال: Correct vs Wrong from screenshot) */}
            <div className="space-y-2 text-right">
              <h4 className="text-xs font-black text-white">{t.verifExampleTitle}</h4>
              <div className="grid grid-cols-4 gap-2">
                {/* Correct: Full face */}
                <div className="relative rounded-2xl overflow-hidden border border-emerald-500/60 aspect-square bg-slate-950 shadow-sm flex flex-col justify-end p-1">
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop"
                    alt="Correct"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute top-1 left-1 w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center shadow">
                    <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                  </div>
                </div>

                {/* Mask */}
                <div className="relative rounded-2xl overflow-hidden border border-rose-500/60 aspect-square bg-slate-950 shadow-sm flex flex-col justify-end p-1">
                  <img
                    src="https://images.unsplash.com/photo-1584634731339-252c581abfc5?q=80&w=300&auto=format&fit=crop"
                    alt="Mask"
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute top-1 left-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                    <XCircle className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Wrong Gender / Different person */}
                <div className="relative rounded-2xl overflow-hidden border border-rose-500/60 aspect-square bg-slate-950 shadow-sm flex flex-col justify-end p-1">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop"
                    alt="Wrong"
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute top-1 left-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                    <XCircle className="w-3.5 h-3.5" />
                  </div>
                </div>

                {/* Child / Minor */}
                <div className="relative rounded-2xl overflow-hidden border border-rose-500/60 aspect-square bg-slate-950 shadow-sm flex flex-col justify-end p-1">
                  <img
                    src="https://images.unsplash.com/photo-1543332164-6e82f355badc?q=80&w=300&auto=format&fit=crop"
                    alt="Child"
                    className="absolute inset-0 w-full h-full object-cover opacity-80"
                  />
                  <div className="absolute top-1 left-1 w-5 h-5 rounded-full bg-rose-600 text-white flex items-center justify-center shadow">
                    <XCircle className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            </div>

            {/* Official Notice terms matching user screenshot (إشعار التوثيق) */}
            <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-right space-y-2 text-[11px] text-slate-300 leading-relaxed">
              <h4 className="font-black text-amber-300 text-xs">{t.verifTermsTitle}</h4>
              <p>{t.verifTerm1}</p>
              <p>{t.verifTerm2}</p>
              <p>{t.verifTerm3}</p>
              <p>{t.verifTerm4}</p>
              <p className="text-rose-300/90 font-medium">{t.verifTerm5}</p>
            </div>
          </div>
        )}

        {/* STEP 2: CAMERA 4-ANGLE SEQUENCE (3s front, 3s left, 3s right, 3s down) */}
        {step === 'camera' && (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-between space-y-4">
            <div className="w-full text-center space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-600/25 border border-purple-500/40 text-purple-200 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>
                  {isRtl
                    ? `الزاوية (${currentAngleIndex + 1}/4): ${angleConfigs[currentAngleIndex]?.name}`
                    : `Angle (${currentAngleIndex + 1}/4): ${angleConfigs[currentAngleIndex]?.name}`}
                </span>
              </div>
              <p className="text-sm font-black text-amber-300 animate-pulse">
                {angleConfigs[currentAngleIndex]?.instruction}
              </p>
            </div>

            {/* Live Camera View with Interactive Guide Overlay */}
            <div className="relative w-full max-w-[280px] aspect-square rounded-3xl overflow-hidden border-4 border-purple-500/50 bg-black shadow-2xl flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover -scale-x-100"
              />

              {/* Oval Face Guide */}
              <div className="absolute inset-6 rounded-[50%] border-2 border-dashed border-white/60 pointer-events-none flex items-center justify-center">
                <span className="text-3xl opacity-80">{angleConfigs[currentAngleIndex]?.icon}</span>
              </div>

              {/* Big 3-second countdown badge */}
              <div className="absolute top-4 right-4 w-12 h-12 rounded-full bg-black/80 backdrop-blur-md border-2 border-amber-400 text-amber-300 font-mono font-black text-2xl flex items-center justify-center shadow-2xl animate-bounce">
                {countdown}
              </div>

              {/* Angle tracker footer inside video */}
              <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-2">
                {[0, 1, 2, 3].map((idx) => {
                  const isDone = idx < currentAngleIndex;
                  const isCurrent = idx === currentAngleIndex;
                  return (
                    <div
                      key={idx}
                      className={`w-3 h-3 rounded-full transition-all border ${
                        isDone
                          ? 'bg-emerald-400 border-emerald-300 scale-110'
                          : isCurrent
                          ? 'bg-amber-400 border-amber-300 animate-ping'
                          : 'bg-white/20 border-white/30'
                      }`}
                    />
                  );
                })}
              </div>
            </div>

            {/* Camera error message fallback */}
            {cameraError && (
              <div className="p-3 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold text-center">
                {cameraError}
              </div>
            )}

            {/* Angles Step Progress Badges */}
            <div className="grid grid-cols-4 gap-2 w-full max-w-sm">
              {angleConfigs.map((cfg, idx) => {
                const isDone = idx < currentAngleIndex;
                const isCurrent = idx === currentAngleIndex;
                return (
                  <div
                    key={cfg.key}
                    className={`p-2 rounded-2xl border text-center transition-all ${
                      isDone
                        ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                        : isCurrent
                        ? 'bg-purple-600/30 border-amber-400 text-amber-300 font-bold shadow-md'
                        : 'bg-slate-950/60 border-slate-800 text-slate-500'
                    }`}
                  >
                    <span className="text-sm block">{cfg.icon}</span>
                    <span className="text-[10px] font-bold block truncate">{cfg.name}</span>
                    <span className="text-[9px] font-mono text-slate-400">
                      {isDone ? '✓ 3s' : isCurrent ? `${countdown}s` : '3s'}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Cancel / restart button */}
            <button
              type="button"
              onClick={() => {
                stopCamera();
                setStep('intro');
              }}
              className="py-2 px-4 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 transition-colors cursor-pointer"
            >
              {isRtl ? 'إلغاء والعودة' : 'Cancel & Go Back'}
            </button>
          </div>
        )}

        {/* STEP 3: REVIEW CAPTURED 4 PHOTOS & SUBMIT TO ADMIN */}
        {step === 'review' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center mx-auto text-2xl shadow-lg">
              ✨
            </div>
            <div>
              <h4 className="text-base font-black text-white">{t.verifAllCaptured}</h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {isRtl
                  ? 'تم التقاط الصور الأربعة بنجاح، راجع الصور واضغط إرسال للتوثيق.'
                  : 'All 4 photos captured successfully. Review and submit.'}
              </p>
            </div>

            {/* 4 Captured Photos Grid */}
            <div className="grid grid-cols-2 gap-2.5 max-w-sm mx-auto text-right">
              {angleConfigs.map((cfg) => {
                const photoSrc = capturedPhotos[cfg.key];
                return (
                  <div
                    key={cfg.key}
                    className="p-2 rounded-2xl bg-slate-950/90 border border-purple-500/30 space-y-1.5 shadow-md"
                  >
                    <div className="flex items-center justify-between text-[11px] font-bold text-purple-200 px-1">
                      <span>{cfg.name}</span>
                      <span>{cfg.icon}</span>
                    </div>
                    <div className="w-full aspect-square rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
                      {photoSrc ? (
                        <img
                          src={photoSrc}
                          alt={cfg.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-xs text-slate-500">
                          {isRtl ? 'لم يتم الالتقاط' : 'Not captured'}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Actions: Submit to Admin or Retake */}
            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={handleSubmitAll}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:brightness-105 active:scale-98 text-white font-black text-xs shadow-xl shadow-emerald-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Check className="w-4 h-4 stroke-[3]" />
                <span>{t.verifSubmitRequest}</span>
              </button>

              <button
                type="button"
                onClick={handleRetake}
                className="w-full py-2.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.verifRetake}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
