import React from 'react';
import {
  X,
  Sparkles,
  PhoneCall,
  Gem,
  Coins,
  ShieldCheck,
  CheckCircle2,
  Gift,
  Lock,
  ArrowRight,
  UserCheck,
} from 'lucide-react';
import { UserAccount } from '../../types';
import { translations, Language } from '../../utils/i18n';

interface TasksModalProps {
  currentUser: string;
  account: UserAccount | undefined;
  lang?: Language;
  onClose: () => void;
  onClaimTask: (taskId: string, rewardType: 'diamonds' | 'coins', amount: number) => void;
  onOpenVerification?: () => void;
}

export const TasksModal: React.FC<TasksModalProps> = ({
  currentUser,
  account,
  lang = 'ar',
  onClose,
  onClaimTask,
  onOpenVerification,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const isFemale = Boolean(
    account?.gender?.includes('أنثى') ||
      account?.gender?.toLowerCase().includes('female')
  );

  const completed = account?.completedTasks || [];
  const calledCount = account?.calledPartners?.length || 0;
  const isVerified = Boolean(account?.isVerified);

  // Task 1: Call 3 users (Female only)
  const isTask1Completed = completed.includes('call_3_users');
  const canClaimTask1 = isFemale && calledCount >= 3 && !isTask1Completed;

  // Task 2: Daily Check-in
  const isTask2Completed = completed.includes('daily_checkin');

  // Task 3: Verification
  const isTask3Completed = completed.includes('verify_profile');
  const canClaimTask3 = isVerified && !isTask3Completed;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border border-purple-500/35 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-400/30 to-purple-500/30 border border-amber-400/40 text-amber-300 flex items-center justify-center text-lg shadow-sm">
              🏆
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-1.5">
                <span>{t.tasksTitle}</span>
                <Sparkles className="w-4 h-4 text-amber-400" />
              </h3>
              <p className="text-[11px] text-purple-300/80">
                {isRtl ? 'أكمل المهمات واكسب الماسات والكوينز فوراً' : 'Complete missions & earn rewards'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balances Header Strip */}
        <div className="grid grid-cols-2 gap-2.5 p-3 rounded-2xl bg-slate-950/80 border border-purple-500/20 text-xs">
          <div className="flex items-center justify-between px-2">
            <span className="text-slate-400 font-medium">{t.diamondsLabel}:</span>
            <div className="flex items-center gap-1 font-black text-pink-300">
              <span className="font-mono">{account?.diamonds || 0}</span>
              <Gem className="w-3.5 h-3.5 text-pink-400" />
            </div>
          </div>
          <div className="flex items-center justify-between px-2 border-r border-slate-800">
            <span className="text-slate-400 font-medium">{t.coinsLabel}:</span>
            <div className="flex items-center gap-1 font-black text-amber-300">
              <span className="font-mono">{account?.points || 0}</span>
              <Coins className="w-3.5 h-3.5 text-amber-400" />
            </div>
          </div>
        </div>

        {/* Tasks List */}
        <div className="space-y-3">
          {/* TASK 1: TALK TO 3 USERS VIA CALL (FEMALE ONLY) - TOP MISSION AS REQUESTED */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-950/60 via-purple-950/40 to-slate-950 border-2 border-pink-500/50 space-y-3 shadow-lg shadow-pink-950/30 relative overflow-hidden">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-pink-500 to-purple-600 text-white flex items-center justify-center shadow-md shrink-0">
                  <PhoneCall className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-black text-white">{t.task1Title}</h4>
                  <p className="text-[11px] text-pink-200/80 mt-0.5 leading-relaxed">{t.task1Desc}</p>
                </div>
              </div>
              <div className="px-2.5 py-1 rounded-xl bg-pink-500/20 border border-pink-500/40 text-pink-300 text-xs font-black shrink-0">
                {t.task1Reward}
              </div>
            </div>

            {/* Female Only Tag / Progress Bar */}
            <div className="space-y-2 pt-1 border-t border-pink-500/20">
              {isFemale ? (
                <>
                  <div className="flex items-center justify-between text-xs font-bold text-pink-200">
                    <span>{t.taskProgress}:</span>
                    <span className="font-mono font-black text-white">
                      {Math.min(3, calledCount)} / 3 {isRtl ? 'مكالمات' : 'Calls'}
                    </span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-slate-950 overflow-hidden border border-pink-500/30">
                    <div
                      className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full transition-all duration-500"
                      style={{ width: `${Math.min(100, Math.round((calledCount / 3) * 100))}%` }}
                    />
                  </div>
                </>
              ) : (
                <div className="p-2.5 rounded-xl bg-slate-950/80 border border-amber-500/30 text-amber-300 text-[11px] font-bold flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{t.taskFemaleOnlyNotice}</span>
                </div>
              )}
            </div>

            {/* Claim button */}
            {isFemale && (
              <button
                type="button"
                onClick={() => onClaimTask('call_3_users', 'diamonds', 8)}
                disabled={!canClaimTask1}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-md ${
                  isTask1Completed
                    ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 cursor-default'
                    : canClaimTask1
                    ? 'bg-gradient-to-r from-pink-500 via-rose-500 to-purple-600 text-white shadow-pink-500/30 hover:brightness-110 active:scale-95 cursor-pointer animate-pulse'
                    : 'bg-slate-950/70 text-slate-500 border border-slate-800 cursor-not-allowed'
                }`}
              >
                {isTask1Completed ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{t.taskClaimed} (+8 💎)</span>
                  </>
                ) : (
                  <>
                    <Gem className="w-4 h-4" />
                    <span>{canClaimTask1 ? `${t.taskClaim} (+8 💎)` : `${t.taskProgress}: ${Math.min(3, calledCount)}/3`}</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* TASK 2: DAILY CHECK-IN */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center shrink-0">
                <Coins className="w-5 h-5 text-amber-400" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate">{t.taskDailyCheckin}</h4>
                <span className="text-[10px] text-amber-300 font-bold">{t.taskDailyReward}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onClaimTask('daily_checkin', 'coins', 10)}
              disabled={isTask2Completed}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                isTask2Completed
                  ? 'bg-slate-800 text-slate-500 cursor-default'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 font-black active:scale-95 cursor-pointer shadow-md'
              }`}
            >
              {isTask2Completed ? t.taskClaimed : t.taskClaim}
            </button>
          </div>

          {/* TASK 3: COMPLETE VERIFICATION */}
          <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-purple-500/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate">{t.taskVerifyProfile}</h4>
                <span className="text-[10px] text-pink-300 font-bold">{t.taskVerifyReward}</span>
              </div>
            </div>
            {isVerified ? (
              <button
                type="button"
                onClick={() => onClaimTask('verify_profile', 'diamonds', 20)}
                disabled={isTask3Completed}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 ${
                  isTask3Completed
                    ? 'bg-slate-800 text-slate-500 cursor-default'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black active:scale-95 cursor-pointer shadow-md'
                }`}
              >
                {isTask3Completed ? t.taskClaimed : t.taskClaim}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  if (onOpenVerification) onOpenVerification();
                }}
                className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold transition-all shrink-0 cursor-pointer"
              >
                {t.verification}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
