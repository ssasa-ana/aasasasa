import React, { useEffect, useState, useRef } from 'react';
import {
  Phone,
  PhoneOff,
  Mic,
  MicOff,
  Video,
  VideoOff,
  SwitchCamera,
  Coins,
  Gem,
  Maximize2,
} from 'lucide-react';
import { ActiveCallSession, UserAccount } from '../../types';
import { formatDuration } from '../../utils/helpers';
import { translations, Language } from '../../utils/i18n';

interface ActiveCallModalProps {
  callSession: ActiveCallSession;
  partnerAccount?: UserAccount;
  myCoins: number;
  isMeFemale: boolean;
  isPartnerFemale: boolean;
  lang?: Language;
  localStream?: MediaStream | null;
  onAcceptCall: () => void;
  onRejectCall: () => void;
  onEndCall: () => void;
  onToggleMute: () => void;
  onToggleVideo?: () => void;
  onSwitchCamera?: () => void;
  isSpeaking?: boolean;
}

export const ActiveCallModal: React.FC<ActiveCallModalProps> = ({
  callSession,
  partnerAccount,
  myCoins,
  isMeFemale,
  isPartnerFemale,
  lang = 'ar',
  localStream,
  onAcceptCall,
  onRejectCall,
  onEndCall,
  onToggleMute,
  onToggleVideo,
  onSwitchCamera,
  isSpeaking = false,
}) => {
  const t = translations[lang] || translations.ar;
  const isVideo = callSession.callType === 'video';
  const isIncoming = callSession.status === 'ringing' && !callSession.isCaller;
  const isConnected = callSession.status === 'connected';
  const partnerName = partnerAccount?.displayName || callSession.partner;
  const isMonetizedCall = (!isMeFemale && isPartnerFemale) || (isMeFemale && !isPartnerFemale);

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);

  // Attach local stream to video element when video call is active
  useEffect(() => {
    if (isVideo && localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
      localVideoRef.current.play().catch(() => {});
    }
  }, [isVideo, localStream]);

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-2 sm:p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in duration-300">
      <div
        className={`w-full max-w-sm bg-gradient-to-b from-slate-900 via-purple-950/40 to-slate-950 border border-purple-500/30 rounded-3xl shadow-2xl shadow-purple-950/80 text-center relative overflow-hidden flex flex-col items-center justify-between ${
          isVideo ? 'h-[92vh] max-h-[680px]' : 'min-h-[500px]'
        }`}
      >
        {/* Glow ambient background circles */}
        <div className="absolute -top-20 -left-20 w-44 h-44 bg-purple-600/25 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-44 h-44 bg-pink-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header Bar */}
        <div className="w-full flex items-center justify-between px-4 py-3 text-xs text-purple-200/80 border-b border-white/10 shrink-0 z-20 bg-slate-950/60 backdrop-blur-md">
          <div className="flex items-center gap-1.5 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span className="flex items-center gap-1">
              {isVideo ? <Video className="w-3.5 h-3.5 text-emerald-400" /> : <Phone className="w-3.5 h-3.5 text-emerald-400" />}
              <span>{isVideo ? t.videoCall : t.voiceCall}</span>
            </span>
          </div>
          {isConnected && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono font-black text-xs shadow-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{formatDuration(callSession.durationSeconds)}</span>
            </div>
          )}
        </div>

        {/* Central Calling View */}
        {isVideo && isConnected ? (
          /* LIVE VIDEO CALL VIEWPORT */
          <div className="relative w-full flex-1 flex items-center justify-center bg-black overflow-hidden">
            {/* Remote Partner Video Placeholder / Feed */}
            <div className="w-full h-full relative flex items-center justify-center bg-gradient-to-b from-slate-900 to-black">
              {partnerAccount?.avatar ? (
                <img
                  src={partnerAccount.avatar}
                  alt={partnerName}
                  className="w-full h-full object-cover opacity-60 filter blur-sm scale-110"
                />
              ) : null}
              <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3 z-10">
                <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-emerald-400 shadow-2xl bg-slate-900">
                  {partnerAccount?.avatar ? (
                    <img src={partnerAccount.avatar} alt={partnerName} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-3xl font-bold text-white">
                      {partnerName.slice(0, 1).toUpperCase()}
                    </div>
                  )}
                </div>
                <div className="text-center">
                  <h3 className="text-base font-black text-white">{partnerName}</h3>
                  <span className="text-xs text-emerald-400 font-bold flex items-center justify-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>فيديو مباشر HD متصل</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Local Camera Picture-in-Picture Preview */}
            <div className="absolute top-3 left-3 w-28 h-36 rounded-2xl overflow-hidden border-2 border-purple-400/80 bg-slate-950 shadow-2xl z-20">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${callSession.isFrontCamera !== false ? '-scale-x-100' : ''}`}
              />
              {callSession.isVideoOff && (
                <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center text-white text-[10px]">
                  <VideoOff className="w-5 h-5 text-rose-400 mb-1" />
                  <span>الكاميرا مغلقة</span>
                </div>
              )}
            </div>

            {/* Economic banner overlay during call */}
            {isMonetizedCall && (
              <div className="absolute top-3 right-3 z-20 px-2.5 py-1 rounded-xl bg-black/75 backdrop-blur-md border border-amber-500/30 text-[10px] text-amber-300 font-mono font-bold">
                {isMeFemale ? '+50 💎 / د' : '-50 🪙 / د'}
              </div>
            )}
          </div>
        ) : (
          /* VOICE OR PENDING INCOMING/OUTGOING CALL VIEWPORT */
          <div className="flex flex-col items-center my-auto space-y-4 py-4 px-4">
            {/* Animated Avatar Circle */}
            <div className="relative">
              <div
                className={`absolute -inset-4 rounded-full border-2 border-purple-400/30 transition-transform duration-1000 ${
                  isSpeaking || isIncoming ? 'scale-125 opacity-70' : 'scale-100 opacity-20'
                }`}
              />
              <div
                className={`absolute -inset-8 rounded-full border border-pink-400/20 transition-transform duration-1000 ${
                  isSpeaking || isIncoming ? 'scale-150 opacity-40' : 'scale-100 opacity-10'
                }`}
              />
              <div className="w-28 h-28 rounded-full p-1.5 bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-600 shadow-2xl shadow-purple-600/40 flex items-center justify-center relative z-10">
                <div className="w-full h-full rounded-full bg-slate-950 overflow-hidden flex items-center justify-center">
                  {partnerAccount?.avatar ? (
                    <img
                      src={partnerAccount.avatar}
                      alt={partnerName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-4xl font-black text-white">
                      {partnerName.slice(0, 1).toUpperCase()}
                    </span>
                  )}
                </div>
              </div>

              {/* Speaking audio indicator badge */}
              {isConnected && (
                <div
                  className={`absolute bottom-0 right-1 px-2 py-0.5 rounded-full text-[10px] font-black border shadow-lg flex items-center gap-1 z-20 ${
                    isSpeaking
                      ? 'bg-emerald-500 text-slate-950 border-emerald-300 animate-pulse'
                      : 'bg-slate-900 text-slate-400 border-slate-700'
                  }`}
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-current" />
                  <span>{isSpeaking ? 'يتحدث' : 'صامت'}</span>
                </div>
              )}
            </div>

            {/* User Details */}
            <div className="space-y-1">
              <h3 className="text-xl font-black text-white flex items-center justify-center gap-1.5">
                <span>{partnerName}</span>
                <span>{partnerAccount?.countryFlag || '🌍'}</span>
              </h3>
              <p className="text-xs text-purple-300 font-medium">
                {partnerAccount?.gender || 'مستخدم'} • {partnerAccount?.country || 'عربي'}
              </p>
            </div>

            {/* Call Status Text */}
            <div className="space-y-1.5">
              {isConnected ? (
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono font-black text-base shadow-lg shadow-emerald-500/20">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{formatDuration(callSession.durationSeconds)}</span>
                </div>
              ) : isIncoming ? (
                <div className="text-sm font-black text-amber-300 animate-bounce flex items-center justify-center gap-1.5">
                  <Phone className="w-4 h-4 animate-spin" />
                  <span>
                    {isVideo ? 'مكالمة فيديو واردة من ' : 'اتصال صوتي وارد من '}
                    {partnerName}...
                  </span>
                </div>
              ) : (
                <div className="text-sm font-bold text-purple-200 animate-pulse flex items-center justify-center gap-1.5">
                  <span>جاري الاتصال...</span>
                </div>
              )}
            </div>

            {/* Economics / Pricing Banner */}
            {isMonetizedCall && (
              <div className="max-w-[280px] p-2.5 rounded-2xl bg-slate-950/70 border border-purple-500/30 text-xs space-y-1">
                {isMeFemale ? (
                  <div className="flex items-center justify-center gap-1 text-pink-300 font-bold">
                    <Gem className="w-3.5 h-3.5 text-pink-400" />
                    <span>المكافأة: 50 ماسة لكل دقيقة</span>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    <div className="flex items-center justify-center gap-1 text-amber-300 font-bold">
                      <Coins className="w-3.5 h-3.5 text-amber-400" />
                      <span>تكلفة المكالمة: 50 كوينز لكل دقيقة</span>
                    </div>
                    <span className="text-[10px] text-slate-400 block font-mono">
                      رصيدك الحالي: {myCoins} كوينز
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Bottom Actions Bar */}
        <div className="w-full p-4 border-t border-white/10 shrink-0 z-20 bg-slate-950/80 backdrop-blur-md">
          {isIncoming ? (
            /* Incoming Call: Accept / Reject */
            <div className="flex items-center justify-around gap-4 w-full px-4">
              <button
                type="button"
                onClick={onRejectCall}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/40 transition-transform active:scale-95 group-hover:scale-105">
                  <PhoneOff className="w-7 h-7" />
                </div>
                <span className="text-xs font-bold text-rose-300">رفض</span>
              </button>

              <button
                type="button"
                onClick={onAcceptCall}
                className="flex flex-col items-center gap-1.5 group cursor-pointer"
              >
                <div className="w-16 h-16 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white flex items-center justify-center shadow-xl shadow-emerald-600/40 transition-transform active:scale-95 group-hover:scale-105 animate-pulse">
                  {isVideo ? <Video className="w-7 h-7" /> : <Phone className="w-7 h-7" />}
                </div>
                <span className="text-xs font-bold text-emerald-300">رد</span>
              </button>
            </div>
          ) : (
            /* Connected or Outgoing: Controls */
            <div className="flex items-center justify-around gap-2 w-full px-2">
              {/* Mute Mic */}
              <button
                type="button"
                onClick={onToggleMute}
                className="flex flex-col items-center gap-1 group cursor-pointer"
              >
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center transition-all border ${
                    callSession.isMuted
                      ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                      : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700'
                  }`}
                >
                  {callSession.isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </div>
                <span className="text-[10px] font-bold text-slate-300">
                  {callSession.isMuted ? 'إلغاء الكتم' : 'كتم الصوت'}
                </span>
              </button>

              {/* Camera Video On/Off if Video call */}
              {isVideo && (
                <button
                  type="button"
                  onClick={onToggleVideo}
                  className="flex flex-col items-center gap-1 group cursor-pointer"
                >
                  <div
                    className={`w-12 h-12 rounded-full flex items-center justify-center transition-all border ${
                      callSession.isVideoOff
                        ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                        : 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700'
                    }`}
                  >
                    {callSession.isVideoOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
                  </div>
                  <span className="text-[10px] font-bold text-slate-300">
                    {callSession.isVideoOff ? 'فتح الكاميرا' : 'إيقاف الكاميرا'}
                  </span>
                </button>
              )}

              {/* Switch camera flip if Video call */}
              {isVideo && (
                <button
                  type="button"
                  onClick={onSwitchCamera}
                  className="flex flex-col items-center gap-1 group cursor-pointer"
                >
                  <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 text-white hover:bg-slate-700 flex items-center justify-center transition-all">
                    <SwitchCamera className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold text-slate-300">تبديل الكاميرا</span>
                </button>
              )}

              {/* End Call */}
              <button
                type="button"
                onClick={onEndCall}
                className="flex flex-col items-center gap-1 group cursor-pointer"
              >
                <div className="w-12 h-12 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex items-center justify-center shadow-xl shadow-rose-600/40 transition-transform active:scale-95 group-hover:scale-105">
                  <PhoneOff className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-bold text-rose-300">إنهاء المكالمة</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
