import React, { useState } from 'react';
import {
  X,
  ShieldAlert,
  KeyRound,
  Coins,
  VolumeX,
  ShieldCheck,
  Copy,
  Check,
  Search,
  Lock,
  Users,
  ChevronLeft,
  ArrowRight,
  BarChart3,
  UserX,
  UserCheck,
  AlertOctagon,
  Ban,
  Clock,
  Camera,
  CheckCircle2,
  XCircle,
  Eye,
} from 'lucide-react';
import { UserAccount, VerificationRequest } from '../../types';

interface AdminModalProps {
  currentUser: string;
  account: UserAccount | undefined;
  cloudAccounts: Record<string, UserAccount>;
  verificationRequests?: VerificationRequest[];
  onClose: () => void;
  onChangePassword: (target: string, newPass: string) => void;
  onToggleMod: (target: string) => void;
  onGrantPoints: (target: string, amount: number) => void;
  onMuteUser: (target: string, minutes: number) => void;
  onToggleBanUser: (target: string, isBanned: boolean, reason?: string) => void;
  onApproveVerification: (username: string) => void;
  onRejectVerification: (username: string) => void;
  onViewImage?: (url: string) => void;
}

type AdminModuleType =
  | 'verification_requests'
  | 'ban_management'
  | 'users_registry'
  | 'grant_coins'
  | 'passwords'
  | 'moderators'
  | 'mute_sanctions'
  | 'system_stats';

export const AdminModal: React.FC<AdminModalProps> = ({
  account,
  cloudAccounts,
  verificationRequests = [],
  onClose,
  onChangePassword,
  onToggleMod,
  onGrantPoints,
  onMuteUser,
  onToggleBanUser,
  onApproveVerification,
  onRejectVerification,
  onViewImage,
}) => {
  const [activeModule, setActiveModule] = useState<AdminModuleType | null>(null);
  const [passTarget, setPassTarget] = useState('');
  const [newPass, setNewPass] = useState('');
  const [modTarget, setModTarget] = useState('');
  const [pointsTarget, setPointsTarget] = useState('');
  const [pointsAmount, setPointsAmount] = useState('100');
  const [muteTarget, setMuteTarget] = useState('');
  const [muteMins, setMuteMins] = useState('15');
  const [banTarget, setBanTarget] = useState('');
  const [banReason, setBanReason] = useState('مخالفة شروط التطبيق');
  const [accountSearch, setAccountSearch] = useState('');
  const [copiedUser, setCopiedUser] = useState<string | null>(null);

  const isAdmin = account?.isAdmin;
  const allUsernames = Object.keys(cloudAccounts);
  const totalUsers = allUsernames.length;
  const bannedCount = allUsernames.filter((u) => !!cloudAccounts[u]?.isBanned).length;
  const modCount = Object.values(cloudAccounts).filter((a) => a.isMod || a.isAdmin).length;
  const pendingVerifCount = verificationRequests.filter((r) => r.status === 'pending').length;

  const selectUserForAction = (u: string, targetModule?: AdminModuleType) => {
    setPassTarget(u);
    setPointsTarget(u);
    setModTarget(u);
    setMuteTarget(u);
    setBanTarget(u);
    if (targetModule) {
      setActiveModule(targetModule);
    }
  };

  const handleExecuteBan = (target: string, reasonText?: string) => {
    if (!target.trim()) return;
    const clean = target.trim();
    if (cloudAccounts[clean]?.isAdmin) {
      alert('لا يمكن حظر حساب الأدمن الرئيسي!');
      return;
    }
    const finalReason = reasonText || banReason || 'مخالفة الشروط';
    onToggleBanUser(clean, true, finalReason);
    setBanTarget('');
  };

  const handleExecuteUnban = (target: string) => {
    if (!target.trim()) return;
    const clean = target.trim();
    onToggleBanUser(clean, false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-lg bg-slate-900 border border-purple-500/40 rounded-3xl p-4 sm:p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto text-right">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-md shadow-amber-500/10">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">لوحة تحكم الإدارة العليا</h3>
              <p className="text-[11px] text-purple-300/80">
                الصلاحية: {isAdmin ? 'مسؤول رئيسي (Admin)' : 'مشرف عام (Mod)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {activeModule === null ? (
          <div className="space-y-3.5 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-200">الأقسام الإدارية:</span>
              <div className="flex items-center gap-2">
                {pendingVerifCount > 0 && (
                  <span className="text-[10px] bg-pink-500/20 text-pink-300 px-2 py-0.5 rounded-full border border-pink-500/40 font-bold flex items-center gap-1 animate-pulse">
                    <Camera className="w-3 h-3 text-pink-400" />
                    <span>{pendingVerifCount} طلب توثيق</span>
                  </span>
                )}
                {bannedCount > 0 && (
                  <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30 font-bold flex items-center gap-1">
                    <UserX className="w-3 h-3 text-rose-400" />
                    <span>{bannedCount} محظور</span>
                  </span>
                )}
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full border border-purple-500/30 font-bold">
                  {totalUsers} مستخدم
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* 1. طلبات التوثيق (VERIFICATION REQUESTS - PROMINENT FEATURE) */}
              <button
                onClick={() => setActiveModule('verification_requests')}
                className="col-span-2 group relative p-4 rounded-2xl bg-gradient-to-r from-purple-950/80 via-pink-950/60 to-slate-950 border-2 border-pink-500/50 hover:border-pink-400 transition-all text-right flex items-center justify-between shadow-xl shadow-pink-950/40 active:scale-98 cursor-pointer"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-pink-500 to-purple-600 text-white flex items-center justify-center shadow-lg shadow-pink-500/30 shrink-0">
                    <Camera className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white group-hover:text-pink-300 transition-colors flex items-center gap-1.5">
                      <span>طلبات توثيق صور المستخدمين</span>
                      {pendingVerifCount > 0 && (
                        <span className="w-2.5 h-2.5 rounded-full bg-pink-400 animate-ping" />
                      )}
                    </h4>
                    <p className="text-[11px] text-slate-300 mt-0.5">
                      مراجعة الصور الرباعية وقبول أو رفض توثيق حسابات المستخدمين
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="px-3 py-1 rounded-xl bg-pink-500/20 border border-pink-500/40 text-pink-300 font-mono font-black text-xs">
                    {pendingVerifCount} طلب
                  </span>
                  <ChevronLeft className="w-4 h-4 text-pink-400 group-hover:-translate-x-1 transition-transform" />
                </div>
              </button>

              {/* 2. إدارة الحظر والحظر الفوري */}
              <button
                onClick={() => setActiveModule('ban_management')}
                className="group relative p-4 rounded-2xl bg-gradient-to-br from-rose-950/70 via-red-950/40 to-slate-950 border border-rose-500/40 hover:border-rose-400 hover:bg-rose-950/90 transition-all text-right flex flex-col justify-between h-36 shadow-lg shadow-rose-950/50 active:scale-97 cursor-pointer"
              >
                <div className="flex items-start justify-between w-full">
                  <div className="w-10 h-10 rounded-xl bg-rose-600/30 group-hover:bg-rose-600 group-hover:text-white text-rose-300 border border-rose-500/50 flex items-center justify-center transition-all shadow-md">
                    <Ban className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg border bg-rose-500/30 text-rose-200 border-rose-500/50">
                    {bannedCount} محظور
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-black text-white group-hover:text-rose-200 transition-colors">
                    إدارة الحظر
                  </h4>
                  <p className="text-[10px] text-slate-400 group-hover:text-slate-300 mt-0.5 line-clamp-1">
                    حظر وطرد وفك الحظر
                  </p>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-rose-400 group-hover:translate-x-[-2px] transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </button>

              {/* 3. سجل الحسابات وكلمات المرور */}
              <button
                onClick={() => setActiveModule('users_registry')}
                className="group relative p-4 rounded-2xl bg-gradient-to-br from-blue-950/60 to-slate-950 border border-blue-500/30 hover:border-blue-400 hover:bg-blue-950/80 transition-all text-right flex flex-col justify-between h-36 shadow-lg shadow-blue-950/40 active:scale-97 cursor-pointer"
              >
                <div className="flex items-start justify-between w-full">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/25 group-hover:bg-blue-600 group-hover:text-white text-blue-400 border border-blue-500/40 flex items-center justify-center transition-all shadow-md">
                    <Users className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-mono font-bold bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-lg border border-blue-500/30">
                    {totalUsers} مسجل
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-black text-white group-hover:text-blue-200 transition-colors">
                    سجل المستخدمين
                  </h4>
                  <p className="text-[10px] text-slate-400 group-hover:text-slate-300 mt-0.5 line-clamp-1">
                    عرض الحسابات والبيانات
                  </p>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-blue-400 group-hover:translate-x-[-2px] transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </button>

              {/* 4. شحن وتوزيع الكوينز */}
              <button
                onClick={() => setActiveModule('grant_coins')}
                className="group relative p-4 rounded-2xl bg-gradient-to-br from-emerald-950/60 to-slate-950 border border-emerald-500/30 hover:border-emerald-400 hover:bg-emerald-950/80 transition-all text-right flex flex-col justify-between h-36 shadow-lg shadow-emerald-950/40 active:scale-97 cursor-pointer"
              >
                <div className="flex items-start justify-between w-full">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600/25 group-hover:bg-emerald-600 group-hover:text-white text-emerald-400 border border-emerald-500/40 flex items-center justify-center transition-all shadow-md">
                    <Coins className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-lg border border-emerald-500/30">
                    رصيد
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-black text-white group-hover:text-emerald-200 transition-colors">
                    شحن كوينز
                  </h4>
                  <p className="text-[10px] text-slate-400 group-hover:text-slate-300 mt-0.5 line-clamp-1">
                    إرسال نقاط لأي مستخدم
                  </p>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-400 group-hover:translate-x-[-2px] transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </button>

              {/* 5. تغيير كلمات السر */}
              <button
                onClick={() => setActiveModule('passwords')}
                className="group relative p-4 rounded-2xl bg-gradient-to-br from-amber-950/60 to-slate-950 border border-amber-500/30 hover:border-amber-400 hover:bg-amber-950/80 transition-all text-right flex flex-col justify-between h-36 shadow-lg shadow-amber-950/40 active:scale-97 cursor-pointer"
              >
                <div className="flex items-start justify-between w-full">
                  <div className="w-10 h-10 rounded-xl bg-amber-600/25 group-hover:bg-amber-600 group-hover:text-white text-amber-400 border border-amber-500/40 flex items-center justify-center transition-all shadow-md">
                    <KeyRound className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-lg border border-amber-500/30">
                    أمان
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-black text-white group-hover:text-amber-200 transition-colors">
                    كلمات المرور
                  </h4>
                  <p className="text-[10px] text-slate-400 group-hover:text-slate-300 mt-0.5 line-clamp-1">
                    تعديل أو استعادة السر
                  </p>
                </div>
                <div className="flex items-center gap-1 text-[10px] font-bold text-amber-400 group-hover:translate-x-[-2px] transition-transform">
                  <span>فتح القسم</span>
                  <ChevronLeft className="w-3.5 h-3.5" />
                </div>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4 animate-in fade-in slide-in-from-right-3 duration-200">
            {/* Module Top Navigation */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <button
                onClick={() => setActiveModule(null)}
                className="px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 border border-purple-500/40 text-purple-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <ArrowRight className="w-4 h-4" />
                <span>العودة للأقسام الإدارية</span>
              </button>
              <span className="text-xs font-bold text-slate-400">
                {activeModule === 'verification_requests' && 'طلبات التوثيق'}
                {activeModule === 'ban_management' && 'إدارة الحظر'}
                {activeModule === 'users_registry' && 'سجل المستخدمين'}
                {activeModule === 'grant_coins' && 'شحن الكوينز'}
                {activeModule === 'passwords' && 'كلمات السر'}
              </span>
            </div>

            {/* MODULE 1: VERIFICATION REQUESTS (طلبات التوثيق - EXACT REQUIREMENT) */}
            {activeModule === 'verification_requests' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-black text-white flex items-center gap-1.5">
                      <Camera className="w-4 h-4 text-pink-400" />
                      <span>طلبات التوثيق بالصور الرباعية</span>
                    </h4>
                    <p className="text-[11px] text-slate-400">
                      راجع صور المستخدم (أمام، يسار، يمين، أسفل) وقرر قبول أو رفض التوثيق
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-pink-300 bg-pink-500/20 px-2.5 py-1 rounded-xl border border-pink-500/30">
                    {verificationRequests.length} طلب
                  </span>
                </div>

                {verificationRequests.length === 0 ? (
                  <div className="p-8 rounded-3xl bg-slate-950/60 border border-slate-800 text-center text-slate-500 text-xs space-y-2">
                    <Camera className="w-8 h-8 mx-auto text-slate-600" />
                    <p>لا توجد طلبات توثيق جديدة حالياً.</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-0.5">
                    {verificationRequests.map((req) => {
                      const userAcc = cloudAccounts[req.username];
                      const dateStr = new Date(req.submittedAt).toLocaleTimeString('ar-EG');
                      const isApproved = req.status === 'approved';
                      const isRejected = req.status === 'rejected';

                      return (
                        <div
                          key={req.id}
                          className="p-4 rounded-3xl bg-slate-950/90 border border-purple-500/30 shadow-xl space-y-3"
                        >
                          {/* User Header */}
                          <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2.5">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div className="w-10 h-10 rounded-2xl overflow-hidden bg-slate-800 border border-purple-500/40 shrink-0">
                                {req.avatar ? (
                                  <img src={req.avatar} alt={req.username} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="w-full h-full flex items-center justify-center font-bold text-white bg-purple-700">
                                    {req.username.slice(0, 1).toUpperCase()}
                                  </div>
                                )}
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-white text-xs truncate">
                                    {userAcc?.displayName || req.username}
                                  </span>
                                  <span className="text-[10px] text-purple-300">({userAcc?.gender || req.gender || 'مستخدم'})</span>
                                </div>
                                <span className="text-[10px] text-slate-400">
                                  وقت التقديم: {dateStr}
                                </span>
                              </div>
                            </div>

                            {/* Status badge */}
                            <div>
                              {isApproved ? (
                                <span className="px-2.5 py-1 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-black">
                                  تم القبول ✓
                                </span>
                              ) : isRejected ? (
                                <span className="px-2.5 py-1 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-300 text-[10px] font-black">
                                  تم الرفض ✕
                                </span>
                              ) : (
                                <span className="px-2.5 py-1 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-[10px] font-black animate-pulse">
                                  قيد الانتظار
                                </span>
                              )}
                            </div>
                          </div>

                          {/* 4 Captured Verification Photos Display (أمام، يسار، يمين، أسفل) */}
                          <div>
                            <div className="flex items-center justify-between text-[11px] font-bold text-slate-300 mb-1.5">
                              <span>الصور الأربعة الملتقطة للوجه:</span>
                              <span className="text-[10px] text-slate-500">اضغط لتكبير الصورة</span>
                            </div>
                            <div className="grid grid-cols-4 gap-2">
                              {[
                                { title: 'أمام (3s)', src: req.photos.front },
                                { title: 'يسار (3s)', src: req.photos.left },
                                { title: 'يمين (3s)', src: req.photos.right },
                                { title: 'أسفل (3s)', src: req.photos.down },
                              ].map((item, idx) => (
                                <div
                                  key={idx}
                                  onClick={() => onViewImage && item.src && onViewImage(item.src)}
                                  className="space-y-1 text-center cursor-pointer group"
                                >
                                  <div className="w-full aspect-square rounded-xl overflow-hidden border border-purple-500/30 group-hover:border-purple-400 transition-all bg-slate-900 shadow-md">
                                    {item.src ? (
                                      <img
                                        src={item.src}
                                        alt={item.title}
                                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                      />
                                    ) : (
                                      <div className="w-full h-full flex items-center justify-center text-[10px] text-slate-600">
                                        فارغ
                                      </div>
                                    )}
                                  </div>
                                  <span className="text-[9px] font-bold text-slate-400 block truncate">
                                    {item.title}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* ACTION BUTTONS: مقبول & مرفوض (EXACT USER REQUIREMENT) */}
                          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800">
                            {/* مرفوض (Reject Button) */}
                            <button
                              type="button"
                              onClick={() => onRejectVerification(req.username)}
                              className="py-2.5 px-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-black transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer shadow-md"
                            >
                              <XCircle className="w-4 h-4 text-rose-400" />
                              <span>مرفوض (إعادة التوثيق)</span>
                            </button>

                            {/* مقبول (Accept Button) */}
                            <button
                              type="button"
                              onClick={() => onApproveVerification(req.username)}
                              className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:brightness-110 border border-emerald-400/50 text-white text-xs font-black transition-all flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer shadow-lg shadow-emerald-600/30"
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              <span>مقبول (توثيق الحساب)</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* MODULE 2: BAN MANAGEMENT */}
            {activeModule === 'ban_management' && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-rose-950/60 to-slate-950 border border-rose-500/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-rose-300 flex items-center gap-1.5">
                      <Ban className="w-4 h-4 text-rose-400" />
                      <span>حظر مستخدم جديد فوراً</span>
                    </h4>
                  </div>
                  <input
                    type="text"
                    placeholder="اسم المستخدم..."
                    value={banTarget}
                    onChange={(e) => setBanTarget(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-rose-500"
                  />
                  <input
                    type="text"
                    placeholder="سبب الحظر..."
                    value={banReason}
                    onChange={(e) => setBanReason(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-rose-500"
                  />
                  <button
                    type="button"
                    onClick={() => handleExecuteBan(banTarget)}
                    disabled={!banTarget.trim()}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-red-600 text-white text-xs font-black shadow-lg cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-40"
                  >
                    <Ban className="w-4 h-4" />
                    <span>تأكيد الحظر والطرد</span>
                  </button>
                </div>

                {/* Banned Users */}
                <div className="space-y-2">
                  <span className="text-xs font-bold text-slate-300 block">
                    المستخدمون المحظورون ({bannedCount})
                  </span>
                  {bannedCount === 0 ? (
                    <div className="p-4 rounded-xl bg-slate-950/40 text-center text-slate-500 text-xs">
                      لا يوجد أي مستخدم محظور.
                    </div>
                  ) : (
                    allUsernames
                      .filter((u) => cloudAccounts[u]?.isBanned)
                      .map((u) => (
                        <div
                          key={u}
                          className="p-3 rounded-2xl bg-slate-950 border border-rose-500/40 flex items-center justify-between gap-2"
                        >
                          <div>
                            <span className="text-xs font-bold text-white block">{u}</span>
                            <span className="text-[10px] text-rose-300">
                              السبب: {cloudAccounts[u]?.banReason || 'مخالفة'}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleExecuteUnban(u)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40 cursor-pointer"
                          >
                            فك الحظر
                          </button>
                        </div>
                      ))
                  )}
                </div>
              </div>
            )}

            {/* MODULE 3: USERS REGISTRY */}
            {activeModule === 'users_registry' && (
              <div className="space-y-3">
                <div className="relative">
                  <input
                    type="text"
                    value={accountSearch}
                    onChange={(e) => setAccountSearch(e.target.value)}
                    placeholder="بحث بالاسم أو ID..."
                    className="w-full py-2 px-3 pr-9 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white outline-none focus:border-blue-400"
                  />
                  <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                </div>
                <div className="max-h-72 overflow-y-auto space-y-2">
                  {allUsernames
                    .filter((u) => {
                      if (!accountSearch.trim()) return true;
                      const q = accountSearch.toLowerCase().trim();
                      return u.toLowerCase().includes(q) || (cloudAccounts[u]?.idNum && cloudAccounts[u].idNum.includes(q));
                    })
                    .map((u) => {
                      const acc = cloudAccounts[u];
                      const isBanned = !!acc.isBanned;
                      return (
                        <div
                          key={u}
                          className={`p-3 rounded-2xl bg-slate-950 border ${
                            isBanned ? 'border-rose-500/50' : 'border-slate-800'
                          } flex items-center justify-between gap-2`}
                        >
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-white">{u}</span>
                              {acc.isVerified && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold">
                                  موثق ✓
                                </span>
                              )}
                              {isBanned && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-bold">
                                  محظور
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] text-slate-400 font-mono">
                              ID: {acc.idNum || '—'} | كوينز: {acc.points || 0}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => selectUserForAction(u, 'grant_coins')}
                              className="px-2 py-1 rounded-lg bg-emerald-600/20 text-emerald-300 text-[10px] font-bold cursor-pointer"
                            >
                              +شحن
                            </button>
                            <button
                              onClick={() => selectUserForAction(u, 'passwords')}
                              className="px-2 py-1 rounded-lg bg-amber-600/20 text-amber-300 text-[10px] font-bold cursor-pointer"
                            >
                              السر
                            </button>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* MODULE 4: GRANT COINS */}
            {activeModule === 'grant_coins' && (
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30 space-y-3">
                <h4 className="text-xs font-bold text-emerald-300">شحن كوينز لمستخدم</h4>
                <input
                  type="text"
                  placeholder="اسم المستخدم..."
                  value={pointsTarget}
                  onChange={(e) => setPointsTarget(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-emerald-500"
                />
                <input
                  type="number"
                  placeholder="عدد الكوينز..."
                  value={pointsAmount}
                  onChange={(e) => setPointsAmount(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-emerald-500"
                />
                <button
                  onClick={() => {
                    const amt = parseInt(pointsAmount, 10);
                    if (pointsTarget && amt > 0) {
                      onGrantPoints(pointsTarget.trim(), amt);
                      setPointsTarget('');
                      alert(`تم شحن ${amt} كوينز للمستخدم ${pointsTarget}!`);
                    }
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-black shadow-lg cursor-pointer"
                >
                  إرسال الكوينز الآن
                </button>
              </div>
            )}

            {/* MODULE 5: PASSWORDS */}
            {activeModule === 'passwords' && (
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-3">
                <h4 className="text-xs font-bold text-amber-300">تغيير كلمة مرور</h4>
                <input
                  type="text"
                  placeholder="اسم المستخدم..."
                  value={passTarget}
                  onChange={(e) => setPassTarget(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-amber-500"
                />
                <input
                  type="text"
                  placeholder="كلمة السر الجديدة..."
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white outline-none focus:border-amber-500"
                />
                <button
                  onClick={() => {
                    if (passTarget && newPass) {
                      onChangePassword(passTarget.trim(), newPass);
                      setPassTarget('');
                      setNewPass('');
                      alert(`تم تحديث كلمة المرور لـ ${passTarget}`);
                    }
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 text-xs font-black shadow-lg cursor-pointer"
                >
                  حفظ كلمة السر الجديدة
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
