import React, { useState } from 'react';
import {
  X,
  Copy,
  Save,
  Globe,
  User,
  Sparkles,
  ChevronDown,
  Search,
  Check,
  Languages,
} from 'lucide-react';
import { UserAccount } from '../../types';
import { COUNTRIES } from '../../constants';
import { Language, translations } from '../../utils/i18n';

interface EditProfileModalProps {
  account: UserAccount | undefined;
  currentUser: string;
  lang?: Language;
  onClose: () => void;
  onSave: (
    newAge: number,
    newBio: string,
    newCountry: string,
    newCountryFlag: string,
    newDisplayName: string,
    newLang: Language
  ) => void;
  onToggleLanguage?: (lang: Language) => void;
  onCopyId: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({
  account,
  currentUser,
  lang = 'ar',
  onClose,
  onSave,
  onToggleLanguage,
  onCopyId,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const [displayName, setDisplayName] = useState(account?.displayName || currentUser || '');
  const [selectedCountry, setSelectedCountry] = useState(account?.country || 'مصر');
  const [selectedFlag, setSelectedFlag] = useState(account?.countryFlag || '🇪🇬');
  const [age, setAge] = useState(account?.age?.toString() || '22');
  const [bio, setBio] = useState(account?.bio || '');
  const [currentLang, setCurrentLang] = useState<Language>(lang);
  const [showCountryPicker, setShowCountryPicker] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const handleCountrySelect = (cName: string, cFlag: string) => {
    setSelectedCountry(cName);
    setSelectedFlag(cFlag);
    setShowCountryPicker(false);
    setSearchQuery('');
  };

  const filteredCountries = COUNTRIES.filter((c) =>
    c.name.includes(searchQuery.trim())
  );

  const handleLanguageChange = (newLang: Language) => {
    setCurrentLang(newLang);
    if (onToggleLanguage) {
      onToggleLanguage(newLang);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAge = parseInt(age, 10) || 20;
    onSave(
      numAge,
      bio.trim(),
      selectedCountry,
      selectedFlag,
      displayName.trim() || currentUser,
      currentLang
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-sm max-h-[92vh] overflow-y-auto bg-slate-900 border border-purple-500/30 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <h3 className="text-base font-bold text-white">{t.editProfile}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Language Switcher Section (Requested: زر تحويل لغة عربية او انجليزي) */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-950/70 via-indigo-950/50 to-slate-950 border border-purple-500/40 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-purple-200">
            <span className="flex items-center gap-1.5">
              <Languages className="w-4 h-4 text-amber-400" />
              <span>{t.langToggle}</span>
            </span>
            <span className="text-[10px] text-amber-300 font-mono font-bold">
              {currentLang === 'ar' ? 'العربية' : 'English'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleLanguageChange('ar')}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                currentLang === 'ar'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30 border border-purple-400/60'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 border border-slate-800'
              }`}
            >
              <span>العربية (RTL)</span>
              {currentLang === 'ar' && <Check className="w-3.5 h-3.5" />}
            </button>

            <button
              type="button"
              onClick={() => handleLanguageChange('en')}
              className={`py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                currentLang === 'en'
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-md shadow-purple-600/30 border border-purple-400/60'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-400 border border-slate-800'
              }`}
            >
              <span>English (LTR)</span>
              {currentLang === 'en' && <Check className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {/* Readonly ID */}
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">
              {t.idLabel}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={account?.idNum || ''}
                className="flex-1 p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-purple-300 font-mono text-xs outline-none text-center font-bold"
              />
              <button
                type="button"
                onClick={onCopyId}
                className="px-3 rounded-xl bg-purple-600/30 text-purple-200 border border-purple-500/30 hover:bg-purple-600/50 text-xs font-bold transition-all cursor-pointer"
                title="نسخ ID"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Account Display Name */}
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">
              {isRtl ? 'الاسم المستعار' : 'Display Name'}
            </label>
            <div className="relative">
              <input
                type="text"
                maxLength={24}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder="اكتب اسمك..."
                className="w-full p-2.5 pr-8 rounded-xl bg-slate-950 border border-purple-500/40 text-white font-bold text-xs outline-none focus:border-purple-400 placeholder-slate-500"
              />
              <User className="w-3.5 h-3.5 text-purple-400 absolute right-2.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* Country Selector Button */}
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1.5">
              {isRtl ? 'الدولة والعلم' : 'Country & Flag'}
            </label>
            <button
              type="button"
              onClick={() => setShowCountryPicker(true)}
              className="w-full p-3 rounded-2xl bg-slate-950/90 hover:bg-slate-800/90 border border-emerald-500/40 hover:border-emerald-400 transition-all flex items-center justify-between group shadow-md text-right cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <span className="text-2xl filter drop-shadow-sm">{selectedFlag}</span>
                <div>
                  <span className="text-xs font-black text-white block group-hover:text-emerald-300 transition-colors">
                    {selectedCountry}
                  </span>
                  <span className="text-[10px] text-emerald-400/80">
                    {isRtl ? 'انقر لتغيير الدولة' : 'Click to change country'}
                  </span>
                </div>
              </div>
              <span className="text-xs font-bold text-emerald-300 px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center gap-1 group-hover:bg-emerald-500/25 transition-all">
                <span>{isRtl ? 'تغيير' : 'Change'}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </span>
            </button>
          </div>

          {/* Age */}
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">
              {isRtl ? 'العمر' : 'Age'}:
            </label>
            <input
              type="number"
              min="10"
              max="99"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs outline-none focus:border-purple-500 text-center font-bold"
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-xs font-bold text-purple-200 mb-1">
              {isRtl ? 'النبذة التعريفية (Bio)' : 'Bio'}:
            </label>
            <textarea
              rows={2}
              maxLength={70}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="اكتب نبذة عنك..."
              className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white placeholder-slate-500 text-xs outline-none focus:border-purple-500 resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 hover:opacity-95 active:scale-98 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{isRtl ? 'حفظ التعديلات' : 'Save Changes'}</span>
          </button>
        </form>
      </div>

      {/* Country Selection Modal */}
      {showCountryPicker && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-xs bg-slate-900 border border-emerald-500/30 rounded-3xl p-4 shadow-2xl space-y-3 flex flex-col max-h-[80vh] text-right">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold text-white">اختر دولتك</h4>
              </div>
              <button
                type="button"
                onClick={() => setShowCountryPicker(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث..."
                className="w-full p-2.5 pr-8 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs outline-none focus:border-emerald-500 placeholder-slate-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
            </div>
            <div className="flex-1 overflow-y-auto space-y-1 pr-0.5">
              {filteredCountries.map((c) => {
                const isSelected = selectedCountry === c.name;
                return (
                  <button
                    key={c.code}
                    type="button"
                    onClick={() => handleCountrySelect(c.name, c.flag)}
                    className={`w-full p-2.5 rounded-xl flex items-center justify-between text-right text-xs font-bold transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-600/30 border border-emerald-500/50 text-emerald-200'
                        : 'bg-slate-950/60 hover:bg-slate-800/80 border border-slate-800/80 text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-xl">{c.flag}</span>
                      <span>{c.name}</span>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
