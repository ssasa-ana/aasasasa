import React from 'react';
import { X, UserPlus, UserCheck, MessageSquare, VolumeX, Volume2, Copy, ShieldCheck } from 'lucide-react';
import { UserAccount } from '../../types';

interface UserProfileModalProps {
  targetUser: string;
  account: UserAccount | undefined;
  isFollowing: boolean;
  isMuted: boolean;
  onClose: () => void;
  onToggleFollow: () => void;
  onToggleMute: () => void;
  onStartDm: () => void;
}

export const UserProfileModal: React.FC<UserProfileModalProps> = ({
  targetUser,
  account,
  isFollowing,
  isMuted,
  onClose,
  onToggleFollow,
  onToggleMute,
  onStartDm,
}) => {
  const displayName = account?.displayName || targetUser;
  const userCountry = account?.country || 'مصر';
  const userCountryFlag = account?.countryFlag || '🇪🇬';
  const isVerified = Boolean(account?.isVerified);

  const handleCopyId = () => {
    if (account?.idNum) {
      navigator.clipboard?.writeText(account.idNum);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-sm bg-slate-900 border border-purple-500/30 rounded-3xl p-5 shadow-2xl space-y-4 text-right relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        {/* User Card: Avatar on Side + Name, ID, Flag next to it */}
        <div className="flex items-center gap-3.5 pt-2">
          {/* Avatar */}
          <div className="w-20 h-20 rounded-full shrink-0 p-1 bg-gradient-to-tr from-amber-400 via-purple-500 to-pink-500 shadow-xl shadow-purple-600/30">
            <div className="w-full h-full rounded-full bg-slate-950 overflow-hidden flex items-center justify-center">
              {account?.avatar ? (
                <img src={account.avatar} alt={displayName} className="w-full h-full object-cover" />
              ) : (
                <span className="text-2xl font-black text-white">
                  {displayName.slice(0, 1).toUpperCase()}
                </span>
              )}
            </div>
          </div>

          {/* Name & Badges next to avatar */}
          <div className="flex-1 min-w-0 space-y-1">
            <div className="flex items-center gap-1.5">
              <h3 className="text-lg font-black text-white truncate">{displayName}</h3>
              {isVerified && (
                <span title="موثق رسمياً">
                  <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                </span>
              )}
            </div>

            {/* Country and ID Row */}
            <div className="flex flex-wrap items-center gap-1.5 text-xs">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-800 border border-slate-700 text-white font-bold text-[11px]">
                <span>{userCountryFlag}</span>
                <span>{userCountry}</span>
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-purple-950/80 border border-purple-500/30 text-purple-200 font-mono text-[11px]">
                <span>ID: {account?.idNum || '--------'}</span>
                <button onClick={handleCopyId} title="نسخ ID" className="hover:text-white cursor-pointer">
                  <Copy className="w-3 h-3 text-purple-400" />
                </button>
              </span>
            </div>

            {/* Gender and Age */}
            <div className="flex items-center gap-1.5 pt-0.5">
              <span className="px-2 py-0.5 rounded-md bg-purple-600/20 text-purple-200 text-[10px] font-bold border border-purple-500/30">
                {account?.gender || 'مستخدم'}
              </span>
              <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]">
                {account?.age || 22} سنة
              </span>
            </div>
          </div>
        </div>

        {/* Bio */}
        {account?.bio && (
          <p className="text-xs text-slate-300 italic px-2 py-1 bg-slate-950/60 rounded-xl border border-slate-800">
            "{account.bio}"
          </p>
        )}

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2.5 pt-1">
          <button
            onClick={onToggleFollow}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
              isFollowing
                ? 'bg-emerald-600/30 border border-emerald-500/40 text-emerald-300'
                : 'bg-purple-600 hover:bg-purple-500 text-white shadow-md'
            }`}
          >
            {isFollowing ? <UserCheck className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            <span>{isFollowing ? 'متابَع' : 'متابعة'}</span>
          </button>

          <button
            onClick={() => {
              onClose();
              onStartDm();
            }}
            className="py-2.5 px-3 rounded-xl bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>محادثة</span>
          </button>
        </div>

        {/* Mute User Button */}
        <button
          onClick={onToggleMute}
          className={`w-full py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            isMuted
              ? 'bg-slate-800 text-slate-300 border border-slate-700'
              : 'bg-rose-500/20 text-rose-300 border border-rose-500/30 hover:bg-rose-500/30'
          }`}
        >
          {isMuted ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-300" />}
          <span>{isMuted ? 'إلغاء كتم هذا المستخدم' : 'كتم هذا المستخدم (حظر الرسائل)'}</span>
        </button>
      </div>
    </div>
  );
};
