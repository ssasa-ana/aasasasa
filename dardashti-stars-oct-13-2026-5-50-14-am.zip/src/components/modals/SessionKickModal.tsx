import React, { useEffect, useState } from 'react';
import { AlertTriangle, LogOut, ShieldAlert, Lock, Clock } from 'lucide-react';

interface SessionKickModalProps {
  username: string;
  reason?: string;
  isBanned?: boolean;
  onLogoutConfirm: () => void;
}

export const SessionKickModal: React.FC<SessionKickModalProps> = ({
  username,
  reason,
  isBanned = false,
  onLogoutConfirm,
}) => {
  const [countdown, setCountdown] = useState(5);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onLogoutConfirm();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [onLogoutConfirm]);

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200 text-right">
      <div className="w-full max-w-sm bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-rose-500/60 rounded-3xl p-6 shadow-2xl shadow-rose-950/80 text-center space-y-5 relative overflow-hidden">
        {/* Glow Effects */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-rose-600/25 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-amber-600/20 rounded-full blur-3xl pointer-events-none" />

        {/* Warning Icon Badge */}
        <div className="relative mx-auto w-16 h-16 rounded-2xl bg-gradient-to-tr from-rose-600 to-amber-500 p-0.5 shadow-xl shadow-rose-600/40 flex items-center justify-center animate-bounce">
          <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
            {isBanned ? (
              <ShieldAlert className="w-8 h-8 text-rose-500" />
            ) : (
              <AlertTriangle className="w-8 h-8 text-amber-400" />
            )}
          </div>
        </div>

        {/* Title */}
        <div className="space-y-1.5">
          <h3 className="text-lg font-black text-white">
            {isBanned
              ? 'تم حظر الحساب من الإدارة'
              : 'تنبيه أمان: تم تسجيل الدخول من جهاز آخر'}
          </h3>
          <p className="text-xs text-rose-300 font-medium leading-relaxed">
            {isBanned
              ? reason || 'تم حظر حسابك لمخالفة شروط وقواعد الاستخدام'
              : `تم فتح حسابك (${username}) من متصفح أو جهاز آخر.`}
          </p>
        </div>

        {/* Warning Details */}
        <div className="p-3.5 rounded-2xl bg-slate-900/90 border border-rose-500/30 text-xs text-slate-300 space-y-2">
          <div className="flex items-center justify-center gap-1.5 text-amber-300 font-bold">
            <Lock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>تسجيل الخروج التلقائي للأمان</span>
          </div>
          <p className="text-[11px] text-slate-400 leading-normal">
            {isBanned
              ? 'تواصل مع إدارة التطبيق في حال وجود أي استفسار.'
              : 'إذا لم تكن أنت من قام بالدخول، يرجى تغيير كلمة المرور فوراً.'}
          </p>
        </div>

        {/* Countdown Box */}
        <div className="flex items-center justify-center gap-2 p-3 rounded-2xl bg-rose-950/40 border border-rose-500/40">
          <Clock className="w-4 h-4 text-rose-400 animate-pulse" />
          <span className="text-xs font-bold text-slate-300">
            سيتم الخروج خلال
          </span>
          <span className="w-7 h-7 rounded-full bg-rose-600 text-white font-mono font-black text-sm flex items-center justify-center shadow-lg shadow-rose-600/50">
            {countdown}
          </span>
        </div>

        {/* Action Button */}
        <button
          type="button"
          onClick={onLogoutConfirm}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-rose-600 via-pink-600 to-rose-700 hover:brightness-110 active:scale-98 text-white font-black text-xs shadow-xl shadow-rose-600/40 transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>خروج الآن</span>
        </button>
      </div>
    </div>
  );
};
