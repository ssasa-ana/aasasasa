import React, { useState } from 'react';
import { X, DollarSign, Send, Zap, Check, Sparkles, Flame, Crown, Coins } from 'lucide-react';

export interface CoinPackage {
  id: string;
  coins: number;
  bonus: number;
  priceUsd: number;
  name: string;
  badge?: string;
  isPopular?: boolean;
  isVip?: boolean;
}

export const COIN_PACKAGES: CoinPackage[] = [
  {
    id: 'pkg_50',
    coins: 50,
    bonus: 0,
    priceUsd: 1,
    name: 'حزمة البداية',
  },
  {
    id: 'pkg_100',
    coins: 100,
    bonus: 10,
    priceUsd: 2,
    name: 'حزمة برونزية',
    badge: '+10 مجاناً',
  },
  {
    id: 'pkg_250',
    coins: 250,
    bonus: 30,
    priceUsd: 5,
    name: 'حزمة فضية',
    badge: '+30 مجاناً',
  },
  {
    id: 'pkg_500',
    coins: 500,
    bonus: 75,
    priceUsd: 10,
    name: 'حزمة ذهبية',
    badge: 'الأكثر طلباً 🔥',
    isPopular: true,
  },
  {
    id: 'pkg_1000',
    coins: 1000,
    bonus: 200,
    priceUsd: 20,
    name: 'حزمة VIP',
    badge: 'تاج VIP 👑',
    isVip: true,
  },
  {
    id: 'pkg_2500',
    coins: 2500,
    bonus: 600,
    priceUsd: 50,
    name: 'حزمة أسطورية',
    badge: 'توفير خارق',
  },
  {
    id: 'pkg_5000',
    coins: 5000,
    bonus: 1500,
    priceUsd: 100,
    name: 'حزمة الملوك',
    badge: '+1500 كوينز 👑',
    isVip: true,
  },
];

interface BuyCoinsModalProps {
  myCoins?: number;
  onClose: () => void;
  onRequestBuy: (points: number) => void;
}

export const BuyCoinsModal: React.FC<BuyCoinsModalProps> = ({ myCoins, onClose, onRequestBuy }) => {
  const [selectedPkgId, setSelectedPkgId] = useState<string>('pkg_500');
  const [isCustomMode, setIsCustomMode] = useState<boolean>(false);
  const [customCoins, setCustomCoins] = useState<number>(300);

  const selectedPkg = COIN_PACKAGES.find((p) => p.id === selectedPkgId) || COIN_PACKAGES[3];
  const effectiveCoins = isCustomMode ? customCoins : selectedPkg.coins + selectedPkg.bonus;
  const effectivePrice = isCustomMode ? (customCoins / 50).toFixed(2) : selectedPkg.priceUsd.toFixed(2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (effectiveCoins <= 0) return;
    onRequestBuy(effectiveCoins);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border border-amber-500/35 rounded-3xl p-4 sm:p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-amber-500/30 to-yellow-400/20 border border-amber-500/40 text-amber-300 flex items-center justify-center text-lg shadow-sm">
              🪙
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center gap-1.5">
                <span>شحن رصيد الكوينز</span>
                <Sparkles className="w-4 h-4 text-amber-400" />
              </h3>
              <p className="text-[11px] text-amber-300/80">
                استمتع بإرسال الهدايا والمكالمات
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Current Balance */}
        {myCoins !== undefined && (
          <div className="flex items-center justify-between px-3.5 py-2 rounded-2xl bg-slate-950/80 border border-purple-500/20 text-xs">
            <span className="text-slate-400 font-medium">رصيدك الحالي:</span>
            <div className="flex items-center gap-1.5 font-bold text-amber-300">
              <span className="text-sm font-mono font-black">{myCoins.toLocaleString()}</span>
              <span>كوينز</span>
            </div>
          </div>
        )}

        {/* Packages Grid */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300 px-1">
            <span>اختر باقة الكوينز:</span>
            <span className="text-[11px] text-amber-400 flex items-center gap-1">
              <Zap className="w-3 h-3 fill-amber-400" />
              <span>تسليم فوري عبر الإدارة</span>
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-0.5">
            {COIN_PACKAGES.map((pkg) => {
              const isSelected = !isCustomMode && selectedPkgId === pkg.id;
              const totalCoins = pkg.coins + pkg.bonus;
              return (
                <div
                  key={pkg.id}
                  onClick={() => {
                    setIsCustomMode(false);
                    setSelectedPkgId(pkg.id);
                  }}
                  className={`relative p-3 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between text-right active:scale-97 select-none ${
                    isSelected
                      ? 'bg-gradient-to-br from-amber-500/20 via-purple-950/40 to-slate-950 border-amber-400 shadow-lg shadow-amber-500/15 ring-1 ring-amber-400/50'
                      : 'bg-slate-950/70 hover:bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {pkg.badge && (
                    <div className="absolute -top-2 left-2 px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 text-[9px] font-black shadow-sm flex items-center gap-0.5">
                      {pkg.isPopular ? <Flame className="w-2.5 h-2.5 fill-slate-950" /> : null}
                      {pkg.isVip ? <Crown className="w-2.5 h-2.5 fill-slate-950" /> : null}
                      <span>{pkg.badge}</span>
                    </div>
                  )}

                  <div className="space-y-1">
                    <span className="text-xs font-black text-white block truncate">
                      {pkg.name}
                    </span>
                    <div className="flex items-baseline gap-1 text-amber-300">
                      <span className="text-lg font-black font-mono">{totalCoins.toLocaleString()}</span>
                      <span className="text-[10px] font-bold">كوينز</span>
                    </div>
                    {pkg.bonus > 0 && (
                      <span className="text-[10px] text-emerald-400 font-bold block">
                        +{pkg.bonus} إضافية
                      </span>
                    )}
                  </div>

                  <div className="mt-2 pt-2 border-t border-white/10 flex items-center justify-between">
                    <span className="text-xs font-black text-white font-mono">
                      ${pkg.priceUsd} USD
                    </span>
                    <div
                      className={`w-5 h-5 rounded-full flex items-center justify-center border transition-all ${
                        isSelected
                          ? 'bg-amber-400 border-amber-400 text-slate-950'
                          : 'border-slate-700 bg-slate-900'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Custom amount toggle */}
        <div className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setIsCustomMode(!isCustomMode)}
              className="text-xs font-bold text-amber-300 hover:text-amber-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>{isCustomMode ? 'العودة للباقات الجاهزة' : 'تحديد كمية كوينز مخصصة'}</span>
            </button>
            <span className="text-[10px] text-slate-400">(كل 50 كوينز = 1$)</span>
          </div>

          {isCustomMode && (
            <div className="flex items-center gap-2 pt-1 animate-in fade-in">
              <input
                type="number"
                min="10"
                step="10"
                value={customCoins}
                onChange={(e) => setCustomCoins(Math.max(10, parseInt(e.target.value, 10) || 10))}
                className="flex-1 py-1.5 px-3 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-300 font-bold text-sm text-center outline-none"
                placeholder="عدد الكوينز..."
              />
              <span className="text-xs font-bold text-slate-300 font-mono">
                = ${effectivePrice} USD
              </span>
            </div>
          )}
        </div>

        {/* Selected Package Summary Box */}
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-purple-950/30 border border-amber-500/30 flex items-center justify-between">
          <div className="text-right space-y-0.5">
            <span className="text-[10px] text-slate-400 font-bold block">الكمية الإجمالية:</span>
            <div className="flex items-center gap-1 text-sm font-black text-amber-300">
              <span className="font-mono text-base">{effectiveCoins.toLocaleString()}</span>
              <span>كوينز</span>
            </div>
          </div>
          <div className="text-left space-y-0.5">
            <span className="text-[10px] text-slate-400 font-bold block">السعر المطلوب:</span>
            <span className="text-base font-black text-white font-mono">
              ${effectivePrice} USD
            </span>
          </div>
        </div>

        {/* Submit Button */}
        <form onSubmit={handleSubmit}>
          <button
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:brightness-105 active:scale-98 text-slate-950 font-black text-xs shadow-xl shadow-amber-400/25 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Send className="w-4 h-4 rotate-180" />
            <span>طلب الشحن الآن (${effectivePrice} USD)</span>
          </button>
        </form>
      </div>
    </div>
  );
};

interface WithdrawModalProps {
  myDiamonds: number;
  myCoins?: number;
  onClose: () => void;
  onRequestWithdraw: (amount: number, method?: string, details?: string) => void;
  onConvertToCoins?: (diamondsAmount: number) => void;
}

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  myDiamonds = 0,
  myCoins = 0,
  onClose,
  onRequestWithdraw,
  onConvertToCoins,
}) => {
  const safeDiamonds = myDiamonds || 0;
  const [activeTab, setActiveTab] = useState<'cash' | 'coins'>('cash');
  const [amount, setAmount] = useState(safeDiamonds > 0 ? Math.min(safeDiamonds, 100) : 50);
  const [convertAmount, setConvertAmount] = useState(safeDiamonds > 0 ? Math.min(safeDiamonds, 50) : 10);
  const [paymentMethod, setPaymentMethod] = useState<'instapay' | 'vodafone' | 'paypal' | 'bank' | 'usdt'>('instapay');
  const [accountDetails, setAccountDetails] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const cashEstimate = (amount / 50).toFixed(2);
  const egpEstimate = Math.round((amount / 50) * 50); // ~50 EGP per $1

  const handleCashSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (safeDiamonds < 50) {
      setErrorMsg('الحد الأدنى لسحب الكاش هو 50 ماسة ($1.00 دولار).');
      return;
    }
    if (amount < 10) {
      setErrorMsg('الحد الأدنى للسحب 10 ماسات.');
      return;
    }
    if (amount > safeDiamonds) {
      setErrorMsg(`رصيدك لا يكفي! تمتلك ${safeDiamonds.toLocaleString()} ماسة.`);
      return;
    }
    if (!accountDetails.trim()) {
      setErrorMsg('يرجى كتابة رقم الهاتف أو المحفظة أو الحساب.');
      return;
    }

    const methodLabels: Record<string, string> = {
      instapay: 'انستا باي InstaPay',
      vodafone: 'فودافون كاش',
      paypal: 'باي بال PayPal',
      bank: 'تحويل بنكي',
      usdt: 'USDT (TRC20)',
    };

    onRequestWithdraw(amount, methodLabels[paymentMethod] || paymentMethod, accountDetails.trim());
    onClose();
  };

  const handleCoinsConvertSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (convertAmount <= 0) {
      setErrorMsg('يرجى تحديد عدد الماسات للتحويل.');
      return;
    }
    if (convertAmount > safeDiamonds) {
      setErrorMsg(`رصيدك لا يكفي! تمتلك ${safeDiamonds.toLocaleString()} ماسة.`);
      return;
    }
    if (onConvertToCoins) {
      onConvertToCoins(convertAmount);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border border-emerald-500/40 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-pink-500/30 via-emerald-500/20 to-teal-500/30 border border-pink-500/40 text-pink-300 flex items-center justify-center text-xl shadow-sm">
              💎
            </div>
            <div>
              <h3 className="text-base font-black text-white">سحب أرباح الماس</h3>
              <p className="text-[11px] text-emerald-300/80">حولي أرباحك إلى كاش أو كوينز</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Diamond Balance Hero Card */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-pink-950/70 via-purple-950/50 to-slate-950 border-2 border-pink-500/40 text-center space-y-2.5 shadow-xl shadow-pink-950/40 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/10 rounded-full blur-2xl pointer-events-none" />
          <span className="text-xs text-pink-300 font-bold block">
            رصيد أرباحكِ الحالي من المكالمات والهدايا
          </span>
          <div className="flex items-center justify-center gap-2.5">
            <span className="text-4xl font-black font-mono text-white tracking-wider drop-shadow-md">
              {safeDiamonds.toLocaleString()}
            </span>
            <span className="text-3xl animate-bounce">💎</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-xs text-emerald-300 font-bold">
              <span>القيمة بالدولار:</span>
              <span className="font-mono text-white font-black">${(safeDiamonds / 50).toFixed(2)} USD</span>
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-xs text-amber-300 font-bold">
              <span>القيمة بالجنيه:</span>
              <span className="font-mono text-white font-black">~{Math.round((safeDiamonds / 50) * 50).toLocaleString()} ج.م</span>
            </div>
          </div>
        </div>

        {/* Mode Tabs: Cash vs Convert to Coins */}
        <div className="flex bg-slate-950 p-1 rounded-2xl border border-slate-800 gap-1">
          <button
            type="button"
            onClick={() => {
              setActiveTab('cash');
              setErrorMsg('');
            }}
            className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'cash'
                ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5" />
            <span>سحب كاش (فلوس)</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('coins');
              setErrorMsg('');
            }}
            className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'coins'
                ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Coins className="w-3.5 h-3.5" />
            <span>تحويل إلى كوينز</span>
          </button>
        </div>

        {activeTab === 'cash' ? (
          <form onSubmit={handleCashSubmit} className="space-y-3.5">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-purple-200">
                  عدد الماسات المراد سحبها:
                </label>
                <span className="text-[11px] text-emerald-400 font-mono font-bold">
                  = ${cashEstimate} USD (~{egpEstimate} ج.م)
                </span>
              </div>
              <input
                type="number"
                min="10"
                max={safeDiamonds}
                value={amount}
                onChange={(e) => setAmount(parseInt(e.target.value, 10) || 0)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-pink-300 font-mono font-bold text-base text-center outline-none focus:border-pink-500 shadow-inner"
              />
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] text-slate-400 font-bold">كميات سريعة:</span>
              {[50, 100, 250, 500].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setAmount(Math.min(safeDiamonds, val))}
                  className="px-2.5 py-1 rounded-xl bg-pink-950/60 hover:bg-pink-900/60 border border-pink-500/30 text-pink-300 text-[11px] font-bold transition-all cursor-pointer"
                >
                  {val} 💎
                </button>
              ))}
              {safeDiamonds > 0 && (
                <button
                  type="button"
                  onClick={() => setAmount(safeDiamonds)}
                  className="px-2.5 py-1 rounded-xl bg-emerald-500/25 hover:bg-emerald-500/40 border border-emerald-500/50 text-emerald-300 text-[11px] font-black transition-all cursor-pointer"
                >
                  سحب الكل ({safeDiamonds}) 💎
                </button>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-purple-200 mb-1.5">
                طريقة الاستلام المفضلة:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('instapay')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    paymentMethod === 'instapay'
                      ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  انستا باي InstaPay
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('vodafone')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    paymentMethod === 'vodafone'
                      ? 'bg-rose-500/25 border-rose-400 text-rose-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  فودافون كاش
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    paymentMethod === 'paypal'
                      ? 'bg-blue-500/25 border-blue-400 text-blue-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  باي بال PayPal
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank')}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    paymentMethod === 'bank'
                      ? 'bg-amber-500/25 border-amber-400 text-amber-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  تحويل بنكي
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('usdt')}
                  className={`col-span-2 p-2 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                    paymentMethod === 'usdt'
                      ? 'bg-teal-500/25 border-teal-400 text-teal-300 shadow-sm'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  محفظة USDT (TRC20)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-purple-200 mb-1">
                رقم المحفظة / الحساب / الهاتف:
              </label>
              <input
                type="text"
                placeholder="اكتب رقمك أو معرف الحساب..."
                value={accountDetails}
                onChange={(e) => setAccountDetails(e.target.value)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs outline-none focus:border-emerald-500"
              />
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold text-center">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 text-white font-black text-xs shadow-xl shadow-emerald-600/30 hover:brightness-105 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Send className="w-4 h-4 rotate-180" />
              <span>إرسال طلب السحب (${cashEstimate} USD)</span>
            </button>
          </form>
        ) : (
          <form onSubmit={handleCoinsConvertSubmit} className="space-y-3.5">
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-amber-500/30 space-y-2">
              <span className="text-xs font-bold text-amber-300 block">
                تحويل فوري إلى كوينز
              </span>
              <p className="text-[11px] text-slate-300">
                سعر التحويل: <b className="text-white">1 ماسة = 1 كوينز</b> (يتم التحويل في محفظتك فوراً)
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-purple-200">
                  عدد الماسات للتحويل:
                </label>
                <span className="text-[11px] text-amber-400 font-mono font-bold">
                  ستحصل على: {convertAmount.toLocaleString()} كوينز
                </span>
              </div>
              <input
                type="number"
                min="1"
                max={safeDiamonds}
                value={convertAmount}
                onChange={(e) => setConvertAmount(parseInt(e.target.value, 10) || 0)}
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-700 text-amber-300 font-mono font-bold text-base text-center outline-none focus:border-amber-500 shadow-inner"
              />
            </div>

            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] text-slate-400 font-bold">كميات سريعة:</span>
              {[20, 50, 100, 200].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setConvertAmount(Math.min(safeDiamonds, val))}
                  className="px-2.5 py-1 rounded-xl bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/30 text-amber-300 text-[11px] font-bold transition-all cursor-pointer"
                >
                  {val} 💎
                </button>
              ))}
              {safeDiamonds > 0 && (
                <button
                  type="button"
                  onClick={() => setConvertAmount(safeDiamonds)}
                  className="px-2.5 py-1 rounded-xl bg-amber-500/25 hover:bg-amber-500/40 border border-amber-500/50 text-amber-300 text-[11px] font-black transition-all cursor-pointer"
                >
                  تحويل الكل ({safeDiamonds}) 💎
                </button>
              )}
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold text-center">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-black text-xs shadow-xl shadow-amber-400/25 hover:brightness-105 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <Coins className="w-4 h-4" />
              <span>تحويل {convertAmount.toLocaleString()} كوينز فوراً</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
