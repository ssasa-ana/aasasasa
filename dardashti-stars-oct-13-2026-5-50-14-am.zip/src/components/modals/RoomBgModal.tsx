import React, { useRef } from 'react';
import { X, Palette, Image as ImageIcon, Check } from 'lucide-react';
import { ROOM_BGS } from '../../constants';

interface RoomBgModalProps {
  currentBg: string;
  onClose: () => void;
  onSelectBg: (css: string) => void;
  onUploadCustomBg: (file: File) => void;
}

export const RoomBgModal: React.FC<RoomBgModalProps> = ({
  currentBg,
  onClose,
  onSelectBg,
  onUploadCustomBg,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-sm bg-slate-900 border border-purple-500/30 rounded-3xl p-5 shadow-2xl space-y-4 text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-purple-300">
            <Palette className="w-5 h-5" />
            <h3 className="text-base font-bold text-white">خلفيات الغرفة الصوتية</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-300">
          اختر ثيماً مميزاً أو ارفع صورة خلفية خاصة من هاتفك لغرفتك.
        </p>

        {/* Preset themes */}
        <div className="grid grid-cols-2 gap-2.5 max-h-60 overflow-y-auto pr-1">
          {ROOM_BGS.map((bg) => {
            const isSelected = currentBg === bg.css;
            const isImageOrGradient = bg.css.startsWith('url') || bg.css.includes('gradient');
            return (
              <button
                key={bg.id}
                onClick={() => {
                  onSelectBg(bg.css);
                  onClose();
                }}
                className={`relative h-20 rounded-2xl text-xs font-bold text-white border transition-all text-center shadow-md overflow-hidden flex flex-col justify-end p-2.5 group hover:scale-[1.02] active:scale-95 cursor-pointer ${
                  isSelected ? 'border-amber-400 ring-2 ring-amber-400/60' : 'border-white/20'
                }`}
                style={
                  isImageOrGradient
                    ? {
                        backgroundImage: bg.css,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                        backgroundRepeat: 'no-repeat',
                      }
                    : {
                        backgroundColor: bg.css,
                      }
                }
              >
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                {isSelected && (
                  <div className="absolute top-2 left-2 w-5 h-5 rounded-full bg-amber-400 text-slate-950 flex items-center justify-center shadow">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
                <span className="relative z-10 text-[11px] font-black drop-shadow-md text-white">
                  {bg.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Custom file upload */}
        <div className="pt-2">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 px-4 rounded-2xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
          >
            <ImageIcon className="w-4 h-4 text-purple-400" />
            <span>رفع صورة خلفية خاصة من الجهاز</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            accept="image/*"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) {
                onUploadCustomBg(file);
                onClose();
              }
            }}
            className="hidden"
          />
        </div>
      </div>
    </div>
  );
};
