import React, { useState, useRef } from 'react';
import { X, Music, Upload, Play, Square, Volume2, VolumeX, Volume1, Sparkles, Disc3, Plus, Minus } from 'lucide-react';
import { DEMO_SONGS } from '../../constants';

interface RoomMusicModalProps {
  currentSongTitle?: string;
  isPlaying: boolean;
  volume: number;
  onVolumeChange: (vol: number) => void;
  onClose: () => void;
  onPlayDeviceFile: (file: File) => void;
  onPlayDemoSong: (songId: string, title: string) => void;
  onStopMusic: () => void;
}

export const RoomMusicModal: React.FC<RoomMusicModalProps> = ({
  currentSongTitle,
  isPlaying,
  volume = 0.85,
  onVolumeChange,
  onClose,
  onPlayDeviceFile,
  onPlayDemoSong,
  onStopMusic,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);

  const volPercent = Math.round(volume * 100);

  const handleStepVolume = (delta: number) => {
    const next = Math.max(0, Math.min(1, Math.round((volume + delta) * 100) / 100));
    onVolumeChange(next);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|m4a|aac|ogg|webm)$/i)) {
      alert('يرجى اختيار ملف صوتي صالح (MP3, WAV, M4A, OGG...)');
      return;
    }
    if (file.size > 25 * 1024 * 1024) {
      alert('الحد الأقصى للملف الصوتي هو 25 ميجابايت.');
      return;
    }
    setSelectedFileName(file.name);
    onPlayDeviceFile(file);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-sm bg-slate-900 border border-purple-500/30 rounded-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto text-right">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-pink-300">
            <Music className="w-5 h-5 text-pink-400" />
            <h3 className="text-base font-bold text-white">موسيقى وبث الغرفة</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Volume Controller */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/60 via-purple-950/40 to-slate-950 border border-pink-500/30 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-pink-500/20 text-pink-300 flex items-center justify-center border border-pink-500/30">
                {volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : volume < 0.5 ? (
                  <Volume1 className="w-4 h-4 text-amber-300" />
                ) : (
                  <Volume2 className="w-4 h-4 text-emerald-400" />
                )}
              </div>
              <div>
                <h4 className="text-xs font-bold text-white">التحكم في مستوى الصوت</h4>
                <p className="text-[10px] text-pink-300/80">صوت البث الموسيقي للغرفة</p>
              </div>
            </div>
            <span
              className={`px-2.5 py-1 rounded-xl text-xs font-black font-mono border ${
                volume === 0
                  ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                  : volume >= 0.8
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-purple-500/20 border-purple-500/40 text-purple-200'
              }`}
            >
              {volume === 0 ? 'مكتوم' : `${volPercent}%`}
            </span>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => handleStepVolume(-0.05)}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 flex items-center justify-center shrink-0 border border-slate-700 transition-all cursor-pointer"
              title="خفض الصوت"
            >
              <Minus className="w-4 h-4" />
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
              className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-pink-500"
            />
            <button
              onClick={() => handleStepVolume(0.05)}
              className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 flex items-center justify-center shrink-0 border border-slate-700 transition-all cursor-pointer"
              title="رفع الصوت"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Current Playing Bar */}
        {isPlaying && (
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/60 via-pink-900/40 to-slate-900 border border-pink-500/30 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Disc3 className="w-5 h-5 text-pink-400 animate-spin shrink-0" />
              <div className="min-w-0">
                <span className="text-[10px] text-pink-300 font-bold block">يعمل الآن:</span>
                <span className="text-xs font-bold text-white truncate block">
                  {currentSongTitle || 'مقطوعة موسيقية'}
                </span>
              </div>
            </div>
            <button
              onClick={() => {
                onStopMusic();
              }}
              className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold transition-all flex items-center gap-1 shrink-0 cursor-pointer"
              title="إيقاف"
            >
              <Square className="w-3.5 h-3.5 fill-rose-300" />
              <span>إيقاف</span>
            </button>
          </div>
        )}

        {/* Option 1: Pick from Device */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-purple-950/70 to-slate-950 border border-purple-500/30 text-center space-y-2.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 flex items-center justify-center text-white mx-auto shadow-lg shadow-purple-600/30">
            <Upload className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">تشغيل أغنية من هاتفك</h4>
            <p className="text-[11px] text-purple-300/80 mt-0.5 leading-relaxed">
              اختر ملفاً صوتياً من جهازك لبثه مباشرة داخل الغرفة لجميع المستمعين
            </p>
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 hover:opacity-95 text-white font-black text-xs shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
          >
            <Music className="w-4 h-4" />
            <span>اختيار ملف من الجهاز</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.webm"
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>

        {/* Option 2: Quick Demo Melodies */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-purple-200">
            <span>أنغام تجريبية سريعة:</span>
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="space-y-1.5">
            {DEMO_SONGS.map((song) => (
              <div
                key={song.id}
                onClick={() => {
                  onPlayDemoSong(song.id, song.title);
                  onClose();
                }}
                className="p-3 rounded-2xl bg-slate-950/70 hover:bg-slate-950 border border-slate-800 hover:border-pink-500/40 flex items-center justify-between gap-3 cursor-pointer transition-all group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-purple-600/20 group-hover:bg-pink-600/30 text-purple-300 flex items-center justify-center shrink-0 transition-colors">
                    <Music className="w-4 h-4 text-pink-400" />
                  </div>
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-white group-hover:text-pink-300 transition-colors block truncate">
                      {song.title}
                    </span>
                    <span className="text-[10px] text-slate-400">{song.artist}</span>
                  </div>
                </div>
                <button className="px-3 py-1.5 rounded-xl bg-purple-600/20 group-hover:bg-purple-600 text-purple-300 group-hover:text-white text-[11px] font-bold transition-all flex items-center gap-1 shrink-0">
                  <Play className="w-3 h-3 fill-current" />
                  <span>عزف</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
