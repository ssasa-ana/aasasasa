import React, { useRef } from 'react';
import {
  Copy,
  Gamepad2,
  Gift,
  Flame,
  CheckCircle,
  Edit3,
  Award,
  LogOut,
  Camera,
  ArrowUpRight,
  Zap,
  ShieldCheck,
  Trophy,
  Check,
  AlertCircle,
  Clock,
} from 'lucide-react';
import { UserAccount } from '../types';
import { translations, Language } from '../utils/i18n';

interface ProfileTabProps {
  currentUser: string;
  account: UserAccount | undefined;
  coins: number;
  lang?: Language;
  onOpenGames: () => void;
  onOpenInvite: () => void;
  onOpenLevels: () => void;
  onOpenEditProfile: () => void;
  onOpenVerification: () => void;
  onOpenTasks: () => void;
  onShowToast: (msg: string) => void;
  onLogout: () => void;
  onChangeAvatar: (file: File) => void;
  onOpenBuyCoins?: () => void;
  onOpenWithdraw?: () => void;
}

export const ProfileTab: React.FC<ProfileTabProps> = ({
  currentUser,
  account,
  coins,
  lang = 'ar',
  onOpenGames,
  onOpenInvite,
  onOpenLevels,
  onOpenEditProfile,
  onOpenVerification,
  onOpenTasks,
  onShowToast,
  onLogout,
  onChangeAvatar,
  onOpenBuyCoins,
  onOpenWithdraw,
}) => {
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';
  const avatarInputRef = useRef<HTMLInputElement>(null);

  const isFemale = Boolean(
    account?.gender?.includes('أنثى') ||
      account?.gender?.toLowerCase().includes('female')
  );
  const diamonds = account?.diamonds || 0;
  const isVerified = Boolean(account?.isVerified);
  const verificationStatus = account?.verificationStatus || (isVerified ? 'approved' : 'none');

  const handleCopyId = () => {
    if (account?.idNum) {
      navigator.clipboard?.writeText(account.idNum);
      onShowToast(`تم نسخ ID: ${account.idNum}`);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onChangeAvatar(file);
    }
    if (avatarInputRef.current) avatarInputRef.current.value = '';
  };

  const userCountry = account?.country || 'مصر';
  const userCountryFlag = account?.countryFlag || '🇪🇬';
  const displayName = account?.displayName || currentUser;

  return (
    <div className="space-y-4 pb-20 text-right">
      {/* Profile Header Card */}
      <div className="rounded-3xl bg-gradient-to-b from-purple-900/90 via-slate-900 to-slate-950 border border-purple-500/30 p-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-pink-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="flex items-start gap-4">
          {/* Avatar with Camera upload & Golden/Verified Ring */}
          <div className="relative shrink-0">
            <div
              className={`w-24 h-24 rounded-full p-1 shadow-xl flex items-center justify-center transition-all ${
                isVerified
                  ? 'bg-gradient-to-tr from-blue-400 via-indigo-500 to-emerald-400 shadow-blue-500/40 ring-2 ring-blue-400'
                  : 'bg-gradient-to-tr from-amber-400 via-purple-500 to-pink-500 shadow-purple-600/30'
              }`}
            >
              <div className="w-full h-full rounded-full bg-slate-950 overflow-hidden flex items-center justify-center relative">
                {account?.avatar ? (
                  <img
                    src={account.avatar}
                    alt={displayName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="text-3xl font-black text-white">
                    {displayName.slice(0, 1).toUpperCase()}
                  </span>
                )}
              </div>
            </div>

            {/* Verified badge icon on avatar */}
            {isVerified && (
              <div
                className="absolute top-0 right-0 p-1 rounded-full bg-blue-500 text-white shadow-lg border-2 border-slate-900"
                title="حساب موثق رسمياً"
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
              </div>
            )}

            {/* Change Avatar Button */}
            <button
              onClick={() => avatarInputRef.current?.click()}
              className="absolute bottom-0 left-0 p-2 rounded-full bg-purple-600 hover:bg-purple-500 text-white shadow-lg border-2 border-slate-900 transition-transform active:scale-90 cursor-pointer"
              title="تغيير الصورة"
            >
              <Camera className="w-3.5 h-3.5" />
            </button>
            <input
              type="file"
              ref={avatarInputRef}
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {/* User Details next to the Avatar */}
          <div className="flex-1 min-w-0 space-y-1.5 pt-0.5">
            <div className="flex items-center gap-1.5 flex-wrap">
              <h2 className="text-xl font-black text-white truncate tracking-wide">
                {displayName}
              </h2>
              {/* Verified Blue Badge Icon */}
              {isVerified && (
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-500/20 border border-blue-400/50 text-blue-300 text-[10px] font-black shrink-0">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
                  <span>{isRtl ? 'موثق' : 'Verified'}</span>
                </div>
              )}
            </div>

            {/* ID & Country Flag */}
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-800/90 border border-slate-700/80 text-white shadow-sm font-bold">
                <span className="text-sm">{userCountryFlag}</span>
                <span className="text-[11px] text-slate-200">{userCountry}</span>
              </div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-purple-950/80 border border-purple-500/30 text-purple-200 shadow-sm font-mono font-bold">
                <span className="text-[10px] text-purple-400">ID:</span>
                <span className="text-xs">{account?.idNum || '--------'}</span>
                <button
                  onClick={handleCopyId}
                  className="text-purple-400 hover:text-white transition-colors pr-0.5 cursor-pointer"
                  title="نسخ ID"
                >
                  <Copy className="w-3 h-3" />
                </button>
              </div>
            </div>

            {/* Badges: Gender & Age */}
            <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
              <span className="px-2.5 py-0.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-300 text-[11px] font-medium">
                {account?.gender || 'مستخدم'}
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-slate-800/80 border border-slate-700 text-slate-400 text-[11px]">
                {account?.age || 22} سنة
              </span>
            </div>

            {/* Verification status label on profile card */}
            {isVerified ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 text-[11px] font-bold mt-1">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>تم التوثيق بنجاح بعد قبول من الأدمن</span>
              </div>
            ) : verificationStatus === 'pending' ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/40 text-amber-300 text-[11px] font-bold mt-1">
                <Clock className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                <span>طلب التوثيق قيد مراجعة الإدارة</span>
              </div>
            ) : verificationStatus === 'rejected' ? (
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-rose-500/15 border border-rose-400/40 text-rose-300 text-[11px] font-bold mt-1">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                <span>تم رفض التوثيق من الإدارة (اضغط لإعادة التوثيق)</span>
              </div>
            ) : null}

            {account?.bio && (
              <p className="text-xs text-slate-300 italic pt-1 line-clamp-2">
                "{account.bio}"
              </p>
            )}
          </div>
        </div>

        {/* Coins Wallet */}
        <div className="mt-4 pt-2.5 border-t border-purple-500/20 flex items-center justify-between gap-2 bg-slate-950/70 rounded-2xl px-3.5 py-2 border border-amber-500/25 shadow-md">
          <div className="flex items-center gap-2">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-slate-300">{t.coinsLabel}:</span>
                <span className="text-sm font-black text-amber-300 font-mono">
                  {coins.toLocaleString()}
                </span>
                <span className="text-[11px] text-amber-400 font-bold">كوينز</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => {
              if (onOpenBuyCoins) {
                onOpenBuyCoins();
              } else {
                onShowToast('شحن الرصيد');
              }
            }}
            className="py-1.5 px-3 rounded-lg bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-300 hover:brightness-105 active:scale-95 text-slate-950 font-black text-[11px] shadow-sm transition-all flex items-center gap-1 shrink-0 cursor-pointer"
            title="شحن كوينز"
          >
            <Zap className="w-3.5 h-3.5 fill-slate-950" />
            <span>{t.recharge}</span>
          </button>
        </div>
      </div>

      {/* Withdraw for females */}
      {isFemale && (
        <button
          onClick={() => {
            if (onOpenWithdraw) {
              onOpenWithdraw();
            } else {
              onShowToast('سحب الأرباح');
            }
          }}
          className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-emerald-600/20 via-teal-600/20 to-emerald-500/20 hover:from-emerald-600/30 hover:to-emerald-500/30 border border-emerald-500/40 flex items-center justify-between text-white transition-all shadow-md group active:scale-98 cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500 text-slate-950 font-black group-hover:scale-105 transition-transform">
              <ArrowUpRight className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-bold block text-emerald-300">{t.withdrawDiamonds}</span>
              <span className="text-[11px] text-slate-300 font-medium">
                رصيد الأرباح: <b className="text-amber-300 font-mono">{diamonds.toLocaleString()}</b> ماسة (${(diamonds / 50).toFixed(2)})
              </span>
            </div>
          </div>
          <span className="text-xs font-black text-emerald-300 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center gap-1">
            <span>سحب كاش</span>
          </span>
        </button>
      )}

      {/* Profile Features & Settings Buttons */}
      <div className="space-y-2">
        {/* 1. BUTTON: توثيق (REQUESTED: حالة الحساب والامان تغير الاسم اكون كلمه توثيق) */}
        <button
          onClick={onOpenVerification}
          className={`w-full p-3.5 rounded-2xl border flex items-center justify-between text-white transition-all shadow-md group active:scale-98 cursor-pointer ${
            isVerified
              ? 'bg-gradient-to-r from-blue-950/60 to-slate-900 border-blue-500/50 hover:border-blue-400'
              : verificationStatus === 'pending'
              ? 'bg-gradient-to-r from-amber-950/60 to-slate-900 border-amber-500/50'
              : verificationStatus === 'rejected'
              ? 'bg-gradient-to-r from-rose-950/60 to-slate-900 border-rose-500/50'
              : 'bg-gradient-to-r from-purple-950/60 to-slate-900 border-purple-500/40 hover:border-purple-400'
          }`}
        >
          <div className="flex items-center gap-3">
            <div
              className={`p-2.5 rounded-xl flex items-center justify-center font-black group-hover:scale-105 transition-transform ${
                isVerified
                  ? 'bg-blue-500 text-white shadow-md shadow-blue-500/40'
                  : verificationStatus === 'pending'
                  ? 'bg-amber-500 text-slate-950'
                  : verificationStatus === 'rejected'
                  ? 'bg-rose-500 text-white'
                  : 'bg-purple-600/30 text-purple-300 border border-purple-500/40'
              }`}
            >
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-black block">
                {t.verification}
              </span>
              <span className="text-[11px] text-slate-300">
                {isVerified
                  ? 'تم التوثيق بنجاح بعد قبول الأدمن ✓'
                  : verificationStatus === 'pending'
                  ? 'طلب التوثيق قيد المراجعة'
                  : verificationStatus === 'rejected'
                  ? 'تم الرفض - انقر لإعادة التوثيق'
                  : 'التحقق من الوجه بالكاميرا المباشرة'}
              </span>
            </div>
          </div>
          <span
            className={`text-xs font-black px-3 py-1.5 rounded-xl border flex items-center gap-1 ${
              isVerified
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                : verificationStatus === 'pending'
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse'
                : verificationStatus === 'rejected'
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                : 'bg-purple-600/20 text-purple-300 border-purple-500/30'
            }`}
          >
            {isVerified
              ? 'موثق ✓'
              : verificationStatus === 'pending'
              ? 'قيد الانتظار'
              : verificationStatus === 'rejected'
              ? 'إعادة التوثيق'
              : 'بدء التوثيق'}
          </span>
        </button>

        {/* 2. BUTTON: المهمات (REQUESTED: زار المتصدرين تغير الاسم اكون المهمات) */}
        <button
          onClick={onOpenTasks}
          className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-amber-950/40 via-purple-950/50 to-slate-900 border border-amber-500/40 hover:border-amber-400 flex items-center justify-between text-white transition-all shadow-md group active:scale-98 cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 font-black group-hover:scale-105 transition-transform shadow-md">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-black block text-amber-300">
                {t.missions}
              </span>
              <span className="text-[11px] text-slate-300">
                {isRtl
                  ? 'كلم 3 مستخدمين واكسب 8 ماسات (للبنات فقط)'
                  : 'Talk to 3 users and earn 8 diamonds (Females only)'}
              </span>
            </div>
          </div>
          <span className="text-xs font-black text-amber-300 px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center gap-1">
            <span>+8 💎</span>
          </span>
        </button>

        {/* 3. Edit Profile */}
        <button
          onClick={onOpenEditProfile}
          className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-purple-900/40 to-slate-900/80 hover:bg-slate-900 border border-purple-500/30 flex items-center justify-between text-white transition-all shadow-sm group active:scale-98 cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400 group-hover:scale-105 transition-transform">
              <Edit3 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-bold block">{t.editProfile}</span>
              <span className="text-[11px] text-slate-400">
                {isRtl ? 'تعديل البيانات واللغة' : 'Change info & Language'}
              </span>
            </div>
          </div>
          <span className="text-xs font-bold text-purple-400">تعديل</span>
        </button>

        {/* 4. Games */}
        <button
          onClick={onOpenGames}
          className="w-full p-3.5 rounded-2xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 flex items-center justify-between text-white transition-all shadow-sm cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-600/20 text-purple-400">
              <Gamepad2 className="w-4 h-4" />
            </div>
            <span className="text-sm font-bold">{t.games}</span>
          </div>
          <span className="text-slate-400 text-xs">لعب</span>
        </button>

        {/* 5. Invite Friends */}
        <button
          onClick={onOpenInvite}
          className="w-full p-3.5 rounded-2xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 flex items-center justify-between text-white transition-all shadow-sm cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-600/20 text-emerald-400">
              <Gift className="w-4 h-4" />
            </div>
            <span className="text-sm font-bold">{t.inviteFriends}</span>
          </div>
          <span className="text-slate-400 text-xs">مشاركة</span>
        </button>

        {/* Levels for females */}
        {isFemale && (
          <button
            onClick={onOpenLevels}
            className="w-full p-3.5 rounded-2xl bg-gradient-to-r from-amber-500/20 to-pink-500/20 border border-amber-500/30 flex items-center justify-between text-white transition-all shadow-sm cursor-pointer"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-400 text-slate-950 font-black">
                <Award className="w-4 h-4" />
              </div>
              <span className="text-sm font-bold text-amber-300">مستويات الماس</span>
            </div>
            <span className="text-amber-300 text-xs font-bold">عرض</span>
          </button>
        )}
      </div>

      {/* Logout Button */}
      <button
        onClick={onLogout}
        className="w-full py-3.5 px-4 rounded-2xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-bold transition-all flex items-center justify-center gap-2 active:scale-98 cursor-pointer"
      >
        <LogOut className="w-4 h-4" />
        <span>{t.logout}</span>
      </button>
    </div>
  );
};
