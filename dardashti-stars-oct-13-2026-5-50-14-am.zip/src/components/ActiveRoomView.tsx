import React, { useState, useRef, useEffect } from 'react';
import {
  Mic,
  MicOff,
  LogOut,
  Palette,
  Gift,
  Gamepad2,
  Smile,
  Send,
  Crown,
  Lock,
  Unlock,
  Volume2,
  VolumeX,
  X,
  UserX,
  LayoutGrid,
  ChevronDown,
  ArrowDown,
  Music,
  ShieldCheck,
} from 'lucide-react';
import { UserAccount, RoomChatMsg, RoomGiftEvent, RoomMusicState } from '../types';
import { ROOM_SEAT_COUNT, QUICK_EMOJIS } from '../constants';
import { unlockAudio } from '../utils/audio';
import { RoomMusicModal } from './modals/RoomMusicModal';

interface ActiveRoomViewProps {
  currentUser: string;
  roomName: string;
  roomTitle: string;
  isOwner: boolean;
  roomSeats: Record<number | string, string | null>;
  roomMutes: Record<string, boolean>;
  roomLockedSeats: Record<number | string, boolean>;
  roomMusicState: RoomMusicState | null;
  roomBg: string;
  cloudAccounts: Record<string, UserAccount>;
  roomChatLog: RoomChatMsg[];
  mySeatIdx: number | null;
  isMicMuted: boolean;
  isMeSpeaking?: boolean;
  speakingUsers?: Record<string, boolean>;
  onMinimizeRoom?: () => void;
  onLeaveRoom: () => void;
  onTakeSeat: (index: number) => void;
  onToggleMic: () => void;
  onAdminKick: (index: number) => void;
  onAdminMute: (index: number) => void;
  onAdminToggleSeatLock: (index: number) => void;
  onOpenBgPicker: () => void;
  onOpenGiftModal: () => void;
  onSendChatMessage: (text: string) => void;
  onSendImageMessage?: (file: File) => void;
  floatingGifts: RoomGiftEvent[];
  floatingTexts: RoomChatMsg[];
  onOpenXO: () => void;
  musicVolume?: number;
  onVolumeChange?: (vol: number) => void;
  onPlayDeviceMusic: (file: File) => void;
  onPlayDemoMusic: (songId: string, title: string) => void;
  onStopRoomMusic: () => void;
  onTogglePauseRoomMusic: () => void;
  onShowToast: (msg: string) => void;
}

export const ActiveRoomView: React.FC<ActiveRoomViewProps> = ({
  currentUser,
  roomName,
  roomTitle,
  isOwner,
  roomSeats,
  roomMutes,
  roomLockedSeats,
  roomMusicState,
  roomBg,
  cloudAccounts,
  roomChatLog,
  mySeatIdx,
  isMicMuted,
  isMeSpeaking,
  speakingUsers,
  onMinimizeRoom,
  onLeaveRoom,
  onTakeSeat,
  onToggleMic,
  onAdminKick,
  onAdminMute,
  onAdminToggleSeatLock,
  onOpenBgPicker,
  onOpenGiftModal,
  onSendChatMessage,
  onSendImageMessage,
  floatingGifts,
  floatingTexts,
  onOpenXO,
  musicVolume = 0.85,
  onVolumeChange,
  onPlayDeviceMusic,
  onPlayDemoMusic,
  onStopRoomMusic,
  onTogglePauseRoomMusic,
  onShowToast,
}) => {
  const [chatInput, setChatInput] = useState('');
  const [showEmoji, setShowEmoji] = useState(false);
  const [showMiniGames, setShowMiniGames] = useState(false);
  const [showMusicModal, setShowMusicModal] = useState(false);
  const [showGridMenu, setShowGridMenu] = useState(false);
  const [isRoomMutedAll, setIsRoomMutedAll] = useState(false);
  const [selectedSeatAction, setSelectedSeatAction] = useState<number | null>(null);
  const [isUserScrolledUp, setIsUserScrolledUp] = useState(false);
  const isUserScrolledUpRef = useRef(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  const handleChatScroll = () => {
    if (!chatScrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatScrollRef.current;
    const atBottom = scrollHeight - (scrollTop + clientHeight) < 50;
    const scrolledUp = !atBottom;
    setIsUserScrolledUp(scrolledUp);
    isUserScrolledUpRef.current = scrolledUp;
  };

  useEffect(() => {
    if (chatScrollRef.current && !isUserScrolledUpRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [roomChatLog]);

  const scrollToBottom = () => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTo({
        top: chatScrollRef.current.scrollHeight,
        behavior: 'smooth',
      });
      setIsUserScrolledUp(false);
      isUserScrolledUpRef.current = false;
    }
  };

  const handleSend = () => {
    if (!chatInput.trim()) return;
    onSendChatMessage(chatInput.trim());
    setChatInput('');
    setTimeout(() => {
      scrollToBottom();
    }, 50);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  const adminName = roomSeats[ROOM_SEAT_COUNT];
  const adminAcc = adminName ? cloudAccounts[adminName] : undefined;
  const isMeAdmin = adminName === currentUser;
  const isHostSpeaking = isMeAdmin ? !!isMeSpeaking : (adminName ? !!speakingUsers?.[adminName] : false);

  const effectiveBg =
    roomBg || 'linear-gradient(135deg, #1e1b4b 0%, #4c1d95 50%, #701a75 100%)';
  const isImageOrGradient = effectiveBg.startsWith('url') || effectiveBg.includes('gradient');

  function renderSeat(idx: number) {
    const occupantName = roomSeats[idx] || roomSeats[String(idx)];
    const occupantAcc = occupantName ? cloudAccounts[occupantName] : undefined;
    const isMe = occupantName === currentUser;
    const isOccupantMuted = occupantName ? !!roomMutes[occupantName] : false;
    const isLocked = !!roomLockedSeats[idx] || !!roomLockedSeats[String(idx)];
    const seatDisplayNumber = idx + 1;
    const isOccupantSpeaking = isMe
      ? !!isMeSpeaking
      : (occupantName ? !!speakingUsers?.[occupantName] : false);

    const handleSeatClick = (e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      unlockAudio();
      if (occupantName) {
        if (isOwner && !isMe) {
          setSelectedSeatAction(idx);
        } else if (!isOwner && !isMe) {
          onShowToast(`المقعد مشغول بواسطة: ${occupantName}`);
        } else if (isMe) {
          onShowToast('أنت جالس على هذا المقعد');
        }
      } else {
        if (isLocked && !isOwner) {
          onShowToast('هذا المقعد مقفل من المضيف');
          return;
        }
        if (isOwner) {
          setSelectedSeatAction(idx);
        } else {
          onTakeSeat(idx);
        }
      }
    };

    return (
      <button
        key={idx}
        type="button"
        onClick={handleSeatClick}
        className="flex flex-col items-center justify-center p-1.5 rounded-2xl relative transition-transform cursor-pointer select-none active:scale-95 focus:outline-none pointer-events-auto touch-manipulation z-30"
        title={occupantName ? `مقعد ${seatDisplayNumber}: ${occupantName}` : `مقعد ${seatDisplayNumber}`}
      >
        <div
          className={`relative w-12 h-12 rounded-full flex items-center justify-center transition-all backdrop-blur-md shadow-md ${
            occupantName
              ? isMe
                ? `p-0.5 bg-gradient-to-tr from-amber-400 to-pink-500 shadow-amber-500/30 ring-2 ring-amber-400 ${
                    isOccupantSpeaking ? 'speaking-pulse' : ''
                  }`
                : isOccupantMuted
                ? 'p-0.5 bg-rose-600/50 ring-1 ring-rose-400'
                : `p-0.5 bg-gradient-to-tr from-emerald-400 to-teal-300 shadow-emerald-500/20 ${
                    isOccupantSpeaking ? 'speaking-pulse' : ''
                  }`
              : isLocked
              ? 'bg-black/60 border border-amber-500/60 shadow-inner'
              : 'bg-white/20 hover:bg-white/35 border border-white/30 active:scale-95'
          }`}
        >
          {occupantName ? (
            <div className="w-full h-full rounded-full bg-slate-900 overflow-hidden flex items-center justify-center">
              {occupantAcc?.avatar ? (
                <img
                  src={occupantAcc.avatar}
                  alt={occupantName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <span className="text-xs font-bold text-white">
                  {occupantName.slice(0, 1).toUpperCase()}
                </span>
              )}
            </div>
          ) : isLocked ? (
            <div className="flex flex-col items-center text-amber-300">
              <Lock className="w-4 h-4 text-amber-400" />
            </div>
          ) : (
            <div className="flex flex-col items-center text-white/80">
              <Mic className="w-4 h-4 text-white/80" />
            </div>
          )}

          {occupantName && isOccupantMuted && (
            <span
              className="absolute -bottom-0.5 -left-0.5 p-0.5 rounded-full bg-rose-600 text-white shadow border border-white/30"
              title="المايك مكتوم"
            >
              <MicOff className="w-2.5 h-2.5" />
            </span>
          )}

          {isLocked && occupantName && (
            <span className="absolute -top-0.5 -right-0.5 p-0.5 rounded-full bg-amber-500 text-slate-950 shadow">
              <Lock className="w-2.5 h-2.5" />
            </span>
          )}
        </div>

        <span className="text-[10px] font-bold text-white drop-shadow truncate max-w-[60px] mt-1 text-center pointer-events-none">
          {occupantName || (isLocked ? 'مقفل' : `مقعد ${seatDisplayNumber}`)}
        </span>
      </button>
    );
  }

  return (
    <div
      onClick={() => unlockAudio()}
      className="fixed inset-0 z-50 flex flex-col text-white max-w-lg mx-auto overflow-hidden select-none bg-slate-950 font-sans"
      style={
        isImageOrGradient
          ? {
              backgroundImage: effectiveBg,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
            }
          : {
              backgroundColor: effectiveBg,
            }
      }
    >
      <div className="absolute inset-0 bg-gradient-to-b from-black/35 via-transparent to-black/45 pointer-events-none z-0" />

      {/* 1. TOP HEADER BAR */}
      <div className="relative z-20 flex items-center justify-between px-3 py-2 bg-black/40 backdrop-blur-md border-b border-white/10 gap-2 shrink-0">
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onLeaveRoom}
            className="px-2.5 py-1.5 rounded-xl bg-rose-500/25 hover:bg-rose-500/40 text-rose-200 border border-rose-500/30 text-xs font-bold transition-all flex items-center gap-1 shadow-sm active:scale-95 cursor-pointer"
            title="مغادرة الغرفة"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>خروج</span>
          </button>
        </div>

        <div className="text-center min-w-0 px-1 flex-1">
          <div className="flex items-center justify-center gap-1 text-amber-300 text-xs font-bold truncate">
            <Crown className="w-3.5 h-3.5 shrink-0 text-amber-400" />
            <span className="truncate">{roomTitle}</span>
          </div>
          <span className="text-[10px] text-white/70 block truncate">
            المضيف: {roomName} {isOwner ? '(أنت)' : ''}
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={() => setShowMusicModal(true)}
            className={`px-2 py-1.5 rounded-xl border transition-all text-xs flex items-center gap-1 active:scale-95 cursor-pointer ${
              roomMusicState?.isPlaying
                ? 'bg-pink-600/35 hover:bg-pink-600/50 text-pink-200 border-pink-400/60 shadow-lg shadow-pink-500/30 animate-pulse'
                : 'bg-white/15 hover:bg-white/25 text-white border border-white/20'
            }`}
            title="الموسيقى"
          >
            <Music className={`w-3.5 h-3.5 ${roomMusicState?.isPlaying ? 'text-pink-300 animate-spin' : 'text-pink-200'}`} />
            <span className="text-[10px] font-bold">موسيقى</span>
          </button>

          <button
            onClick={() => setShowGridMenu(!showGridMenu)}
            className="p-2 rounded-xl bg-white/15 hover:bg-white/25 text-white border border-white/20 transition-all text-xs active:scale-95 cursor-pointer"
            title="أدوات الغرفة"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Floating gift animations */}
      {floatingGifts.map((fg, idx) => (
        <div
          key={fg.id || idx}
          className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 pointer-events-none text-center animate-float-gift"
        >
          <div className="text-6xl drop-shadow-2xl">{fg.gift}</div>
          <div className="mt-2 px-4 py-2 rounded-2xl bg-black/85 backdrop-blur-md border border-amber-400/50 text-white text-xs font-bold shadow-2xl">
            <span className="text-amber-300">{fg.from}</span> أهدى {fg.giftName} إلى{' '}
            <span className="text-pink-300">{fg.to}</span>
            {fg.msg && <div className="text-[11px] text-slate-300 mt-0.5">"{fg.msg}"</div>}
          </div>
        </div>
      ))}

      {/* Floating text bubbles */}
      {floatingTexts.map((ft) => (
        <div
          key={ft.id}
          className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30 pointer-events-none max-w-[90%] px-4 py-2 rounded-2xl bg-black/80 backdrop-blur-md border border-purple-400/40 text-white text-sm text-center shadow-2xl animate-room-text"
        >
          <span className="font-bold text-amber-300 ml-1">{ft.from}: </span>
          <span className="font-semibold">{ft.text}</span>
        </div>
      ))}

      {/* 2. COMPACT STAGE: HOST AVATAR & 8 SEATS */}
      <div className="relative z-30 px-3 pt-2 pb-1 shrink-0">
        <div className="flex flex-col items-center justify-center mb-1">
          <div className="relative">
            <div
              onClick={() => {
                unlockAudio();
                if (isOwner && roomSeats[ROOM_SEAT_COUNT] !== currentUser) {
                  onTakeSeat(ROOM_SEAT_COUNT);
                }
              }}
              className={`w-14 h-14 rounded-full p-0.5 bg-gradient-to-tr from-amber-300 via-pink-400 to-indigo-400 shadow-xl flex items-center justify-center transition-all ${
                isOwner && roomSeats[ROOM_SEAT_COUNT] !== currentUser
                  ? 'cursor-pointer hover:scale-105 active:scale-95 ring-2 ring-amber-300'
                  : ''
              } ${isHostSpeaking ? 'speaking-pulse' : 'opacity-95'}`}
              title={isOwner ? 'مقعد المضيف الرئيسي' : undefined}
            >
              <div className="w-full h-full rounded-full bg-slate-950 overflow-hidden flex items-center justify-center border-2 border-white/40">
                {adminAcc?.avatar ? (
                  <img src={adminAcc.avatar} alt="Host" className="w-full h-full object-cover" />
                ) : (
                  <span className="text-2xl">👑</span>
                )}
              </div>
            </div>
            {adminAcc?.isVerified && (
              <span className="absolute -top-1 -right-1 p-0.5 rounded-full bg-blue-500 text-white shadow border border-white/40" title="موثق">
                <ShieldCheck className="w-3 h-3" />
              </span>
            )}
          </div>
          <div className="mt-1 text-center">
            <span className="text-[11px] font-black text-white drop-shadow flex items-center gap-1 justify-center">
              <span>المضيف:</span>
              <span className="truncate max-w-[120px]">{adminName || (isOwner ? currentUser : 'شاغر')}</span>
            </span>
          </div>
        </div>

        {/* 8 MIC SEATS: 2 Rows of 4 */}
        <div className="w-full max-w-sm mx-auto space-y-1.5">
          <div className="grid grid-cols-4 gap-2 justify-items-center">
            {[0, 1, 2, 3].map((idx) => renderSeat(idx))}
          </div>
          <div className="grid grid-cols-4 gap-2 justify-items-center">
            {[4, 5, 6, 7].map((idx) => renderSeat(idx))}
          </div>
        </div>
      </div>

      {/* 3. LIVE CHAT AREA */}
      <div className="relative z-10 flex-1 flex flex-col min-h-0 mx-1.5 my-1 overflow-hidden">
        <div
          className="flex-1 overflow-y-auto px-2 py-2 space-y-2 text-xs overscroll-contain flex flex-col"
          ref={chatScrollRef}
          onScroll={handleChatScroll}
        >
          <div className="mt-auto" />
          <div className="text-center max-w-[95%] mx-auto px-3 py-1 rounded-xl bg-black/40 backdrop-blur-sm border border-purple-400/25 text-purple-200 text-[11px] leading-relaxed shadow-sm">
            <span>مرحباً بكم في الغرفة الصوتية! يرجى الالتزام بالاحترام وتجنب الإساءة.</span>
          </div>

          {roomChatLog.length === 0 ? (
            <div className="text-center py-6 text-white/60 text-xs italic drop-shadow">
              الدردشة هادئة... شارك بأول رسالة!
            </div>
          ) : (
            roomChatLog.map((msg) => {
              const senderAcc = cloudAccounts[msg.from];
              const isMsgFromMe = msg.from === currentUser;
              return (
                <div
                  key={msg.id}
                  className={`w-full flex ${isMsgFromMe ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`flex flex-col space-y-1 max-w-[85%] ${
                      isMsgFromMe ? 'items-start text-right' : 'items-end text-right'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 bg-black/55 backdrop-blur-md px-2 py-0.5 rounded-full border border-white/15 shadow-sm">
                      <div className="w-4 h-4 rounded-full overflow-hidden bg-slate-800 border border-white/30 shrink-0">
                        {senderAcc?.avatar ? (
                          <img src={senderAcc.avatar} alt={msg.from} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[9px] text-white">
                            {msg.from.slice(0, 1).toUpperCase()}
                          </div>
                        )}
                      </div>
                      <span className="text-[10px] font-bold text-amber-300 truncate max-w-[100px]">
                        {msg.from} {isMsgFromMe ? '(أنت)' : ''}
                      </span>
                      {senderAcc?.isVerified && (
                        <span title="موثق">
                          <ShieldCheck className="w-2.5 h-2.5 text-blue-400 shrink-0" />
                        </span>
                      )}
                    </div>
                    <div
                      className={`px-3.5 py-2 rounded-2xl text-[13px] font-medium leading-relaxed shadow-lg break-words border backdrop-blur-md ${
                        isMsgFromMe
                          ? 'bg-purple-900/80 border-purple-400/40 text-white rounded-tr-xs'
                          : 'bg-black/75 border-white/20 text-white rounded-tl-xs'
                      }`}
                    >
                      <span>{msg.text}</span>
                      {msg.img && (
                        <img
                          src={msg.img}
                          alt="Shared in room"
                          className="w-32 h-32 object-cover rounded-xl mt-1.5 border border-white/20 shadow"
                        />
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {isUserScrolledUp && (
          <button
            onClick={scrollToBottom}
            className="absolute bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 text-white text-[11px] font-bold shadow-2xl border border-purple-300/40 flex items-center gap-1 z-30 transition-all active:scale-95 animate-bounce cursor-pointer"
          >
            <ArrowDown className="w-3 h-3" />
            <span>رسائل جديدة</span>
          </button>
        )}
      </div>

      {/* 4. BOTTOM BAR */}
      <div className="relative z-30 bg-black/60 backdrop-blur-xl border-t border-white/15 px-2.5 py-2 flex items-center justify-between gap-1.5 shrink-0">
        <div className="flex-1 min-w-[110px] h-9 bg-black/45 hover:bg-black/55 focus-within:bg-black/70 border border-white/20 focus-within:border-amber-400/80 rounded-full px-2.5 flex items-center gap-1.5 transition-all backdrop-blur-md">
          <input
            type="text"
            value={chatInput}
            onChange={(e) => setChatInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="اكتب في الغرفة..."
            className="flex-1 bg-transparent text-white placeholder-white/60 text-xs font-medium outline-none min-w-0"
          />
          <button
            onClick={handleSend}
            disabled={!chatInput.trim()}
            className={`p-1 rounded-full transition-all shrink-0 active:scale-90 ${
              chatInput.trim()
                ? 'bg-amber-400 text-slate-950 shadow-md cursor-pointer'
                : 'text-white/30 cursor-not-allowed'
            }`}
            title="إرسال"
          >
            <Send className="w-3.5 h-3.5 rtl:-scale-x-100" />
          </button>
        </div>

        <button
          onClick={() => {
            const next = !isRoomMutedAll;
            setIsRoomMutedAll(next);
            onShowToast(next ? 'تم كتم أصوات الغرفة' : 'تم تشغيل أصوات الغرفة');
          }}
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 border border-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 transition-colors cursor-pointer"
          title={isRoomMutedAll ? 'تشغيل الصوت' : 'كتم الصوت'}
        >
          {isRoomMutedAll ? <VolumeX className="w-4 h-4 text-rose-300" /> : <Volume2 className="w-4 h-4 text-white" />}
        </button>

        <button
          onClick={onToggleMic}
          className={`w-9 h-9 rounded-full border backdrop-blur-md flex items-center justify-center transition-all shrink-0 cursor-pointer active:scale-90 ${
            isMicMuted
              ? 'bg-black/40 hover:bg-black/60 border-white/20 text-white/80'
              : 'bg-emerald-600/50 hover:bg-emerald-600/70 border-emerald-400 text-emerald-200 animate-pulse shadow-md shadow-emerald-500/30'
          }`}
          aria-label="مايك"
        >
          {isMicMuted ? <MicOff className="w-4 h-4 text-rose-300" /> : <Mic className="w-4 h-4 text-white" />}
        </button>

        <button
          onClick={() => {
            setShowEmoji(!showEmoji);
            setShowMiniGames(false);
            setShowGridMenu(false);
          }}
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 border border-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 transition-colors cursor-pointer"
          title="إيموجي"
        >
          <Smile className="w-4 h-4 text-white" />
        </button>

        <button
          onClick={() => {
            setShowMiniGames(!showMiniGames);
            setShowEmoji(false);
            setShowGridMenu(false);
          }}
          className="w-9 h-9 rounded-full bg-black/40 hover:bg-black/60 border border-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 transition-colors cursor-pointer"
          title="ألعاب"
        >
          <Gamepad2 className="w-4 h-4 text-white" />
        </button>

        <button
          onClick={onOpenGiftModal}
          className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-700 via-indigo-600 to-purple-600 border border-purple-400/50 shadow-lg shadow-purple-600/40 flex items-center justify-center hover:scale-105 active:scale-90 transition-all shrink-0 cursor-pointer"
          title="إرسال هدية"
        >
          <Gift className="w-5 h-5 text-amber-300 fill-amber-400" />
        </button>
      </div>

      {/* Grid Tools Popup Menu */}
      {showGridMenu && (
        <div className="bg-slate-900/95 backdrop-blur-xl border-t border-purple-500/30 p-3 z-30 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-bold text-purple-200">أدوات الغرفة</span>
            <button onClick={() => setShowGridMenu(false)} className="text-slate-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => {
                setShowGridMenu(false);
                if (onMinimizeRoom) {
                  onMinimizeRoom();
                }
              }}
              className="p-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 flex flex-col items-center gap-1.5 transition-all active:scale-95 text-center cursor-pointer"
              title="تصغير الغرفة"
            >
              <ChevronDown className="w-5 h-5 text-amber-300" />
              <span className="text-[10px] font-bold text-white">تصغير</span>
            </button>
            <button
              onClick={() => {
                setShowGridMenu(false);
                setShowMusicModal(true);
              }}
              className="p-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 flex flex-col items-center gap-1.5 transition-all active:scale-95 text-center cursor-pointer"
              title="الموسيقى"
            >
              <Music className="w-5 h-5 text-pink-400" />
              <span className="text-[10px] font-bold text-white">الموسيقى</span>
            </button>
            <button
              onClick={() => {
                setShowGridMenu(false);
                onOpenBgPicker();
              }}
              className="p-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 flex flex-col items-center gap-1.5 transition-all active:scale-95 text-center cursor-pointer"
              title="تغيير الخلفية"
            >
              <Palette className="w-5 h-5 text-purple-300" />
              <span className="text-[10px] font-bold text-white">الخلفية</span>
            </button>
            <button
              onClick={() => {
                setShowGridMenu(false);
                onOpenXO();
              }}
              className="p-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 flex flex-col items-center gap-1.5 transition-all active:scale-95 text-center cursor-pointer"
              title="تحدي X-O"
            >
              <Gamepad2 className="w-5 h-5 text-emerald-400" />
              <span className="text-[10px] font-bold text-white">لعبة X-O</span>
            </button>
          </div>
        </div>
      )}

      {/* Mini-Games Drawer */}
      {showMiniGames && (
        <div className="bg-slate-900 border-t border-purple-500/30 p-3 z-30 animate-in fade-in slide-in-from-bottom-2">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-purple-200">ألعاب الغرفة</span>
            <button onClick={() => setShowMiniGames(false)} className="text-slate-400 hover:text-white cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => {
                setShowMiniGames(false);
                onOpenXO();
              }}
              className="p-2.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 flex flex-col items-center gap-1 transition-all cursor-pointer"
            >
              <span className="text-xl">⚔️</span>
              <span className="text-[10px] font-bold text-white">تحدي X-O</span>
            </button>
          </div>
        </div>
      )}

      {/* Emoji Drawer */}
      {showEmoji && (
        <div className="bg-slate-900 border-t border-purple-500/30 p-2 z-30 animate-in fade-in slide-in-from-bottom-2">
          <div className="grid grid-cols-9 gap-1 max-h-24 overflow-y-auto">
            {QUICK_EMOJIS.map((emoji) => (
              <button
                key={emoji}
                onClick={() => setChatInput((prev) => prev + emoji)}
                className="text-xl p-1 hover:bg-slate-800 rounded-lg transition-colors text-center cursor-pointer"
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Room Music Modal */}
      {showMusicModal && (
        <RoomMusicModal
          currentSongTitle={roomMusicState?.title}
          isPlaying={!!roomMusicState?.isPlaying}
          volume={musicVolume}
          onVolumeChange={onVolumeChange || (() => {})}
          onClose={() => setShowMusicModal(false)}
          onPlayDeviceFile={onPlayDeviceMusic}
          onPlayDemoSong={onPlayDemoMusic}
          onStopMusic={onStopRoomMusic}
        />
      )}

      {/* Seat Control Modal for Owner */}
      {isOwner && selectedSeatAction !== null && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedSeatAction(null)}
        >
          <div
            className="w-full max-w-xs bg-slate-900 border border-purple-500/50 rounded-3xl p-5 shadow-2xl space-y-4 text-center relative z-[110]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
              <span className="text-sm font-black text-amber-300 flex items-center gap-1.5">
                <Crown className="w-4 h-4 text-amber-400" />
                <span>إدارة مقعد {selectedSeatAction + 1}</span>
              </span>
              <button
                type="button"
                onClick={() => setSelectedSeatAction(null)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {roomSeats[selectedSeatAction] || roomSeats[String(selectedSeatAction)] ? (
              <div className="space-y-2.5">
                <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs font-bold text-white">
                  المستخدم: {roomSeats[selectedSeatAction] || roomSeats[String(selectedSeatAction)]}
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAdminMute(selectedSeatAction);
                    setSelectedSeatAction(null);
                  }}
                  className="w-full py-3 px-3 rounded-2xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  {roomMutes[roomSeats[selectedSeatAction] || roomSeats[String(selectedSeatAction)]!] ? (
                    <Mic className="w-4 h-4" />
                  ) : (
                    <MicOff className="w-4 h-4" />
                  )}
                  <span>
                    {roomMutes[roomSeats[selectedSeatAction] || roomSeats[String(selectedSeatAction)]!]
                      ? 'إلغاء كتم المايك'
                      : 'كتم مايك المستخدم'}
                  </span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onAdminKick(selectedSeatAction);
                    setSelectedSeatAction(null);
                  }}
                  className="w-full py-3 px-3 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
                >
                  <UserX className="w-4 h-4" />
                  <span>طرد من المقعد</span>
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="p-2.5 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs font-medium text-slate-300">
                  المقعد {selectedSeatAction + 1} شاغر{' '}
                  {roomLockedSeats[selectedSeatAction] || roomLockedSeats[String(selectedSeatAction)]
                    ? '(مقفل)'
                    : '(مفتوح)'}
                </div>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    onTakeSeat(selectedSeatAction);
                    setSelectedSeatAction(null);
                  }}
                  className="w-full py-3.5 px-3 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-pink-600 hover:opacity-95 text-white text-xs font-black flex items-center justify-center gap-2 transition-all shadow-lg active:scale-95 cursor-pointer touch-manipulation"
                >
                  <Mic className="w-4 h-4" />
                  <span>جلوس على المقعد {selectedSeatAction + 1} الآن</span>
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    e.preventDefault();
                    onAdminToggleSeatLock(selectedSeatAction);
                    setSelectedSeatAction(null);
                  }}
                  className={`w-full py-3.5 px-3 rounded-2xl text-xs font-black flex items-center justify-center gap-2 transition-all border active:scale-95 cursor-pointer touch-manipulation ${
                    roomLockedSeats[selectedSeatAction] || roomLockedSeats[String(selectedSeatAction)]
                      ? 'bg-emerald-500/20 hover:bg-emerald-500/30 border-emerald-500/40 text-emerald-300'
                      : 'bg-amber-500/20 hover:bg-amber-500/30 border-amber-500/40 text-amber-300'
                  }`}
                >
                  {roomLockedSeats[selectedSeatAction] || roomLockedSeats[String(selectedSeatAction)] ? (
                    <>
                      <Unlock className="w-4 h-4" />
                      <span>فتح المقعد</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>قفل المقعد</span>
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
